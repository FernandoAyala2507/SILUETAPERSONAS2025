import os
import re
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


def corregir_espaciados_upn(
    archivo_entrada=r"C:\Users\jeanh\Desktop\Cosas\Titulacion\Script\CorregidoTrabajo_Final.docx",
    archivo_salida=r"C:\Users\jeanh\Desktop\Cosas\Titulacion\Script\Trabajo_Final_Corregido_UPN.docx",
):
    doc = Document(archivo_entrada)

    # 1. Configurar márgenes reglamentarios UPN (2.54 cm en los 4 lados) y tamaño Carta
    for seccion in doc.sections:
        seccion.page_width = Inches(8.5)
        seccion.page_height = Inches(11.0)
        seccion.top_margin = Inches(1.0)
        seccion.bottom_margin = Inches(1.0)
        seccion.left_margin = Inches(1.0)
        seccion.right_margin = Inches(1.0)

    # 2. Configurar Estilo 'Normal'
    estilo_normal = doc.styles["Normal"]
    estilo_normal.font.name = "Times New Roman"
    estilo_normal.font.size = Pt(12)
    estilo_normal.font.color.rgb = RGBColor(0, 0, 0)

    rPr = estilo_normal.element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.append(rFonts)
    rFonts.set(qn("w:ascii"), "Times New Roman")
    rFonts.set(qn("w:hAnsi"), "Times New Roman")
    rFonts.set(qn("w:cs"), "Times New Roman")

    patron_capitulos = re.compile(r"^CAP[ÍI]TULO\s+[IVXLCDM]+", re.IGNORECASE)
    patron_subtitulos_num = re.compile(r"^\d+\.\d+(\.\d+)?\s+")
    patron_literales = re.compile(r"^[a-d]\)\s+")
    patron_elementos = re.compile(
        r"^(RESUMEN EJECUTIVO|DECLARACIÓN DE USO DE INTELIGENCIA ARTIFICIAL|REFERENCIAS|ANEXOS|Tabla \d+|Figura \d+|Ecuación \d+)",
        re.IGNORECASE,
    )

    es_portada = True

    for p in doc.paragraphs:
        texto = p.text.strip()

        # Si es un párrafo vacío que genera espaciado desigual, se normaliza
        if not texto:
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            continue

        if "RESUMEN EJECUTIVO" in texto.upper():
            es_portada = False

        # Homogeneizar fuente Times New Roman 12 pt
        for run in p.runs:
            run.font.name = "Times New Roman"
            if not run.font.size:
                run.font.size = Pt(12)

        # Regla de oro UPN/APA: interlineado doble continuo sin pt extra antes o después
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)

        # Tratar encabezados y jerarquías
        if es_portada:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Inches(0)
        elif patron_capitulos.match(texto) or patron_elementos.match(texto):
            # Títulos principales de capítulos (Nivel 1): Centrados y en Negrita
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Inches(0)
            for run in p.runs:
                run.bold = True
        elif patron_subtitulos_num.match(texto) or patron_literales.match(
            texto
        ):
            # Subtítulos (Nivel 2 y 3): Alineados a la izquierda, en Negrita, sin sangría
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.first_line_indent = Inches(0)
            for run in p.runs:
                run.bold = True
        elif (
            texto.startswith("Nota.")
            or texto.startswith("Fuente:")
            or texto.startswith("TRTC=")
        ):
            # Notas de tablas/figuras
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.first_line_indent = Inches(0)
        else:
            # Párrafos de texto regulares: Sangría de primera línea 1.27 cm
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.first_line_indent = Inches(0.5)

    doc.save(archivo_salida)
    print(f"Documento normalizado generado con éxito: {archivo_salida}")


if __name__ == "__main__":
    corregir_espaciados_upn()