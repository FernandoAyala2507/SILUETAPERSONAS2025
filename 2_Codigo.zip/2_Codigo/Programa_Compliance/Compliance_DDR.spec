# -*- mode: python ; coding: utf-8 -*-

from PyInstaller.utils.hooks import collect_all

# ============================================================
# RECOLECCIÓN DE PyQt6 (evita errores de DLLs faltantes)
# ============================================================
datas_qt, binaries_qt, hiddenimports_qt = collect_all('PyQt6')

# ============================================================
# RECOLECCIÓN DE PLAYWRIGHT (para que el navegador funcione)
# ============================================================
datas_pw, binaries_pw, hiddenimports_pw = collect_all('playwright')

# ============================================================
# RECOLECCIÓN DE pdfplumber (necesita sus datos)
# ============================================================
datas_pdf, binaries_pdf, hiddenimports_pdf = collect_all('pdfplumber')

# ============================================================
# RECOLECCIÓN DE pandas / openpyxl (por si acaso)
# ============================================================
datas_pd, binaries_pd, hiddenimports_pd = collect_all('pandas')
datas_op, binaries_op, hiddenimports_op = collect_all('openpyxl')

# ============================================================
# TUS ARCHIVOS PROPIOS (JSON e icono)
# ============================================================
mis_datos = [
    ('ubigeos_map.json', '.'),
    ('logo.ico', '.'),
]

# ============================================================
# UNIR TODO
# ============================================================
datas_totales = (
    mis_datos 
    + datas_qt + datas_pw + datas_pdf + datas_pd + datas_op
)

binaries_totales = (
    binaries_qt + binaries_pw + binaries_pdf + binaries_pd + binaries_op
)

hiddenimports_totales = (
    hiddenimports_qt 
    + hiddenimports_pw 
    + hiddenimports_pdf 
    + hiddenimports_pd 
    + hiddenimports_op
    + [
        # Módulos internos de tu proyecto (por si PyInstaller no los detecta)
        'modulos.modulo_extractor',
        'modulos.modulo_gesintel',
        'modulos.modulo_sentinel',
        'modulos.modulo_sunat',
        'modulos.modulo_word',
        'modulos.modulo_anexos',
        'modulos.modulo_descargas',
        'modulos.modulo_eecc',
        'modulos.orquestador_lsb',
        'modulos.procesador_pdf',
        'modulos.eecc_documental',
        'modulos.eecc_extractor',
        'modulos.eecc_validador',
        'modulos.exportador_excel',
        'utils.conversor_columnas',
        'vistas.vista_rutas',
        'vistas.vista_extractor',
        'vistas.vista_descargas',
        'vistas.vista_anexos',
        'vistas.vista_core',
        'worker_core',
        'worker_extractor',
        'worker_descargas',
        'worker_anexos',
        'config_manager',
        # Backends de pandas
        'fastparquet',
        'pyarrow',
        'openpyxl',
        'xlsxwriter',
        # Utilidades que a veces se pierden
        'pypdf',
        'fitz',
        'docx',
    ]
)

# ============================================================
# ANÁLISIS
# ============================================================
a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=binaries_totales,
    datas=datas_totales,
    hiddenimports=hiddenimports_totales,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Compliance_DDR',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,          # <--- UPX desactivado (causa problemas con PyQt6)
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='logo.ico',    # <--- Icono del ejecutable
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,          # <--- UPX desactivado aquí también
    upx_exclude=[],
    name='Compliance_DDR',
)