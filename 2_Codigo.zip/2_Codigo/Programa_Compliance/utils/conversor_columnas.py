class ConversorColumnas:
    """Conversor estático de letras de columnas Excel a índices (0-based)."""
    
    @staticmethod
    def col_a_indice(letra: str) -> int:
        """
        Convierte una letra de columna de Excel a índice numérico (0-based).
        
        Args:
            letra: Letra o combinación de letras (ej: "A", "Z", "AA", "AB")
            
        Returns:
            Índice numérico (0 = columna A)
            
        Examples:
            >>> ConversorColumnas.col_a_indice("A")
            0
            >>> ConversorColumnas.col_a_indice("Z")
            25
            >>> ConversorColumnas.col_a_indice("AA")
            26
        """
        if not letra or not isinstance(letra, str):
            raise ValueError(f"La letra debe ser un string válido: {letra}")
        
        letra_limpia = str(letra).strip().upper()
        
        if not letra_limpia.isalpha():
            raise ValueError(f"La columna debe contener solo letras: {letra_limpia}")
        
        num = 0
        for char in letra_limpia:
            num = num * 26 + (ord(char) - ord('A')) + 1
        
        return num - 1
    
    @staticmethod
    def indice_a_col(indice: int) -> str:
        """
        Convierte un índice numérico a letra de columna Excel (inversa).
        
        Args:
            indice: Índice 0-based
            
        Returns:
            Letra de columna (ej: 0 -> "A", 25 -> "Z", 26 -> "AA")
        """
        if indice < 0:
            raise ValueError(f"El índice no puede ser negativo: {indice}")
        
        resultado = ""
        num = indice + 1
        
        while num > 0:
            num -= 1
            resultado = chr(ord('A') + (num % 26)) + resultado
            num //= 26
        
        return resultado
    
    @staticmethod
    def es_valida(letra: str) -> bool:
        """Verifica si una cadena es una letra de columna válida."""
        try:
            ConversorColumnas.col_a_indice(letra)
            return True
        except ValueError:
            return False


def col_a_indice(letra: str) -> int:
    """Versión funcional simple (delegación al método estático)."""
    return ConversorColumnas.col_a_indice(letra)