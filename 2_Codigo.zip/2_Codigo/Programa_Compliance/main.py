import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QHBoxLayout, 
                             QVBoxLayout, QFrame, QLabel, QPushButton, QStackedWidget,
                             QSizePolicy, QScrollArea)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QIcon

import config_manager
from vistas.vista_rutas import VistaRutas
from vistas.vista_extractor import VistaExtractor
from vistas.vista_descargas import VistaDescargas
from vistas.vista_anexos import VistaAnexos
from vistas.vista_core import VistaProcesamientoCore

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

MODERN_STYLE = """
    /* ========== VARIABLES GLOBALES ========== */
    * {
        font-family: 'Segoe UI', 'Inter', 'Roboto', sans-serif;
    }
    
    /* ========== VENTANA PRINCIPAL ========== */
    QMainWindow {
        background-color: #0a0e1a;
    }
    
    /* ========== SIDEBAR ========== */
    #Sidebar {
        background-color: #0f1117;
        border-right: 1px solid #1e2433;
        min-width: 240px;
        max-width: 240px;
    }
    
    #SidebarLabel {
        color: #ffffff;
        font-size: 16px;
        font-weight: bold;
        padding: 24px 16px;
        letter-spacing: 1px;
        border-bottom: 2px solid #2a7de1;
        margin-bottom: 20px;
    }
    
    /* ========== BOTONES DEL MENÚ ========== */
    .MenuButton {
        color: #a8b3cf;
        background-color: transparent;
        border: none;
        border-radius: 12px;
        padding: 12px 16px;
        text-align: left;
        font-size: 13px;
        font-weight: 500;
        margin: 4px 12px;
    }
    
    .MenuButton:hover {
        background-color: #1a1f2e;
        color: #ffffff;
    }
    
    .MenuButton:checked {
        background-color: #2a7de1;
        color: #ffffff;
        font-weight: 600;
    }
    
    /* ========== ÁREA CENTRAL ========== */
    #ContentArea {
        background-color: #0a0e1a;
    }
    
    /* ========== TARJETAS (GROUP BOX) ========== */
    QGroupBox {
        color: #ffffff;
        font-weight: 600;
        font-size: 13px;
        border: 1px solid #2a2f3f;
        border-radius: 14px;
        margin-top: 14px;
        padding-top: 18px;
        background-color: #121624;
    }
    
    QGroupBox::title {
        subcontrol-origin: margin;
        subcontrol-position: top left;
        left: 16px;
        padding: 0 10px;
        background-color: #121624;
        color: #2a7de1;
    }
    
    /* ========== CAMPOS DE TEXTO ========== */
    QLineEdit, QTextEdit, QPlainTextEdit {
        background-color: #1a1f2e;
        color: #e0e4f0;
        border: 1px solid #2a2f3f;
        border-radius: 10px;
        padding: 8px 12px;
        font-size: 12px;
        selection-background-color: #2a7de1;
    }
    
    QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {
        border: 1px solid #2a7de1;
        outline: none;
    }
    
    /* ========== COMBOBOX ========== */
    QComboBox {
        background-color: #1a1f2e;
        color: #e0e4f0;
        border: 1px solid #2a2f3f;
        border-radius: 10px;
        padding: 8px 12px;
        font-size: 12px;
        min-width: 150px;
    }
    
    QComboBox:hover {
        border: 1px solid #2a7de1;
    }
    
    QComboBox:focus {
        border: 1px solid #2a7de1;
        outline: none;
    }
    
    QComboBox QAbstractItemView {
        background-color: #1a1f2e;
        color: #e0e4f0;
        border: 1px solid #2a2f3f;
        border-radius: 10px;
        selection-background-color: #2a7de1;
        selection-color: #ffffff;
        outline: none;
    }
    
    QComboBox QAbstractItemView::item {
        padding: 8px 12px;
        min-height: 25px;
    }
    
    QComboBox QAbstractItemView::item:hover {
        background-color: #2a2f3f;
    }
    
    QComboBox::drop-down {
        border: none;
        width: 30px;
    }
    
    QComboBox::down-arrow {
        image: none;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
        border-top: 5px solid #e0e4f0;
        margin-right: 10px;
    }
    
    /* ========== LABELS ========== */
    QLabel {
        color: #c8d0e0;
        font-size: 12px;
    }
    
    /* ========== BOTONES GENERALES ========== */
    QPushButton {
        background-color: #1e2433;
        color: #e0e4f0;
        border: none;
        border-radius: 10px;
        padding: 8px 14px;
        font-weight: 500;
        font-size: 12px;
    }
    
    QPushButton:hover {
        background-color: #2a2f3f;
    }
    
    QPushButton:pressed {
        background-color: #1a1f2e;
    }
    
    QPushButton#PrimaryButton {
        background-color: #2a7de1;
        color: #ffffff;
        font-weight: 600;
        font-size: 13px;
        padding: 10px 16px;
        border-radius: 12px;
    }
    
    QPushButton#PrimaryButton:hover {
        background-color: #3b8eef;
    }
    
    /* ========== CHECKBOX ========== */
    QCheckBox {
        color: #e0e4f0;
        font-size: 12px;
        spacing: 8px;
    }
    
    QCheckBox::indicator {
        width: 16px;
        height: 16px;
        border-radius: 5px;
        border: 1px solid #2a2f3f;
        background-color: #1a1f2e;
    }
    
    QCheckBox::indicator:checked {
        background-color: #2a7de1;
        border-color: #2a7de1;
    }
    
    /* ========== PROGRESS BAR ========== */
    QProgressBar {
        border: none;
        border-radius: 6px;
        background-color: #1a1f2e;
        text-align: center;
        color: #ffffff;
        font-weight: bold;
        font-size: 11px;
        height: 10px;
    }
    
    QProgressBar::chunk {
        background-color: #2a7de1;
        border-radius: 6px;
    }
    
    /* ========== LOGS ========== */
    QTextEdit, QPlainTextEdit {
        background-color: #0a0e1a;
        color: #b4ff9f;
        font-family: 'Consolas', 'Monaco', monospace;
        font-size: 11px;
        border-radius: 12px;
    }
    
    /* ========== LISTA DE LISTAS ========== */
    QListWidget {
        background-color: #1a1f2e;
        color: #e0e4f0;
        border: 1px solid #2a2f3f;
        border-radius: 12px;
        padding: 6px;
        outline: none;
    }
    
    QListWidget::item {
        padding: 8px;
        border-radius: 8px;
    }
    
    QListWidget::item:selected {
        background-color: #2a7de1;
    }
    
    QListWidget::item:hover {
        background-color: #2a2f3f;
    }
    
    /* ========== SCROLLBARS ========== */
    QScrollBar:vertical {
        background-color: #1a1f2e;
        width: 8px;
        border-radius: 4px;
    }
    
    QScrollBar::handle:vertical {
        background-color: #2a2f3f;
        border-radius: 4px;
        min-height: 30px;
    }
    
    QScrollBar::handle:vertical:hover {
        background-color: #3a4a5a;
    }
    
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
        height: 0px;
    }
    
    QScrollBar:horizontal {
        background-color: #1a1f2e;
        height: 8px;
        border-radius: 4px;
    }
    
    QScrollBar::handle:horizontal {
        background-color: #2a2f3f;
        border-radius: 4px;
        min-width: 30px;
    }
    
    /* ========== TAB WIDGET ========== */
    QTabWidget::pane {
        border: 1px solid #2a2f3f;
        border-radius: 12px;
        background-color: #121624;
    }
    
    QTabBar::tab {
        background-color: #1a1f2e;
        color: #a8b3cf;
        padding: 8px 20px;
        margin-right: 4px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }
    
    QTabBar::tab:selected {
        background-color: #2a7de1;
        color: #ffffff;
    }
    
    QTabBar::tab:hover:!selected {
        background-color: #2a2f3f;
    }
    
    /* ========== MESSAGE BOX ========== */
    QMessageBox {
        background-color: #121624;
    }
    
    QMessageBox QLabel {
        color: #e0e4f0;
        font-size: 12px;
    }
    
    QMessageBox QPushButton {
        background-color: #1e2433;
        color: #ffffff;
        border-radius: 8px;
        padding: 6px 14px;
        min-width: 70px;
    }
    
    QMessageBox QPushButton:hover {
        background-color: #2a7de1;
    }
    
    /* ========== TOOLTIP ========== */
    QToolTip {
        background-color: #1a1f2e;
        color: #ffffff;
        border: 1px solid #2a7de1;
        border-radius: 6px;
        padding: 5px 10px;
        font-size: 11px;
    }
"""

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sistema de DDR - By Jean H.")
        self.setWindowIcon(QIcon(resource_path("logo.ico")))
        self.setMinimumSize(900, 600)
        self.resize(1200, 800)
        self.setStyleSheet(MODERN_STYLE)
        
        font = QFont("Segoe UI", 10)
        QApplication.setFont(font)
        
        self.config_data = config_manager.cargar_memoria()
        self.setup_ui()

    def setup_ui(self):
        central_widget = QWidget()
        central_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(250)
        
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(20, 20, 20, 20)
        sidebar_layout.setSpacing(8)
        
        title_label = QLabel("⚖️ COMPLIANCE\nPLAFT")
        title_label.setObjectName("SidebarLabel")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setWordWrap(True)
        sidebar_layout.addWidget(title_label)
        
        sidebar_layout.addSpacing(20)
        
        self.btn_rutas = QPushButton("🏠  Rutas Globales")
        self.btn_extractor = QPushButton("📊  Cruce de Listas")
        self.btn_descargas = QPushButton("🌐  Descarga Web")
        self.btn_core = QPushButton("⚡  Procesamiento Core")
        self.btn_anexos = QPushButton("📎  Recopilar Anexos")
        
        self.menu_buttons = [self.btn_rutas, self.btn_extractor, self.btn_descargas, self.btn_core, self.btn_anexos]
        
        self.btn_rutas.setToolTip("Configura las rutas globales del sistema")
        self.btn_extractor.setToolTip("Ejecuta el cruce masivo de listas de riesgo")
        self.btn_descargas.setToolTip("Realiza búsquedas automáticas en la web")
        self.btn_core.setToolTip("Ejecuta el pipeline completo de compliance")
        self.btn_anexos.setToolTip("Recopila archivos anexos automáticamente")
        
        for i, btn in enumerate(self.menu_buttons):
            btn.setProperty("class", "MenuButton")
            btn.setCheckable(True)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda checked, index=i: self.change_page(index))
            sidebar_layout.addWidget(btn)
            
        sidebar_layout.addStretch()
        
        footer_label = QLabel("| By Jean H. |")
        footer_label.setStyleSheet("color: #4a5568; font-size: 11px; padding: 10px;")
        footer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sidebar_layout.addWidget(footer_label)
        
        main_layout.addWidget(sidebar)
        
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.setStyleSheet("QScrollArea { border: none; background-color: #0a0e1a; }")
        
        self.content_stack = QStackedWidget()
        self.content_stack.setObjectName("ContentArea")
        
        self.scroll_area.setWidget(self.content_stack)
        main_layout.addWidget(self.scroll_area)
        
        self.vista_rutas = VistaRutas(self)
        self.vista_extractor = VistaExtractor(self)
        self.vista_descargas = VistaDescargas(self)
        self.vista_core = VistaProcesamientoCore(self)
        self.vista_anexos = VistaAnexos(self)
        
        self.content_stack.addWidget(self.vista_rutas)
        self.content_stack.addWidget(self.vista_extractor)
        self.content_stack.addWidget(self.vista_descargas)
        self.content_stack.addWidget(self.vista_core)
        self.content_stack.addWidget(self.vista_anexos)
        
        self.change_page(0)

    def change_page(self, index):
        self.content_stack.setCurrentIndex(index)
        for i, btn in enumerate(self.menu_buttons):
            btn.setChecked(i == index)
            self.scroll_area.verticalScrollBar().setValue(0)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon(resource_path("logo.ico")))
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())