from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QComboBox, QCheckBox, QPushButton, QPlainTextEdit, QMessageBox, QGroupBox
from hilos.worker_core import WorkerThreadCore
import config_manager

class VistaProcesamientoCore(QWidget):
    def __init__(self, parent_main):
        super().__init__()
        self.parent_main = parent_main
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 20, 30, 20)

        group_params = QGroupBox("⚙️ Módulos a Ejecutar (Core)")
        layout_params = QVBoxLayout()
        
        combo_layout = QHBoxLayout()
        combo_layout.addWidget(QLabel("Periodo Fiscal:"))
        self.combo_mes = QComboBox()
        self.combo_mes.addItems(["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"])
        combo_layout.addWidget(self.combo_mes)
        combo_layout.addStretch()
        layout_params.addLayout(combo_layout)

        layout_checks = QGridLayout()
        self.chk_sunat = QCheckBox("Módulo SUNAT / Ficha RUC")
        self.chk_eecc = QCheckBox("Módulo Orquestador EECC (Copiar)")
        self.chk_motor = QCheckBox("Módulo Analítico LSB (Finanzas)")
        self.chk_sentinel = QCheckBox("Módulo SENTINEL")
        self.chk_gesintel = QCheckBox("Módulo GESINTEL")
        self.chk_word = QCheckBox("Módulo Generador WORD")
        
        for chk in [self.chk_sunat, self.chk_eecc, self.chk_motor, self.chk_sentinel, self.chk_gesintel, self.chk_word]:
            chk.setChecked(True)

        layout_checks.addWidget(self.chk_sunat, 0, 0)
        layout_checks.addWidget(self.chk_eecc, 0, 1)
        layout_checks.addWidget(self.chk_motor, 1, 0)
        layout_checks.addWidget(self.chk_sentinel, 1, 1)
        layout_checks.addWidget(self.chk_gesintel, 2, 0)
        layout_checks.addWidget(self.chk_word, 2, 1)
        layout_checks.setColumnStretch(0, 1)
        layout_checks.setColumnStretch(1, 1)
        
        layout_params.addLayout(layout_checks)
        group_params.setLayout(layout_params)
        layout.addWidget(group_params)

        self.btn_ejecutar = QPushButton("▶ INICIAR PROCESAMIENTO CORE")
        self.btn_ejecutar.setStyleSheet("background-color: #89b4fa; color: #11111b; font-weight: bold; font-size: 14px; padding: 10px;")
        self.btn_ejecutar.clicked.connect(self.iniciar_ejecucion)
        layout.addWidget(self.btn_ejecutar)

        self.txt_logs = QPlainTextEdit()
        self.txt_logs.setReadOnly(True)
        self.txt_logs.setStyleSheet("background-color: #11111b; color: #a6e3a1; font-family: Consolas;")
        layout.addWidget(self.txt_logs)

    def iniciar_ejecucion(self):
        config_global = self.parent_main.config_data
        
        if not config_global.get("ruta_matriz"):
            QMessageBox.warning(self, "Advertencia", "Falta definir el Libro Maestro en la pestaña de Rutas.")
            return

        self.btn_ejecutar.setEnabled(False)
        self.txt_logs.clear()
        self.escribir_log("🚀 INICIANDO PIPELINE DE COMPLIANCE...")

        config_global.update({
            "MES": self.combo_mes.currentText().strip().upper(),
            "EJECUTAR_SUNAT": self.chk_sunat.isChecked(),
            "EJECUTAR_EECC": self.chk_eecc.isChecked(),
            "EJECUTAR_MOTOR": self.chk_motor.isChecked(),
            "EJECUTAR_SENTINEL": self.chk_sentinel.isChecked(),
            "EJECUTAR_GESINTEL": self.chk_gesintel.isChecked(),
            "EJECUTAR_WORD": self.chk_word.isChecked()
        })
        
        config_manager.guardar_memoria(config_global)

        self.worker = WorkerThreadCore(config_global)
        self.worker.log_signal.connect(self.escribir_log)
        self.worker.error_signal.connect(self.manejar_error)
        self.worker.finished_signal.connect(self.finalizar_ejecucion)
        self.worker.start()

    def escribir_log(self, msj):
        self.txt_logs.appendPlainText(msj)

    def manejar_error(self, err):
        self.escribir_log(f"[ERROR] {err}")

    def finalizar_ejecucion(self):
        self.btn_ejecutar.setEnabled(True)
        self.escribir_log("✅ TAREAS FINALIZADAS.")