from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QFormLayout, QPushButton, 
                             QLineEdit, QTextEdit, QProgressBar, QGroupBox, QLabel, QMessageBox, QFileDialog)
from PyQt6.QtCore import Qt
import config_manager
from hilos.worker_anexos import WorkerAnexos

class VistaAnexos(QWidget):
    def __init__(self, parent_main):
        super().__init__()
        self.parent_main = parent_main
        self.setup_ui()
        self.cargar_datos()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)

        g_anexos = QGroupBox("🗂️ Módulo Recopilador de Archivos Externos (Sentinel, Sunat, etc.)")
        f_anexos = QFormLayout()
        
        lbl_info = QLabel("Este módulo rebusca los archivos que hayan sido descargados por otros sistemas o aplicativos, siempre y cuando tengan como nombre el DOI que vamos a buscar. Ej: '33333333 - SENTINEL.pdf'.")
        lbl_info.setStyleSheet("color: #a6adc8; font-size: 13px; font-style: italic; margin-bottom: 15px;")
        lbl_info.setWordWrap(True)
        f_anexos.addRow(lbl_info)

        self.txt_ruta_origen = QLineEdit()
        btn_origen = QPushButton("Directorio Origen de Archivos")
        btn_origen.clicked.connect(self.seleccionar_carpeta)
        f_anexos.addRow(btn_origen, self.txt_ruta_origen)

        self.txt_pestana = QLineEdit()
        self.txt_col_doi = QLineEdit()
        self.txt_col_car = QLineEdit()
        
        f_anexos.addRow("Pestaña a leer en Matriz:", self.txt_pestana)
        f_anexos.addRow("Letra Columna Documento (DOI):", self.txt_col_doi)
        f_anexos.addRow("Letra Columna N° Carpeta:", self.txt_col_car)

        self.btn_ejecutar = QPushButton("EJECUTAR RECOPILACIÓN DE ANEXOS")
        self.btn_ejecutar.setStyleSheet("background-color: #002060; color: white; font-weight: bold; padding: 12px; margin-top: 15px;")
        self.btn_ejecutar.clicked.connect(self.ejecutar_anexos)
        f_anexos.addRow(self.btn_ejecutar)

        g_anexos.setLayout(f_anexos)
        layout.addWidget(g_anexos)

        self.log_txt = QTextEdit()
        self.log_txt.setReadOnly(True)
        self.log_txt.setStyleSheet("background-color: #11111b; color: #f9e2af; font-family: Consolas;")
        layout.addWidget(self.log_txt)

        self.pb = QProgressBar()
        layout.addWidget(self.pb)

    def seleccionar_carpeta(self):
        ruta = QFileDialog.getExistingDirectory(self, "Seleccionar Carpeta Origen")
        if ruta: 
            self.txt_ruta_origen.setText(ruta)

    def cargar_datos(self):
        cfg = self.parent_main.config_data
        self.txt_ruta_origen.setText(cfg.get("anexos_ruta_origen", ""))
        self.txt_pestana.setText(cfg.get("anexos_pestana", "DDR_ANUAL"))
        self.txt_col_doi.setText(cfg.get("anexos_col_doi", "AD"))
        self.txt_col_car.setText(cfg.get("anexos_col_car", "A"))

    def guardar_datos(self):
        self.parent_main.config_data.update({
            "anexos_ruta_origen": self.txt_ruta_origen.text(),
            "anexos_pestana": self.txt_pestana.text().strip(),
            "anexos_col_doi": self.txt_col_doi.text().strip().upper(),
            "anexos_col_car": self.txt_col_car.text().strip().upper()
        })
        config_manager.guardar_memoria(self.parent_main.config_data)

    def ejecutar_anexos(self):
        self.guardar_datos()
        cfg = self.parent_main.config_data
        
        if not cfg.get("ruta_matriz") or not cfg.get("ruta_casos") or not cfg.get("anexos_ruta_origen"):
            return QMessageBox.warning(self, "Error", "Faltan configurar las Rutas Globales (Matriz o Destino) o la ruta de Origen de Anexos.")
        
        self.btn_ejecutar.setEnabled(False)
        self.log_txt.clear()
        self.pb.setValue(0)
        
        self.worker = WorkerAnexos(cfg)
        self.worker.log_signal.connect(self.log_txt.append)
        self.worker.progress_signal.connect(lambda v: self.pb.setValue(int(v * 100)))
        self.worker.error_signal.connect(lambda e: self.log_txt.append(f"[ERROR FATAL] {e}"))
        self.worker.finished_signal.connect(lambda: self.btn_ejecutar.setEnabled(True))
        self.worker.start()