from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QFormLayout, QPushButton, 
                             QLineEdit, QTextEdit, QProgressBar, QGroupBox, QMessageBox)
import config_manager
from hilos.worker_descargas import WorkerDescargas

class VistaDescargas(QWidget):
    def __init__(self, parent_main):
        super().__init__()
        self.parent_main = parent_main
        self.setup_ui()
        self.cargar_datos()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        
        g_desc = QGroupBox("🌐 Parámetros Auditoría Web (Bing PDF)")
        f_desc = QFormLayout()
        
        self.txt_desc_pestana = QLineEdit()
        self.txt_desc_col_nombre = QLineEdit()
        self.txt_desc_col_car = QLineEdit()
        
        f_desc.addRow("Pestaña a leer en Matriz:", self.txt_desc_pestana)
        f_desc.addRow("Letra Columna de Nombres:", self.txt_desc_col_nombre)
        f_desc.addRow("Letra Columna N° Carpeta:", self.txt_desc_col_car)
        
        self.btn_ejecutar = QPushButton("INICIAR AUDITORÍA Y RECORTE PDF")
        self.btn_ejecutar.setStyleSheet("background-color: #002060; color: white; font-weight: bold; padding: 12px; margin-top: 15px;")
        self.btn_ejecutar.clicked.connect(self.ejecutar_descargas)
        
        f_desc.addRow(self.btn_ejecutar)
        g_desc.setLayout(f_desc)
        layout.addWidget(g_desc)
        
        self.log_desc = QTextEdit()
        self.log_desc.setReadOnly(True)
        self.log_desc.setStyleSheet("background-color: #11111b; color: #89dceb; font-family: Consolas;")
        layout.addWidget(self.log_desc)
        
        self.pb_desc = QProgressBar()
        layout.addWidget(self.pb_desc)

    def cargar_datos(self):
        cfg = self.parent_main.config_data
        self.txt_desc_pestana.setText(cfg.get("descargas_pestana", "DDR_ANUAL"))
        self.txt_desc_col_nombre.setText(cfg.get("descargas_col_nombre", "C"))
        self.txt_desc_col_car.setText(cfg.get("descargas_col_car", "A"))

    def guardar_datos(self):
        self.parent_main.config_data.update({
            "descargas_pestana": self.txt_desc_pestana.text().strip(),
            "descargas_col_nombre": self.txt_desc_col_nombre.text().strip().upper(),
            "descargas_col_car": self.txt_desc_col_car.text().strip().upper()
        })
        config_manager.guardar_memoria(self.parent_main.config_data)

    def ejecutar_descargas(self):
        self.guardar_datos()
        cfg = self.parent_main.config_data
        
        if not cfg.get("ruta_matriz") or not cfg.get("ruta_casos"):
            return QMessageBox.warning(self, "Error", "Faltan configurar las Rutas Globales (Matriz o Casos) en la pestaña 'Rutas'.")
        
        self.btn_ejecutar.setEnabled(False)
        self.log_desc.clear()
        self.pb_desc.setValue(0)
        
        self.worker = WorkerDescargas(cfg)
        self.worker.log_signal.connect(self.log_desc.append)
        self.worker.progress_signal.connect(lambda v: self.pb_desc.setValue(int(v * 100)))
        self.worker.error_signal.connect(lambda e: self.log_desc.append(f"[ERROR FATAL] {e}"))
        self.worker.finished_signal.connect(lambda: self.btn_ejecutar.setEnabled(True))
        self.worker.start()