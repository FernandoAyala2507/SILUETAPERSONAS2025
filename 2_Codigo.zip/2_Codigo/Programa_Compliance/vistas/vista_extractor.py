import os

from PyQt6.QtWidgets import (QLabel, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, 
                             QPushButton, QLineEdit, QTextEdit, QProgressBar, 
                             QGroupBox, QListWidget, QListWidgetItem, QInputDialog, QMessageBox)
from PyQt6.QtCore import Qt
import config_manager
from hilos.worker_extractor import WorkerExtractor

class VistaExtractor(QWidget):
    def __init__(self, parent_main):
        super().__init__()
        self.parent_main = parent_main
        self.listas_dinamicas = self.parent_main.config_data.get("listas", {})
        self.setup_ui()
        self.poblar_lista_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 20, 30, 20)
        
        g_dinamico = QGroupBox("Gestión Dinámica de Listas (Caché Alto Rendimiento)")
        l_dinamico = QHBoxLayout()
        
        panel_lista = QVBoxLayout()
        self.lista_ui = QListWidget()
        self.lista_ui.setMinimumWidth(200)
        self.lista_ui.setMaximumWidth(280)
        self.lista_ui.itemClicked.connect(self.cargar_detalle_lista)
        self.lista_ui.itemChanged.connect(self.actualizar_estado_checkbox)
        panel_lista.addWidget(self.lista_ui)
        
        row_botones = QHBoxLayout()
        btn_add = QPushButton("+ Añadir Lista")
        btn_add.clicked.connect(self.agregar_lista_nueva)
        btn_remove = QPushButton("- Eliminar")
        btn_remove.clicked.connect(self.eliminar_lista_seleccionada)
        row_botones.addWidget(btn_add)
        row_botones.addWidget(btn_remove)
        panel_lista.addLayout(row_botones)
        l_dinamico.addLayout(panel_lista)
        
        panel_detalle = QWidget()
        f_detalle = QFormLayout(panel_detalle)
        self.txt_lista_archivo = QLineEdit()
        self.txt_lista_alias = QLineEdit()
        self.txt_lista_hoja = QLineEdit()
        self.txt_lista_cols = QLineEdit()

        self.txt_lista_archivo.textChanged.connect(self.guardar_detalle_lista)
        self.txt_lista_alias.textChanged.connect(self.guardar_detalle_lista)
        self.txt_lista_hoja.textChanged.connect(self.guardar_detalle_lista)
        self.txt_lista_cols.textChanged.connect(self.guardar_detalle_lista)

        f_detalle.addRow("Nombre Archivo:", self.txt_lista_archivo)
        f_detalle.addRow("Pestaña Salida (Alias):", self.txt_lista_alias)
        f_detalle.addRow("Hojas (Separar con ','):", self.txt_lista_hoja)
        f_detalle.addRow("Columnas a leer:", self.txt_lista_cols)
        
        l_dinamico.addWidget(panel_detalle)
        g_dinamico.setLayout(l_dinamico)
        layout.addWidget(g_dinamico)
        
        # --- Logs y Ejecución ---
        self.log_ext = QTextEdit()
        self.log_ext.setReadOnly(True)
        self.log_ext.setStyleSheet("background-color: #11111b; color: #a6e3a1; font-family: Consolas;")
        layout.addWidget(self.log_ext)
        
        self.pb_ext = QProgressBar()
        layout.addWidget(self.pb_ext)
        
        self.btn_ejecutar = QPushButton("EJECUTAR CRUCE MASIVO (EXTRACTOR)")
        self.btn_ejecutar.setStyleSheet("background-color: #002060; color: white; font-weight: bold; padding: 12px;")
        self.btn_ejecutar.clicked.connect(self.ejecutar_extractor)
        layout.addWidget(self.btn_ejecutar)
        self.lbl_estado_config = QLabel()
        self.lbl_estado_config.setStyleSheet("font-size: 12px; padding: 5px;")
        layout.addWidget(self.lbl_estado_config)
        
        self.actualizar_estado_config()

    def actualizar_estado_config(self):
        cfg = self.parent_main.config_data
        ruta_listas = cfg.get("ruta_listas", "")
        
        if ruta_listas and os.path.exists(ruta_listas):
            listas_activas = len([c for c in cfg.get('listas', {}).values() if c.get('activo', True)])
            self.lbl_estado_config.setText(f"✅ Listo: {listas_activas} lista(s) activa(s) en {ruta_listas}")
            self.lbl_estado_config.setStyleSheet("color: #a6e3a1; background-color: #1e1e2e; padding: 5px;")
        else:
            self.lbl_estado_config.setText("⚠️ Configuración incompleta: Falta la ruta de listas (ver pestaña Rutas)")
            self.lbl_estado_config.setStyleSheet("color: #f38ba8; background-color: #1e1e2e; padding: 5px;")

    def poblar_lista_ui(self):
        self.lista_ui.blockSignals(True)
        self.lista_ui.clear()
        for nom, datos in self.listas_dinamicas.items():
            item = QListWidgetItem(nom)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked if datos.get("activo", True) else Qt.CheckState.Unchecked)
            self.lista_ui.addItem(item)
        self.lista_ui.blockSignals(False)

    def actualizar_estado_checkbox(self, item):
        nombre = item.text()
        if nombre in self.listas_dinamicas:
            self.listas_dinamicas[nombre]["activo"] = (item.checkState() == Qt.CheckState.Checked)

    def agregar_lista_nueva(self):
        texto, ok = QInputDialog.getText(self, "Nueva Lista", "Nombre identificador:")
        if ok and texto.strip():
            nombre = texto.strip()
            if nombre not in self.listas_dinamicas:
                self.listas_dinamicas[nombre] = {"archivo": "", "hoja": "", "cols": "", "alias": nombre, "activo": True}
                self.poblar_lista_ui()

    def eliminar_lista_seleccionada(self):
        item = self.lista_ui.currentItem()
        if item and QMessageBox.question(self, "Confirmar", f"¿Eliminar '{item.text()}'?") == QMessageBox.StandardButton.Yes:
            del self.listas_dinamicas[item.text()]
            self.poblar_lista_ui()
            self.txt_lista_archivo.clear()
            self.txt_lista_alias.clear()
            self.txt_lista_hoja.clear()
            self.txt_lista_cols.clear()

    def cargar_detalle_lista(self, item):
        datos = self.listas_dinamicas.get(item.text(), {})
        for qline in [self.txt_lista_archivo, self.txt_lista_alias, self.txt_lista_hoja, self.txt_lista_cols]:
            qline.blockSignals(True)
        self.txt_lista_archivo.setText(datos.get("archivo", ""))
        self.txt_lista_alias.setText(datos.get("alias", ""))
        self.txt_lista_hoja.setText(datos.get("hoja", ""))
        self.txt_lista_cols.setText(datos.get("cols", ""))
        for qline in [self.txt_lista_archivo, self.txt_lista_alias, self.txt_lista_hoja, self.txt_lista_cols]:
            qline.blockSignals(False)

    def guardar_detalle_lista(self):
        item = self.lista_ui.currentItem()
        if item:
            self.listas_dinamicas[item.text()].update({
                "archivo": self.txt_lista_archivo.text(),
                "alias": self.txt_lista_alias.text(),
                "hoja": self.txt_lista_hoja.text(),
                "cols": self.txt_lista_cols.text()
            })

    def ejecutar_extractor(self):
        cfg = self.parent_main.config_data
        
        if not cfg.get("ruta_matriz") or not os.path.exists(cfg.get("ruta_matriz")):
            QMessageBox.warning(
                self, 
                "Error de Configuración", 
                "❌ Falta definir el Libro Maestro (Excel Matriz) en la pestaña de Rutas.\n\n"
                "1. Ve a la pestaña '🏠 Rutas Globales'\n"
                "2. Haz clic en 'Examinar' junto a 'Libro Maestro'\n"
                "3. Selecciona el archivo Excel\n"
                "4. Haz clic en 'Guardar Configuración'"
            )
            return
        
        if not cfg.get("ruta_casos") or not os.path.exists(cfg.get("ruta_casos")):
            QMessageBox.warning(
                self, 
                "Error de Configuración", 
                "❌ Falta definir el Directorio Destino (Carpeta de Casos) en la pestaña de Rutas.\n\n"
                "1. Ve a la pestaña '🏠 Rutas Globales'\n"
                "2. Haz clic en 'Examinar' junto a 'Directorio Destino (Casos)'\n"
                "3. Selecciona la carpeta donde están los expedientes\n"
                "4. Haz clic en 'Guardar Configuración'"
            )
            return
        
        if not cfg.get("ruta_listas") or not os.path.exists(cfg.get("ruta_listas")):
            QMessageBox.warning(
                self, 
                "Error de Configuración", 
                "❌ Falta definir el Directorio de Listas (Excel/CSV) en la pestaña de Rutas.\n\n"
                "1. Ve a la pestaña '🏠 Rutas Globales'\n"
                "2. Busca la sección 'Directorio de Listas (Excel/CSV)'\n"
                "3. Haz clic en 'Examinar' y selecciona la carpeta donde están tus listas\n"
                "4. Haz clic en 'Guardar Configuración'\n\n"
                "📁 Las listas deben ser archivos .xlsx, .xls, .csv o .xlsb"
            )
            return
        
        listas_activas = {nom: c for nom, c in cfg.get('listas', {}).items() if c.get('activo', True)}
        if not listas_activas:
            reply = QMessageBox.question(
                self,
                "Sin Listas Activas",
                "⚠️ No hay ninguna lista activa para el cruce.\n\n"
                "¿Deseas ir a la sección de Gestión de Listas para activar alguna?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                self.parent_main.change_page(1)
            return
        
        cfg["listas"] = self.listas_dinamicas
        config_manager.guardar_memoria(cfg)
        
        self.btn_ejecutar.setEnabled(False)
        self.log_ext.clear()
        self.pb_ext.setRange(0, 100)
        self.pb_ext.setValue(0)
        
        self.worker = WorkerExtractor(cfg)
        self.worker.log_signal.connect(self.log_ext.append)
        self.worker.progress_signal.connect(lambda v: self.pb_ext.setValue(int(v * 100)) if v >= 0 else self.pb_ext.setValue(0))
        self.worker.error_signal.connect(lambda e: self.log_ext.append(f"[ERROR FATAL] {e}"))
        self.worker.finished_signal.connect(lambda: self.btn_ejecutar.setEnabled(True))
        self.worker.start()