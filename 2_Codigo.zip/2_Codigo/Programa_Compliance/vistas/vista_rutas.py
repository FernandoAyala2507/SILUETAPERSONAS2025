from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, 
                             QFormLayout, QLabel, QLineEdit, QPushButton, 
                             QFileDialog, QMessageBox, QGroupBox)
from PyQt6.QtCore import Qt
import config_manager
import os
import openpyxl

class VistaRutas(QWidget):
    def __init__(self, parent_main):
        super().__init__()
        self.parent_main = parent_main
        self.setup_ui()
        self.cargar_datos()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 30, 40, 30)

        # ==========================================
        # BLOQUE 1: DIRECTORIOS FÍSICOS
        # ==========================================
        group_rutas = QGroupBox("📁 Configuración Global de Directorios")
        layout_rutas = QGridLayout()
        layout_rutas.setContentsMargins(20, 25, 20, 20)
        layout_rutas.setSpacing(15)
        
        self.entry_matriz = self._crear_fila_ruta(layout_rutas, 0, "Libro Maestro (.xlsx):", self.seleccionar_matriz)
        self.entry_casos = self._crear_fila_ruta(layout_rutas, 1, "Directorio Destino (Casos):", self.seleccionar_casos)
        self.entry_eecc = self._crear_fila_ruta(layout_rutas, 2, "Directorio Origen (EECC):", self.seleccionar_eecc)
        self.entry_formatos = self._crear_fila_ruta(layout_rutas, 3, "Directorio Plantillas Word:", self.seleccionar_formatos)
        self.entry_listas = self._crear_fila_ruta(layout_rutas, 4, "Directorio de Listas (Excel/CSV):", self.seleccionar_listas) 
       
        group_rutas.setLayout(layout_rutas)
        layout.addWidget(group_rutas)

        # ==========================================
        # BLOQUE 2: ESTRUCTURA DINÁMICA DEL EXCEL
        # ==========================================
        group_excel = QGroupBox("📊 Estructura Dinámica de la Matriz")
        f_excel = QFormLayout()
        f_excel.setContentsMargins(20, 25, 20, 20)
        f_excel.setVerticalSpacing(12)

        self.txt_pestana = QLineEdit()
        self.txt_col_car = QLineEdit()
        self.txt_col_doi = QLineEdit()
        self.txt_col_nom = QLineEdit()
        self.txt_col_mes = QLineEdit() 
        self.txt_col_tipo = QLineEdit()

        self.txt_col_mes.setPlaceholderText("Ej: B")
        self.txt_col_tipo.setPlaceholderText("Ej: C (Identificador PN / PJ)")

        f_excel.addRow("Nombre de la Pestaña a leer:", self.txt_pestana)
        f_excel.addRow("Letra Columna - N° de Carpeta:", self.txt_col_car)
        f_excel.addRow("Letra Columna - DOI / RUC:", self.txt_col_doi)
        f_excel.addRow("Letra Columna - Nombres:", self.txt_col_nom)
        f_excel.addRow("Letra Columna - Mes de Eval.:", self.txt_col_mes)
        f_excel.addRow("Letra Columna - Tipo (PN/PJ):", self.txt_col_tipo)

        group_excel.setLayout(f_excel)
        layout.addWidget(group_excel)
        
        # ==========================================
        # BOTONES DE ACCIÓN
        # ==========================================
        row_botones = QHBoxLayout()
        
        self.btn_crear_carpetas = QPushButton("📁 Crear Carpetas Manualmente")
        self.btn_crear_carpetas.setStyleSheet("background-color: #313244; color: #a6adc8; font-weight: bold; padding: 10px;")
        self.btn_crear_carpetas.clicked.connect(self.crear_carpetas_manual)
        
        self.btn_guardar = QPushButton("💾 Guardar Configuración")
        self.btn_guardar.setStyleSheet("background-color: #89b4fa; color: #11111b; font-weight: bold; padding: 10px;")
        self.btn_guardar.clicked.connect(self.guardar_rutas)
        
        row_botones.addWidget(self.btn_crear_carpetas)
        row_botones.addStretch()
        row_botones.addWidget(self.btn_guardar)
        
        layout.addLayout(row_botones)
        layout.addStretch()

    def _crear_fila_ruta(self, layout, row, texto_label, callback):
        lbl = QLabel(texto_label)
        layout.addWidget(lbl, row, 0)
        entry = QLineEdit()
        layout.addWidget(entry, row, 1)
        btn = QPushButton("Examinar")
        btn.clicked.connect(callback)
        layout.addWidget(btn, row, 2)
        return entry

    def seleccionar_matriz(self):
        ruta, _ = QFileDialog.getOpenFileName(self, "Seleccionar Libro Maestro", "", "Excel Files (*.xlsx)")
        if ruta: self.entry_matriz.setText(ruta)

    def seleccionar_casos(self):
        ruta = QFileDialog.getExistingDirectory(self, "Seleccionar Carpeta")
        if ruta: self.entry_casos.setText(ruta)

    def seleccionar_eecc(self):
        ruta = QFileDialog.getExistingDirectory(self, "Seleccionar Carpeta")
        if ruta: self.entry_eecc.setText(ruta)

    def seleccionar_formatos(self):
        ruta = QFileDialog.getExistingDirectory(self, "Seleccionar Carpeta de Plantillas Word")
        if ruta: self.entry_formatos.setText(ruta)
        
    def seleccionar_listas(self):
        ruta = QFileDialog.getExistingDirectory(self, "Seleccionar Carpeta de Listas (Excel/CSV)")
        if ruta: self.entry_listas.setText(ruta)

    def cargar_datos(self):
        config = self.parent_main.config_data
        
        self.entry_matriz.setText(config.get("ruta_matriz", ""))
        self.entry_casos.setText(config.get("ruta_casos", ""))
        self.entry_eecc.setText(config.get("ruta_eecc", ""))
        self.entry_formatos.setText(config.get("ruta_formatos", "")) 
        self.entry_listas.setText(config.get("ruta_listas", ""))
        
        self.txt_pestana.setText(config.get("matriz_pestana", "DDR_ANUAL"))
        self.txt_col_car.setText(config.get("matriz_col_car", "A"))
        self.txt_col_doi.setText(config.get("matriz_col_doi", "AD"))
        self.txt_col_nom.setText(config.get("matriz_col_nom", "C"))
        self.txt_col_mes.setText(config.get("matriz_col_mes", "B"))
        self.txt_col_tipo.setText(config.get("matriz_col_tipo", "D")) 

    def guardar_rutas(self):
        self.parent_main.config_data.update({
            "ruta_matriz": self.entry_matriz.text(),
            "ruta_casos": self.entry_casos.text(),
            "ruta_eecc": self.entry_eecc.text(),
            "ruta_formatos": self.entry_formatos.text(),
            "ruta_listas": self.entry_listas.text(),
            
            "matriz_pestana": self.txt_pestana.text().strip(),
            "matriz_col_car": self.txt_col_car.text().strip().upper(),
            "matriz_col_doi": self.txt_col_doi.text().strip().upper(),
            "matriz_col_nom": self.txt_col_nom.text().strip().upper(),
            "matriz_col_mes": self.txt_col_mes.text().strip().upper(),
            "matriz_col_tipo": self.txt_col_tipo.text().strip().upper()
        })
        config_manager.guardar_memoria(self.parent_main.config_data)
        QMessageBox.information(self, "Éxito", "Configuración persistida correctamente. Todos los módulos usarán estas reglas.")

    def crear_carpetas_manual(self):
        matriz = self.entry_matriz.text()
        destino = self.entry_casos.text()
        pestana = self.txt_pestana.text().strip()
        col_letra = self.txt_col_car.text().strip().upper()

        if not matriz or not destino:
            return QMessageBox.warning(self, "Faltan Parámetros", "Indica el Excel Matriz y el Directorio Destino.")
        
        try:
            wb = openpyxl.load_workbook(matriz, data_only=True)
            if pestana not in wb.sheetnames:
                wb.close()
                return QMessageBox.warning(self, "Error", f"La pestaña '{pestana}' no existe.")

            ws = wb[pestana]
            creadas = 0
            for cell in ws[col_letra]:
                if cell.row == 1:
                    continue
                n_carpeta = str(cell.value).strip()
                if n_carpeta and n_carpeta.upper() not in ["NONE", "NAN", "", "0"]:
                    ruta_completa = os.path.join(destino, n_carpeta)
                    if not os.path.exists(ruta_completa):
                        os.makedirs(ruta_completa, exist_ok=True)
                        creadas += 1
            wb.close()
            QMessageBox.information(self, "Listo", f"Se crearon {creadas} carpetas basadas en la columna {col_letra}.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Fallo al leer matriz:\n{str(e)}")