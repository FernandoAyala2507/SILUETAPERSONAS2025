# -*- mode: python ; coding: utf-8 -*-

import os
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

BASE_DIR = os.path.abspath(os.path.dirname(SPEC))

block_cipher = None

hidden_imports = [
    'pandas',
    'openpyxl',
    'pdfplumber',
    'pdfminer',
    'pdfminer.six',
    'fitz',
    'pypdf',
    'playwright',
    'docx',
    'python-docx',
    'winreg',
    'pyxlsb',
    'xlrd',
    'PyQt6.QtCore',
    'PyQt6.QtGui',
    'PyQt6.QtWidgets',
    'pyarrow',
    'fastparquet',
    'PIL',
    'PIL.Image',
]

for pkg in ['modulos', 'vistas', 'hilos', 'utils']:
    hidden_imports += collect_submodules(pkg)

datas = [
    ('logo.ico', '.'),
    ('ubigeos_map.json', '.'),
]
datas += collect_data_files('playwright')

a = Analysis(
    ['main.py'],
    pathex=[BASE_DIR],
    binaries=[],
    datas=datas,
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['matplotlib', 'tkinter', 'IPython', 'jupyter', 'notebook'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Programa_Compliance',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='logo.ico',
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Programa_Compliance',
)