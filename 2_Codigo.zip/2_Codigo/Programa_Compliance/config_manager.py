import os
import json

ARCHIVO_MEMORIA = "config_app.json"

DEFAULT_LISTAS = {
    "Base CAF - Emp. Vinculadas": {"archivo": "Base CAF - Empresas vinculadas", "hoja": "UNICA", "cols": "F", "alias": "CAF Emp Vinc", "activo": True},
    "Base Parientes PEP": {"archivo": "Base Parientes PEP", "hoja": "Lista Parientes PEP parte 2", "cols": "E", "alias": "Parientes PEP", "activo": True},
    "Base Riesgo Crediticio": {"archivo": "Base Riesgo Crediticio", "hoja": "PN(BRC)", "cols": "H", "alias": "Riesgo Cred", "activo": True},
    "Lista CAF": {"archivo": "Lista CAF", "hoja": "CONGELAMIENTOS UIF", "cols": "D, G", "alias": "Lista CAF", "activo": True},
    "Lista Cumplimiento": {"archivo": "Lista Cumplimiento", "hoja": "LISTA CUMPLIMIENTO", "cols": "G", "alias": "Cumplimiento", "activo": True},
    "Lista Interna Recompensas": {"archivo": "Lista Interna Recompensas", "hoja": "UNICA", "cols": "E", "alias": "Recompensas", "activo": True},
    "Lista Ley 30737": {"archivo": "Lista Ley 30737", "hoja": "Categoria 1, Categoría 2, Categoría 3", "cols": "C - D - F", "alias": "Ley 30737", "activo": True},
    "Lista Noticias": {"archivo": "Lista Noticias", "hoja": "LISTA NOTICIAS", "cols": "I", "alias": "Noticias", "activo": True},
    "Lista PEP": {"archivo": "Lista PEP", "hoja": "Lista PEP", "cols": "D", "alias": "Lista PEP", "activo": True},
    "Lista Fraude": {"archivo": "Lista Fraude", "hoja": "Nueva lista desde julio 2022", "cols": "E", "alias": "Fraude", "activo": True},
    "Base Reportes Operaciones": {"archivo": "3_RO - 012022 - 022026_ACTUAL", "hoja": "2025_2026", "cols": "N, O - AF, AG", "alias": "Base RO", "activo": True},
    "Inventario CARS": {"archivo": "Inventario CARS", "hoja": "2018-2026", "cols": "F", "alias": "CARS", "activo": True}
}

def cargar_memoria():
    if os.path.exists(ARCHIVO_MEMORIA):
        with open(ARCHIVO_MEMORIA, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if "listas" not in data or not data["listas"]:
                data["listas"] = DEFAULT_LISTAS.copy()
            return data
    return {"listas": DEFAULT_LISTAS.copy()}

def guardar_memoria(data):
    with open(ARCHIVO_MEMORIA, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4)