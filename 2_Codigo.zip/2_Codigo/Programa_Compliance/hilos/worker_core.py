import sys
from PyQt6.QtCore import QThread, pyqtSignal

from modulos.modulo_sunat import ExtractorSUNAT
from modulos.modulo_eecc import OrquestadorEECC
from modulos.modulo_sentinel import ExtractorSentinel
from modulos.modulo_gesintel import ExtractorGesintel
from modulos.modulo_word import GeneradorWordMasivo
from modulos.orquestador_lsb import MotorAnalisisLSB

class StreamRedirector:
    def __init__(self, signal):
        self.signal = signal
    def write(self, text):
        if text.strip(): 
            self.signal.emit(text.strip())
    def flush(self):
        pass

class WorkerThreadCore(QThread):
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()
    error_signal = pyqtSignal(str)

    def __init__(self, config):
        super().__init__()
        self.config = config

    def run(self):
        original_stdout = sys.stdout 
        try:
            sys.stdout = StreamRedirector(self.log_signal)
            
            print(f"🚀 Iniciando Pipeline de Compliance. Periodo: {self.config.get('MES')}")
            
            if self.config.get("EJECUTAR_EECC"):
                print("\n[INFO] Ejecutando módulo de Estados de Cuenta...")
                motor_eecc = OrquestadorEECC(self.config)
                motor_eecc.ejecutar()
            
            if self.config.get("EJECUTAR_SUNAT"):
                print("\n[INFO] Ejecutando módulo SUNAT...")
                motor_sunat = ExtractorSUNAT(self.config)
                motor_sunat.ejecutar()

            if self.config.get("EJECUTAR_SENTINEL"):
                print("\n[INFO] Ejecutando módulo SENTINEL...")
                motor_sentinel = ExtractorSentinel(self.config)
                motor_sentinel.ejecutar()

            if self.config.get("EJECUTAR_GESINTEL"):
                print("\n[INFO] Ejecutando módulo GESINTEL...")
                motor_gesintel = ExtractorGesintel(self.config)
                motor_gesintel.ejecutar()

            if self.config.get("EJECUTAR_MOTOR"):
                print("\n[INFO] Ejecutando Motor Analítico LSB (Finanzas)...")
                motor_lsb = MotorAnalisisLSB(self.config)
                motor_lsb.ejecutar()

            if self.config.get("EJECUTAR_WORD"):
                print("\n[INFO] Autocompletando plantillas Word institucionales...")
                motor_word = GeneradorWordMasivo(self.config)
                motor_word.ejecutar()
            
        except Exception as e:
            self.error_signal.emit(str(e))
            import traceback
            traceback.print_exc()
        finally:
            sys.stdout = original_stdout
            self.finished_signal.emit()