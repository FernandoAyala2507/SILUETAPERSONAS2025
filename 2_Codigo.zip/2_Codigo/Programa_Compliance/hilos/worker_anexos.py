import sys
from PyQt6.QtCore import QThread, pyqtSignal
from modulos.modulo_anexos import MotorAnexosCore

class StreamRedirector:
    def __init__(self, signal):
        self.signal = signal
    def write(self, text):
        if text.strip(): self.signal.emit(text.strip())
    def flush(self): pass

class WorkerAnexos(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(float)
    finished_signal = pyqtSignal()
    error_signal = pyqtSignal(str)

    def __init__(self, config):
        super().__init__()
        self.config = config

    def run(self):
        original_stdout = sys.stdout 
        try:
            sys.stdout = StreamRedirector(self.log_signal)
            motor = MotorAnexosCore(self.config)
            motor.ejecutar(callback_progreso=self.progress_signal.emit)
            
        except Exception as e:
            self.error_signal.emit(str(e))
        finally:
            sys.stdout = original_stdout
            self.finished_signal.emit()