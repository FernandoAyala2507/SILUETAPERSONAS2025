import os
import re
import gc
import fitz
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from utils.conversor_columnas import ConversorColumnas

class ExtractorSUNAT:
    def __init__(self, config: dict):
        self.cfg = config
        self.ruta_matriz = config.get("ruta_matriz")
        self.ruta_carpetas = config.get("ruta_casos")
        
        mes_raw = config.get("MES", "")
        self.mes = str(mes_raw).strip().upper()
        self.pestana = config.get("matriz_pestana", "DDR_ANUAL")
        self.col_car = config.get("matriz_col_car", "A").upper()
        self.col_doi = config.get("matriz_col_doi", "AD").upper()
        self.col_mes = config.get("matriz_col_mes", "B").upper()

    def log(self, mensaje: str):
        print(f"[ExtractorSUNAT] > {mensaje}")

    def evaluar_documento(self, ruta_pdf: str):
        try:
            with fitz.open(ruta_pdf) as doc:
                texto_pagina_inicial = doc[0].get_text("text").strip()
                lineas_iniciales = texto_pagina_inicial.split('\n')
                
                es_sunat = any("SUNAT" in linea.upper() or "CONSULTA RUC" in linea.upper() for linea in lineas_iniciales[:4])
                if not es_sunat:
                    return "NO_ES_SUNAT", None
                
                if "EL SISTEMA RUC NO REGISTRA" in texto_pagina_inicial.upper():
                    return "NO_REGISTRA", None
                
                texto_limpio = []
                for pagina in doc:
                    lineas = pagina.get_text("text").split('\n')
                    for linea in lineas:
                        L = linea.strip()
                        if not L:
                            continue 
                        if re.match(r"^\d{1,2}/\d{1,2}/\d{2,4},\s*\d{1,2}:\d{2}\s*[AP]M", L, re.IGNORECASE):
                            continue
                        if "SUNAT - Consulta RUC" in L:
                            continue
                        if "SUNAT Derechos Reservados" in L or "©" in L:
                            continue
                        if "e-consultaruc.sunat.gob.pe" in L or re.match(r"^https?://", L):
                            continue
                            
                        texto_limpio.append(L)
                        
                texto_completo = "\n".join(texto_limpio)
                return "VALIDO", texto_completo
                
        except Exception as e:
            self.log(f"Error procesando documento {ruta_pdf}: {e}")
            return "ERROR", None

    def extraer_datos(self, texto: str):
        campos = [
            "Número de RUC:", "Tipo Contribuyente:", "Tipo de Documento:", "Nombre Comercial:",
            "Fecha de Inscripción:", "Fecha de Inicio de Actividades:", "Estado del Contribuyente:",
            "Condición del Contribuyente:", "Domicilio Fiscal:", "Sistema Emisión de Comprobante:",
            "Actividad Comercio Exterior:", "Sistema Contabilidad:", "Actividad(es) Económica(s):",
            "Comprobantes de Pago c/aut. de impresión (F. 806 u 816):", "Sistema de Emisión Electrónica:",
            "Emisor electrónico desde:", "Comprobantes Electrónicos:", "Afiliado al PLE desde:", "Padrones:"
        ]

        limite_parada = "|".join([re.escape(c) for c in campos])
        resultados = {}
        
        for campo in campos:
            patron = f"{re.escape(campo)}(.*?)(?={limite_parada}|$)"
            match = re.search(patron, texto, re.DOTALL | re.IGNORECASE)
            nombre_columna = campo.replace(":", "").strip()
            
            if match:
                valor = match.group(1).replace("\n", " ").strip()
                if nombre_columna == "Actividad(es) Económica(s)":
                    valor = re.sub(r'\s*(Secundaria \d+|Terciaria \d+)', r'\n\1', valor)
                    valor = valor.strip()
                resultados[nombre_columna] = valor if valor else "N/A"
            else:
                resultados[nombre_columna] = "N/A"
                
        return resultados

    def actualizar_matriz_excel(self, todos_los_datos: list):
        df_nuevos = pd.DataFrame(todos_los_datos)
        nombre_pestana = 'SUNAT_Extraido'
        
        try:
            with pd.ExcelWriter(self.ruta_matriz, engine='openpyxl', mode='a', if_sheet_exists='overlay') as writer:
                if nombre_pestana in writer.book.sheetnames:
                    startrow = writer.book[nombre_pestana].max_row
                    df_nuevos.to_excel(writer, index=False, header=False, sheet_name=nombre_pestana, startrow=startrow)
                else:
                    df_nuevos.to_excel(writer, index=False, sheet_name=nombre_pestana)
            
            wb = load_workbook(self.ruta_matriz)
            ws = wb[nombre_pestana]
            
            azul_fill = PatternFill(start_color='002060', end_color='002060', fill_type='solid')
            blanco_font = Font(color='FFFFFF', bold=True)
            
            for cell in ws[1]:
                cell.fill = azul_fill
                cell.font = blanco_font
                cell.alignment = Alignment(horizontal='center', vertical='center')
                
            for row in ws.iter_rows(min_row=2):
                for cell in row:
                    cell.alignment = Alignment(wrap_text=True, vertical='top')
            
            wb.save(self.ruta_matriz)
            wb.close()
        except Exception as e:
            self.log(f"Error de I/O en Matriz Excel: {e}")
            raise

    def ejecutar(self):
        if not self.ruta_matriz or not os.path.isfile(self.ruta_matriz):
            self.log("Excepción: Ruta de Matriz no existe.")
            return
        if not self.ruta_carpetas or not os.path.isdir(self.ruta_carpetas):
            self.log("Excepción: Directorio Destino no existe.")
            return

        self.log(f"Lectura Pestaña: {self.pestana}... Filtro: {self.mes}")
        
        try:
            df_matriz = pd.read_excel(self.ruta_matriz, sheet_name=self.pestana, dtype=str)
            
            try:
                idx_mes = ConversorColumnas.col_a_indice(self.col_mes)
                columna_mes_datos = df_matriz.iloc[:, idx_mes].astype(str).str.strip().str.upper()
                df_filtrado = df_matriz[columna_mes_datos == self.mes]
            except IndexError:
                self.log(f"ALERTA: La columna de mes '{self.col_mes}' está fuera del rango. Procesando todos.")
                df_filtrado = df_matriz
            
            if df_filtrado.empty:
                self.log("Sin Hallazgos para este Mes.")
                return
                
            self.log(f"Encontrados {len(df_filtrado)} expedientes. Iniciando barrido documental...")
            
            idx_car = ConversorColumnas.col_a_indice(self.col_car)
            idx_doi = ConversorColumnas.col_a_indice(self.col_doi)

            datos_recolectados = []
            documentos_procesados = 0

            for index, row in df_filtrado.iterrows():
                try:
                    n_caso = str(row.iloc[idx_car]).strip()
                    doi = str(row.iloc[idx_doi]).strip()
                except IndexError:
                    continue 
                
                if n_caso.lower() in ["nan", "none", ""]:
                    continue

                ruta_carpeta_caso = os.path.join(self.ruta_carpetas, n_caso)
                if not os.path.isdir(ruta_carpeta_caso):
                    continue
                
                archivos_en_carpeta = os.listdir(ruta_carpeta_caso)
                patron_busqueda = rf'^{re.escape(doi)}(?:[\s\-_].*)?\.pdf$'
                
                for file in archivos_en_carpeta:
                    if re.match(patron_busqueda, file, re.IGNORECASE):
                        ruta_pdf = os.path.join(ruta_carpeta_caso, file)
                        estado, texto = self.evaluar_documento(ruta_pdf)
                        
                        if estado == "NO_ES_SUNAT":
                            continue 
                        
                        if estado == "NO_REGISTRA":
                            datos_recolectados.append({"N°_CASO": n_caso, "DOI (Buscado)": doi, "Archivo Origen": file, "Número de RUC": "NO REGISTRA"})
                        elif estado == "VALIDO":
                            data_extraida = self.extraer_datos(texto)
                            data_extraida["N°_CASO"] = n_caso
                            data_extraida["DOI (Buscado)"] = doi
                            data_extraida["Archivo Origen"] = file
                            datos_recolectados.append(data_extraida)
                            
                        documentos_procesados += 1
                        del texto
                        gc.collect()

            if datos_recolectados:
                self.log("Persistiendo estructuración en el Libro Maestro...")
                df_consolidado = pd.DataFrame(datos_recolectados)
                cols_pivote = ["N°_CASO", "DOI (Buscado)", "Archivo Origen", "Número de RUC"]
                cols_extraidas = [col for col in df_consolidado.columns if col not in cols_pivote]
                df_consolidado = df_consolidado[cols_pivote + cols_extraidas]
                df_consolidado.fillna("--", inplace=True)
                self.actualizar_matriz_excel(df_consolidado.to_dict('records'))
                self.log(f"--- PROCESO SATISFACTORIO ({documentos_procesados} Fichas Auditadas) ---")
            else:
                self.log("Proceso finalizado. Sin hallazgos.")
        except Exception as e:
            self.log(f"ERROR CRÍTICO PIPELINE: {e}")
            import traceback
            traceback.print_exc()