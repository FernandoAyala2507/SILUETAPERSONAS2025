import fitz
import os
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
from utils.conversor_columnas import ConversorColumnas

class ExtractorGesintel:
    def __init__(self, config: dict):
        self.ruta_matriz = config.get("ruta_matriz", "")
        self.ruta_casos_destino = config.get("ruta_casos", "")
        
        self.pestana = config.get("matriz_pestana", "DDR_ANUAL")
        self.col_car = config.get("matriz_col_car", "A")
        self.col_doi = config.get("matriz_col_doi", "AD")
        self.col_mes = config.get("matriz_col_mes", "B")
        self.mes_seleccionado = config.get("MES", "")
        
        self.datos_finales = []
        self.mapa_doi = {}
        self.diccionario_siglas = {
            "PEPT": "Personas Expuestas Políticamente Titular", "RCAT": "Relacionados con Titular",
            "ASOCT": "Asociados con Titular", "PEPI": "Personas Expuestas Políticamente Internacional",
            "RCAI": "Relacionado a Internacional", "SAN": "Lista de Sanciones Internacionales (OFAC - ONU)",
            "PEPC": "Personas Expuestas Políticamente Candidatos", "RCAC": "Relacionados con Candidatos",
            "PEPH": "Personas Expuestas Políticamente Histórico", "RCAH": "Relacionados con PEP Históricos",
            "ASOCH": "Asociados con PEP Históricos", "BPI": "Personas de Interés",
            "BRD": "Board Member", "SOC": "State Owned Company", "SI": "Interés Especial",
            "OOL": "Otros Listados Oficiales", "NEG": "Listas de Negatividad", "VIP": "Personal Altamente Influyente"
        }

    def _es_mes_valido(self, valor_celda):
        if not self.mes_seleccionado:
            return True
        mes_str = str(valor_celda).strip().upper().split('.')[0]
        
        mapa_meses = {
            "ENERO": ["ENERO", "1", "01"], "FEBRERO": ["FEBRERO", "2", "02"],
            "MARZO": ["MARZO", "3", "03"], "ABRIL": ["ABRIL", "4", "04"],
            "MAYO": ["MAYO", "5", "05"], "JUNIO": ["JUNIO", "6", "06"],
            "JULIO": ["JULIO", "7", "07"], "AGOSTO": ["AGOSTO", "8", "08"],
            "SEPTIEMBRE": ["SEPTIEMBRE", "9", "09"], "OCTUBRE": ["OCTUBRE", "10", "10"],
            "NOVIEMBRE": ["NOVIEMBRE", "11", "11"], "DICIEMBRE": ["DICIEMBRE", "12", "12"]
        }
        permitidos = mapa_meses.get(self.mes_seleccionado, [self.mes_seleccionado])
        return mes_str in permitidos

    def cargar_mapeo_doi(self):
        if not os.path.exists(self.ruta_matriz):
            print(f"[ERROR] No existe la matriz: {self.ruta_matriz}")
            return False
        try:
            df_ddr = pd.read_excel(self.ruta_matriz, sheet_name=self.pestana, dtype=str)
            idx_car = ConversorColumnas.col_a_indice(self.col_car)
            idx_doi = ConversorColumnas.col_a_indice(self.col_doi)
            idx_mes = ConversorColumnas.col_a_indice(self.col_mes)
            
            for _, fila in df_ddr.iterrows():
                try:
                    carpeta = str(fila.iloc[idx_car]).strip()
                    doi = str(fila.iloc[idx_doi]).strip().split('.')[0]
                    mes_celda = str(fila.iloc[idx_mes]).strip()
                    
                    if carpeta.lower() not in ["nan", "none", ""] and doi.lower() not in ["nan", "none", ""]:
                        if self._es_mes_valido(mes_celda):
                            self.mapa_doi[carpeta] = doi
                except IndexError:
                    continue
            return True
        except Exception as e:
            print(f"[ERROR] Gesintel Matriz: {e}")
            return False

    def ejecutar(self):
        print(f"\n--- Iniciando Módulo Gesintel (Filtro: {self.mes_seleccionado}) ---")
        
        if not self.ruta_matriz or not os.path.exists(self.ruta_matriz):
            print("[ERROR] No se encuentra el Libro Maestro")
            return
            
        if not self.ruta_casos_destino or not os.path.exists(self.ruta_casos_destino):
            print("[ERROR] No se encuentra el directorio de casos")
            return
            
        if not self.cargar_mapeo_doi():
            print("[ERROR] No se pudo cargar el mapeo de DOI")
            return

        carpetas = [f for f in os.listdir(self.ruta_casos_destino) if os.path.isdir(os.path.join(self.ruta_casos_destino, f))]
        
        procesados = 0
        for carpeta in carpetas:
            doi_esperado = self.mapa_doi.get(carpeta)
            if not doi_esperado:
                continue

            ruta_folder = os.path.join(self.ruta_casos_destino, carpeta)
            for archivo in os.listdir(ruta_folder):
                if archivo.lower().endswith(".pdf"):
                    self.procesar_pdf(os.path.join(ruta_folder, archivo), carpeta, doi_esperado)
                    procesados += 1
        
        if procesados > 0:
            self.guardar_en_maestro()
        else:
            print("[INFO] No se encontraron documentos Gesintel para procesar")

    def procesar_pdf(self, ruta_pdf, id_carpeta, doi_esperado):
        try:
            doc = fitz.open(ruta_pdf)
            texto_completo = ""
            for pagina in doc:
                texto_completo += pagina.get_text("text") + "\n"
            
            texto_upper = texto_completo.upper()
            if not ("GESINTEL" in texto_upper or "DUE DILIGENCE" in texto_upper):
                doc.close()
                return
                
            if doi_esperado not in texto_completo:
                if " ".join(list(doi_esperado)) not in texto_completo:
                    doc.close()
                    return

            print(f"   -> Procesando Gesintel: {os.path.basename(ruta_pdf)}")

            res_interno, res_siglas = "", ""
            lineas = [linea.strip() for linea in texto_completo.split('\n') if linea.strip()]
            
            if "Listas Propias" in texto_completo:
                for i, linea in enumerate(lineas):
                    if "Listas Propias" in linea:
                        bloque_proximo = " ".join(lineas[i:i+5])
                        if "Primario" in bloque_proximo:
                            res_interno = "Match en listas internas"
                            break
            
            leyendo_match = False
            siglas_encontradas = []
            for linea in lineas:
                if "Con Match" in linea:
                    leyendo_match = True
                    continue
                if "Sin Match" in linea and leyendo_match:
                    break
                
                if leyendo_match:
                    palabras = linea.replace(",", " ").replace(".", " ").split()
                    for p in palabras:
                        if p in self.diccionario_siglas and p not in siglas_encontradas:
                            siglas_encontradas.append(p)

            if siglas_encontradas:
                res_siglas = " | ".join([f"Match {s} - {self.diccionario_siglas[s]}" for s in siglas_encontradas])

            if res_interno or res_siglas:
                self.datos_finales.append({"CARPETA_ID": id_carpeta, "LISTAS_INTERNAS": res_interno, "HALLAZGOS_GESINTEL": res_siglas})
            doc.close()
        except Exception as e:
            print(f"   [!] Error en {os.path.basename(ruta_pdf)}: {e}")

    def guardar_en_maestro(self):
        if not self.datos_finales:
            return
        df = pd.DataFrame(self.datos_finales)
        nombre_hoja = "GESINTEL"
        try:
            with pd.ExcelWriter(self.ruta_matriz, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                df.to_excel(writer, sheet_name=nombre_hoja, index=False)
            
            wb = load_workbook(self.ruta_matriz)
            ws = wb[nombre_hoja]
            fill_azul = PatternFill(start_color="002060", end_color="002060", fill_type="solid")
            font_blanca = Font(color="FFFFFF", bold=True)
            for cell in ws[1]:
                cell.fill, cell.font = fill_azul, font_blanca
            wb.save(self.ruta_matriz)
            print(f">>> Gesintel guardado exitosamente.")
        except Exception as e:
            print(f"[ERROR EXCEL] {e}")