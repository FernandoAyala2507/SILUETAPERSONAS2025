import pdfplumber
import os
import re
import logging
import pandas as pd
logging.getLogger("pdfminer").setLevel(logging.ERROR)

class ProcesadorSentinel:
    def __init__(self):
        self.TOLERANCIA_Y = 4
        self.X_INICIO = 373
        self.X_FIN = 400
        self.MARGEN_VERTICAL = 7
        
        # --- COORDENADAS DE TABLA DE DEUDAS ---
        self.INICIO_X_TABLA = 32.15          
        self.ANCHO_COL_1 = 80      
        self.ANCHO_TIPO_A = 39.5      
        self.ANCHO_TIPO_B = 23.7      
        self.ANCHO_TIPO_C = 16 
        
        self.lineas_x = [self.INICIO_X_TABLA]
        pos = self.INICIO_X_TABLA + self.ANCHO_COL_1
        self.lineas_x.append(pos)
        for _ in range(6):
            pos += self.ANCHO_TIPO_A
            self.lineas_x.append(pos)
            pos += self.ANCHO_TIPO_B
            self.lineas_x.append(pos)
            pos += self.ANCHO_TIPO_C
            self.lineas_x.append(pos)
            
        # --- COORDENADAS SEMÁFORO ---
        self.SEM_INICIO_X = 39.5
        self.SEM_ANCHO_COL_1 = 13.0
        self.SEM_ANCHO_COL_2 = 15.0
        self.SEM_OFFSET_Y = 4.0
        self.SEM_ALTO_FILA = 11.6
        self.SEM_RESULTADOS = {
            0: "Gris, No registra informacion de deudas",
            1: "Verde, Mínimo riesgo, Sin deudas vencidas",
            2: "Amarillo, Mediano Riesgo, Deudas con poco atraso",
            3: "Rojo, Alto Riesgo, Deudas con atraso significativo"
        }
        
        # === CAMBIO 1: RE_RESUMEN tolerante a DNI (8) y RUC (11) ===
        self.RE_RESUMEN = re.compile(
            r"(\d{2}/\d{2}/\d{4})\s+([A-Z]{3})\s+(\d{8,11})\s+(.*?)\s+(\d\.\d{3})\s+([\d,]+\.\d{2})"
        )
        
        self.RE_MONTO = re.compile(r"^\d{1,3}(?:,\d{3})*\.\d{2}$|^0\.00$")
        self.RE_PORCENTAJE = re.compile(r"^(100|[1-9]?\d)%$")
        
        self.RE_REP_NATURAL = re.compile(r"\b(\d{8}|\d{11})\b\s+([A-ZÑa-zñ\s\.\,]+?)\s+(\d{2}/\d{2}/\d{2,4})\s+(.+)")
        self.RE_REP_JURIDICA = re.compile(r"\b([A-Za-z0-9]{8,15})\b\s+([A-ZÑa-zñ\s\.\,]+?)\s+(\d{2}/\d{2}/\d{2,4})\s+(.+)")

    def _obtener_columna(self, x_centro):
        for i in range(len(self.lineas_x) - 1):
            if self.lineas_x[i] <= x_centro <= self.lineas_x[i+1]:
                return i + 1
        return None

    def limpiar_riesgo_jerarquico(self, historial_crudo):
        if not historial_crudo or historial_crudo == "No registra":
            return "NORMAL"
        mapa_riesgo = {"NOR": "NORMAL", "CPP": "CON PROBLEMAS POTENCIALES", "DEF": "DEFICIENTE", "DUD": "DUDOSO", "PER": "PÉRDIDA"}
        siglas = re.findall(r'\b(NOR|CPP|DEF|DUD|PER)\b', historial_crudo)
        if not siglas:
            return "NORMAL"
        peso = {"NOR": 1, "CPP": 2, "DEF": 3, "DUD": 4, "PER": 5}
        peor_sigla = max(siglas, key=lambda x: peso.get(x, 1))
        return mapa_riesgo.get(peor_sigla, "NORMAL")

    def _clasificar_riesgo_por_pixel(self, rgb):
        r, g, b = rgb
        if r > 230 and g > 230 and b > 230:
            return None
        if abs(r - g) < 20 and abs(g - b) < 20 and r > 80:
            return None 
        if g > r and g > b and g > 100:
            return "NOR" 
        elif r > 150 and g > 120 and b < 100:
            return "CPP" 
        elif r > 180 and g > 80 and g < 150 and b < 80:
            return "DEF" 
        elif r > 120 and g < 100 and b < 100:
            return "DUD" 
        elif r < 100 and g < 100 and b < 100:
            return "PER" 
        return None 

    def extraer_datos(self, ruta_pdf, id_carpeta, tipo_persona="PN"):
        resumen_cliente = None
        lista_reps = []
        
        try:
            cliente_nombre = "N/D"
            deuda_total_actual = "N/D"
            lista_deudas_temp = []
            historial_riesgo = "No registra"
            estado_semaforo = "No registra"
            
            lineas_aplanadas = []
            foto_tomada = False
            semaforo_evaluado = False
            
            en_tabla_deudas = False
            tabla_deudas_terminada = False
            indice_fila_tabla = 0
            en_tabla_reps_nat = False
            
            with pdfplumber.open(ruta_pdf) as pdf:
                for num_p, pagina in enumerate(pdf.pages):
                    words = pagina.extract_words(keep_blank_chars=False)
                    
                    # --- EVALUACIÓN DE SEMÁFORO ---
                    if not semaforo_evaluado:
                        for w in words:
                            if "SEMÁFORO" in w["text"].upper():
                                try:
                                    y_techo_semaforo = w["bottom"]
                                    y_inicio_grid = y_techo_semaforo + self.SEM_OFFSET_Y
                                    
                                    imagen_sem = pagina.to_image(resolution=300).original.convert("RGB")
                                    w_img, h_img = imagen_sem.size
                                    escala_x = w_img / pagina.width
                                    escala_y = h_img / pagina.height
                                    
                                    x_centro_col2 = self.SEM_INICIO_X + self.SEM_ANCHO_COL_1 + (self.SEM_ANCHO_COL_2 / 2)
                                    x_pixel = int(x_centro_col2 * escala_x)
                                    
                                    for fila in range(4):
                                        y_centro_fila = y_inicio_grid + (self.SEM_ALTO_FILA * fila) + (self.SEM_ALTO_FILA / 2)
                                        y_pixel = int(y_centro_fila * escala_y)
                                        
                                        r, g, b = imagen_sem.getpixel((x_pixel, y_pixel))
                                        if r < 100 and g < 100 and b < 100:
                                            estado_semaforo = self.SEM_RESULTADOS[fila]
                                            break
                                    semaforo_evaluado = True
                                    break
                                except Exception:
                                    pass
                    
                    filas = {}
                    for w in words:
                        y_f = round(((w["top"] + w["bottom"]) / 2) / self.TOLERANCIA_Y) * self.TOLERANCIA_Y
                        if y_f not in filas:
                            filas[y_f] = []
                        filas[y_f].append(w)
                    
                    for y_f, p_fila in sorted(filas.items()):
                        p_fila = sorted(p_fila, key=lambda x: x["x0"])
                        texto_linea_completa = " ".join([x["text"] for x in p_fila]).strip()
                        texto_linea_upper = texto_linea_completa.upper()
                        
                        if not texto_linea_completa:
                            continue
                        lineas_aplanadas.append(texto_linea_completa)
                        
                        if tipo_persona == "PN":
                            if "ES REPRESENTANTE LEGAL DE" in texto_linea_upper:
                                en_tabla_reps_nat = True
                                continue
                                
                            if en_tabla_reps_nat:
                                if any(palabra in texto_linea_upper for palabra in ["SEMÁFORO", "12M", "RAZÓN SOCIAL", "QUE OCUPA", "FECHA DESDE", "ACT PRE"]):
                                    continue
                                    
                                if any(fin in texto_linea_upper for fin in ["TARJETA CRÉDITO", "OTROS CRÉDITOS", "HECHOS DE IMPORTANCIA", "EMPRESAS RELACIONADAS"]):
                                    en_tabla_reps_nat = False
                                    continue

                                ruc_val, razon_val, fecha_val, cargo_val, estado_val = "", "", "", "", ""
                                
                                for w in p_fila:
                                    centro_x = (w["x0"] + w["x1"]) / 2
                                    txt = w["text"]

                                    if 36.0 <= centro_x < 100.0:
                                        ruc_val += txt + " "
                                    elif 100.0 <= centro_x < 370.0:
                                        razon_val += txt + " "
                                    elif 370.0 <= centro_x < 425.0:
                                        fecha_val += txt + " "
                                    elif 425.0 <= centro_x < 495.0:
                                        cargo_val += txt + " "
                                    elif 495.0 <= centro_x <= 560.0:
                                        estado_val += txt + " "
                                        
                                ruc_val = ruc_val.strip()
                                razon_val = razon_val.strip()
                                fecha_val = fecha_val.strip()
                                cargo_val = cargo_val.strip()
                                estado_val = estado_val.strip()
                                

                                match_ruc = re.search(r"(\d{8,11})", ruc_val)
                                if match_ruc:
                                    ruc_limpio = match_ruc.group(1)
                                    
                                    cargo_limpio = cargo_val if cargo_val else "--"
                                    if cargo_limpio.endswith("-"):
                                        cargo_limpio = cargo_limpio[:-1].strip()
                                        
                                    estado_limpio = estado_val if estado_val else "NO DEFINIDO"
                                        
                                    if "ACTIVO" in estado_limpio.upper() and "NO APLICA" not in estado_limpio.upper():
                                        lista_reps.append({
                                            "CARPETA_ID": id_carpeta,
                                            "TIPO_VINCULO": "Es Rep. Legal de (P. Natural)",
                                            "DOC_VINCULADO": ruc_limpio,
                                            "NOMBRE_VINCULADO": razon_val,
                                            "FECHA": fecha_val,
                                            "CARGO": cargo_limpio,
                                            "ESTADO": estado_limpio
                                        })
                                elif ruc_val != "":
                                    en_tabla_reps_nat = False
                        if not tabla_deudas_terminada:
                            if en_tabla_deudas and "ENTIDAD" in texto_linea_upper and not any(c.isdigit() for c in texto_linea_upper):
                                en_tabla_deudas = False
                                tabla_deudas_terminada = True
                            elif "TOTAL / CALIF. POND." in texto_linea_upper:
                                if not en_tabla_deudas:
                                    en_tabla_deudas = True
                                    indice_fila_tabla = 0
                                else:
                                    if indice_fila_tabla >= 10:
                                        en_tabla_deudas = False
                                        tabla_deudas_terminada = True
                            
                            if en_tabla_deudas:
                                indice_fila_tabla += 1
                                if indice_fila_tabla > 1 and "TOTAL / CALIF. POND." not in texto_linea_upper:
                                    entidad_col1, col_17, col_18, col_19 = "", "", "", ""
                                    for w in p_fila:
                                        centro_x = (w["x0"] + w["x1"]) / 2
                                        col = self._obtener_columna(centro_x)
                                        if col == 1:
                                            entidad_col1 += w["text"] + " "
                                        elif col == 17:
                                            col_17 += w["text"] + " "
                                        elif col == 18:
                                            col_18 += w["text"] + " "
                                        elif col == 19:
                                            col_19 += w["text"] + " "
                                    
                                    entidad_col1 = entidad_col1.strip()
                                    datos_juntos = f"{col_17.strip()} {col_18.strip()} {col_19.strip()}".split()
                                    
                                    tiene_monto = any(self.RE_MONTO.match(b) for b in datos_juntos)
                                    tiene_porcentaje = any(self.RE_PORCENTAJE.match(b) for b in datos_juntos)
                                    
                                    if entidad_col1 and tiene_monto and tiene_porcentaje:
                                        montos = [b for b in datos_juntos if self.RE_MONTO.match(b)]
                                        ultimo_monto = montos[-1]
                                        if ultimo_monto not in ["0.00", "0", "0.0"] and len(entidad_col1) > 2:
                                            lista_deudas_temp.append({"Entidad": entidad_col1, "Monto": ultimo_monto})
                        
                        if not foto_tomada and "4 AÑOS" in texto_linea_upper and "MICROFINANZAS" in texto_linea_upper:
                            try:
                                top_texto = p_fila[0]["top"]
                                bottom_texto = p_fila[0]["bottom"]
                                crop_box = (self.X_INICIO, max(0, top_texto - self.MARGEN_VERTICAL), self.X_FIN, min(pagina.height, bottom_texto + self.MARGEN_VERTICAL))
                                recorte = pagina.crop(crop_box)
                                imagen = recorte.to_image(resolution=300).original 
                                width, height = imagen.size
                                y_center = int(height * 0.68)
                                
                                siglas_detectadas = []
                                ultimo_color = None
                                racha_pixeles = 0
                                
                                for x in range(width):
                                    pixel = imagen.getpixel((x, y_center))
                                    rgb = pixel[:3] if isinstance(pixel, tuple) else (pixel, pixel, pixel)
                                    sigla = self._clasificar_riesgo_por_pixel(rgb)
                                    
                                    if sigla:
                                        if sigla == ultimo_color:
                                            racha_pixeles += 1
                                        else:
                                            if ultimo_color and racha_pixeles > 4:
                                                siglas_detectadas.append(ultimo_color)
                                            ultimo_color = sigla
                                            racha_pixeles = 1
                                    else:
                                        if ultimo_color and racha_pixeles > 4:
                                            siglas_detectadas.append(ultimo_color)
                                        ultimo_color = None
                                        racha_pixeles = 0
                                
                                if ultimo_color and racha_pixeles > 4:
                                    siglas_detectadas.append(ultimo_color)
                                if siglas_detectadas:
                                    historial_riesgo = " -> ".join(siglas_detectadas)
                                foto_tomada = True
                            except Exception:
                                pass
                                        
            columna_excel = pd.Series(lineas_aplanadas)
            leyendo_reps_nat, leyendo_reps_jur = False, False
            
            for i in range(len(columna_excel)):
                texto_linea = str(columna_excel.iloc[i]).strip()
                
                # ============================================================
                # === CAMBIO 2: RESUMEN CLIENTE con fallback por tipo_persona ===
                # ============================================================
                match_resumen = self.RE_RESUMEN.search(texto_linea)
                
                # Fallback PN: si la regex principal no matchea, intentar con DNI explícito (8)
                if not match_resumen and tipo_persona == "PN":
                    match_resumen = re.search(
                        r"(\d{2}/\d{2}/\d{4})\s+([A-Z]{3})\s+(\d{8})\s+(.*?)\s+(\d\.\d{3})\s+([\d,]+\.\d{2})",
                        texto_linea
                    )
                
                # Fallback PJ: si la regex principal no matchea, intentar con RUC explícito (11)
                if not match_resumen and tipo_persona == "PJ":
                    match_resumen = re.search(
                        r"(\d{2}/\d{2}/\d{4})\s+([A-Z]{3})\s+(\d{11})\s+(.*?)\s+(\d\.\d{3})\s+([\d,]+\.\d{2})",
                        texto_linea
                    )
                
                if match_resumen:
                    cliente_nombre = match_resumen.group(4).strip()
                    deuda_total_actual = match_resumen.group(6)

                elif tipo_persona == "PJ":
                    if texto_linea.upper() == "REPRESENTANTES LEGALES":
                        leyendo_reps_jur = True
                        continue

                    if leyendo_reps_jur:
                        if "EMPRESAS RELACIONADAS A:" in texto_linea.upper() or "HECHOS DE IMPORTANCIA" in texto_linea.upper():
                            leyendo_reps_jur = False
                            continue
                        if any(cab in texto_linea.upper() for cab in ["NRO DOCUMENTO", "NOMBRE DE REPRESENTANTE", "ACT PRE 12M", "FECHA DESDE", "CARGO"]):
                            continue

                        match_jur = self.RE_REP_JURIDICA.search(texto_linea)
                        if match_jur:
                            cargo_crudo = match_jur.group(4).strip()
                            cargo_limpio = cargo_crudo.replace("ACTIVO", "").replace("NO APLICA", "").strip()
                            if cargo_limpio.endswith("-"):
                                cargo_limpio = cargo_limpio[:-1].strip()
                            
                            lista_reps.append({
                                "CARPETA_ID": id_carpeta,
                                "TIPO_VINCULO": "Sus Rep. Legales son (P. Jurídica)",
                                "DOC_VINCULADO": match_jur.group(1),
                                "NOMBRE_VINCULADO": match_jur.group(2).strip(),
                                "FECHA": match_jur.group(3),
                                "CARGO": cargo_limpio if cargo_limpio else "--",
                                "ESTADO": "NO APLICA"
                            })

            texto_narrativo_deudas = "No registra información de deudas."
            if lista_deudas_temp:
                entidades_vistas = set()
                deudas_formateadas = []
                for d in lista_deudas_temp:
                    if d["Entidad"] in entidades_vistas:
                        break
                    entidades_vistas.add(d["Entidad"])
                    deudas_formateadas.append(f"{d['Entidad']} por S/ {d['Monto']}")
                texto_narrativo_deudas = "Mantiene deudas con " + ", ".join(deudas_formateadas)
            
            # ============================================================
            # === CAMBIO 3: Fallback de deuda + guardado garantizado ===
            # ============================================================
            # Fallback PN: si no se capturó el cliente pero hay deuda en tabla,
            # intentar recuperar el monto total desde la línea "TOTAL / CALIF. POND."
            if cliente_nombre == "N/D" and tipo_persona == "PN":
                for linea in columna_excel:
                    linea_str = str(linea).strip()
                    if "TOTAL" in linea_str.upper() and ("CALIF" in linea_str.upper() or "POND" in linea_str.upper()):
                        montos = re.findall(r"\d{1,3}(?:,\d{3})*\.\d{2}", linea_str)
                        if montos:
                            deuda_total_actual = montos[-1]
                            break

            if cliente_nombre != "N/D" or deuda_total_actual != "N/D":
                riesgo_final = self.limpiar_riesgo_jerarquico(historial_riesgo)
                resumen_cliente = {
                    "CARPETA_ID": id_carpeta, 
                    "CLIENTE": cliente_nombre if cliente_nombre != "N/D" else id_carpeta,
                    "DEUDA_TOTAL_ACTUAL": deuda_total_actual if deuda_total_actual != "N/D" else "0.00",
                    "HISTORICO_RIESGO_4AÑOS": riesgo_final,
                    "DETALLE_DEUDAS": texto_narrativo_deudas,
                    "SEMAFORO": estado_semaforo
                }
                
        except Exception as e:
            print(f"   [!] Error en Procesador Quirúrgico ({os.path.basename(ruta_pdf)}): {e}")
            import traceback
            traceback.print_exc()
        
        return resumen_cliente, lista_reps