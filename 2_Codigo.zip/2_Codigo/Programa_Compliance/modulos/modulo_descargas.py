import os
import time
import random
import urllib.parse
import pandas as pd
from playwright.sync_api import sync_playwright
import pypdf
import winreg
from utils.conversor_columnas import ConversorColumnas

class MotorDescargasCore:
    def __init__(self, config: dict):
        self.cfg = config
        
    def obtener_valor(self, fila, letra_col):
        idx = ConversorColumnas.col_a_indice(letra_col)
        if 0 <= idx < len(fila):
            return fila.iloc[idx]
        return ""

    def filtrar_paginas_con_recorte(self, ruta_temporal, ruta_final, min_palabras=30):
        try:
            reader = pypdf.PdfReader(ruta_temporal)
            writer = pypdf.PdfWriter()
            paginas_validas = 0

            for i, page in enumerate(reader.pages):
                texto = page.extract_text() or ""
                fragmentos = texto.split()
                palabras_reales = [f for f in fragmentos if not (f.startswith("http") or "www." in f or len(f) > 25)]
                
                if len(palabras_reales) >= min_palabras:
                    writer.add_page(page)
                    paginas_validas += 1
                elif i == 0:
                    alto_total = float(page.mediabox.height)
                    page.mediabox.bottom = float(page.mediabox.top) - (alto_total / 3.0)
                    writer.add_page(page)
                    paginas_validas += 1
            
            if paginas_validas > 0:
                with open(ruta_final, "wb") as f:
                    writer.write(f)
                return paginas_validas
            return 0
        except Exception as e:
            print(f"   [ERROR PDF] {e}")
            return 0

    def obtener_user_agent_edge_actual(self):
        userAgent_defecto = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
        try:
            clave = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Edge\BLBeacon")
            version, _ = winreg.QueryValueEx(clave, "version")
            winreg.CloseKey(clave)
            version_mayor = version.split('.')[0]
            return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version_mayor}.0.0.0 Safari/537.36 Edg/{version}"
        except Exception:
            return userAgent_defecto

    def ejecutar(self, callback_progreso=None):
        try:
            print("[*] Leyendo Matriz Excel para automatización web...")
            
            ruta_matriz = self.cfg.get('ruta_matriz')
            ruta_casos = self.cfg.get('ruta_casos')
            pestana = self.cfg.get('descargas_pestana', 'DDR_ANUAL')
            col_nombre = self.cfg.get('descargas_col_nombre', 'C')
            col_carpeta = self.cfg.get('descargas_col_car', 'A')

            if not ruta_matriz:
                print("[!] ERROR: Ruta de Matriz no configurada")
                if callback_progreso:
                    callback_progreso(-1)
                return
                
            if not ruta_casos:
                print("[!] ERROR: Ruta de casos no configurada")
                if callback_progreso:
                    callback_progreso(-1)
                return

            if not os.path.exists(ruta_matriz):
                print(f"[!] ERROR: La matriz no existe: {ruta_matriz}")
                return

            df = pd.read_excel(ruta_matriz, sheet_name=pestana, dtype=str)
            
            sujetos = []
            for _, fila in df.iterrows():
                nombre = str(self.obtener_valor(fila, col_nombre)).strip()
                carpeta = str(self.obtener_valor(fila, col_carpeta)).strip()
                if nombre.upper() not in ["NAN", "0", ""] and carpeta.upper() not in ["NAN", "0", ""]:
                    sujetos.append((nombre, carpeta))
            
            total_sujetos = len(sujetos)
            if total_sujetos == 0:
                print("[!] No se encontraron sujetos válidos.")
                return

            terminos_auditoria = ["+ LAVADO", "+ DELITO"]

            with sync_playwright() as p:
                print("[*] Iniciando Navegador VISIBLE (Modo Humano) con Camuflaje...")
                browser = p.chromium.launch(headless=False, channel="msedge", args=["--window-state=minimized"]) 
                
                context = browser.new_context(
                    viewport={'width': 1366, 'height': 768},
                    user_agent=self.obtener_user_agent_edge_actual(),
                    locale='es-PE'
                )
                
                page = context.new_page()
                page.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
                
                for idx, (persona, n_carpeta) in enumerate(sujetos, 1):
                    persona_limpia = persona.replace('"', '').strip()
                    nombre_limpio = "".join(c for c in persona_limpia if c.isalnum() or c in (" ", "_", "-")).rstrip()
                    
                    ruta_expediente = os.path.join(ruta_casos, n_carpeta)
                    os.makedirs(ruta_expediente, exist_ok=True)
                    
                    print(f"\n[{idx}/{total_sujetos}] Evaluando a: {persona_limpia} (Carpeta: {n_carpeta})")
                    
                    if idx > 1 and idx % 10 == 0:
                        pausa_larga = random.randint(30, 45)
                        print(f"   [DESCANSO ESTRATÉGICO] Pausando {pausa_larga} segundos para enfriar la conexión...")
                        time.sleep(pausa_larga)
                    
                    for termino in terminos_auditoria:
                        query = f'{persona_limpia} {termino}'
                        query_cod = urllib.parse.quote_plus(query)
                        url_bing = f"https://www.bing.com/search?q={query_cod}"
                        t_limpio = termino.replace("+ ", "").strip()
                        
                        ruta_temp = os.path.join(ruta_expediente, f"temp_{nombre_limpio}_{t_limpio}.pdf")
                        ruta_final = os.path.join(ruta_expediente, f"Busqueda_{nombre_limpio}_{t_limpio}.pdf")
                        
                        exito = False
                        intentos = 0
                        max_intentos = 3
                        
                        while intentos < max_intentos and not exito:
                            try:
                                intentos += 1
                                page.goto(url_bing, wait_until="domcontentloaded", timeout=45000)
                                page.evaluate("window.scrollTo(0, 400); setTimeout(()=>window.scrollTo(0,0), 1000);")
                                time.sleep(1.5)
                                
                                page.pdf(path=ruta_temp, format="Letter", print_background=True, margin={"top": "0.5in", "bottom": "0.5in", "left": "0.5in", "right": "0.5in"})
                                pags = self.filtrar_paginas_con_recorte(ruta_temp, ruta_final, min_palabras=30)
                                
                                if pags > 0:
                                    print(f"   -> PDF guardado: {t_limpio}")
                                exito = True
                                
                                if os.path.exists(ruta_temp):
                                    os.remove(ruta_temp)
                            except Exception as e:
                                error_msg = str(e).split(' at ')[0]
                                print(f"   [ALERTA Web] Falla en intento {intentos}/{max_intentos}: {error_msg}")
                                if os.path.exists(ruta_temp):
                                    os.remove(ruta_temp)
                                if intentos < max_intentos:
                                    print("   -> Esperando 12 segs...")
                                    time.sleep(12)
                        
                        time.sleep(random.randint(4, 7))
                    
                    if callback_progreso:
                        callback_progreso(idx / total_sujetos)
                    print(f"   Esperando para el siguiente sujeto...")
                    time.sleep(random.randint(5, 9))
                    
                browser.close()
                print("\n[*] Auditoría Web Finalizada.")

        except Exception as e:
            print(f"[ERROR CRÍTICO DESCARGAS] {str(e)}")
            import traceback
            traceback.print_exc()
            if callback_progreso:
                callback_progreso(-1)