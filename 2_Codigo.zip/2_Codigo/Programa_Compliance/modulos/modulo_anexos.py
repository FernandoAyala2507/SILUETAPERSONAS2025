import os
import shutil
import pandas as pd
from utils.conversor_columnas import ConversorColumnas

class MotorAnexosCore:
    def __init__(self, config: dict):
        self.cfg = config

    def obtener_valor(self, fila, letra_col):
        idx = ConversorColumnas.col_a_indice(letra_col)
        if 0 <= idx < len(fila):
            return fila.iloc[idx]
        return ""

    def ejecutar(self, callback_progreso=None):
        try:
            ruta_matriz = self.cfg.get('ruta_matriz')
            ruta_destino = self.cfg.get('ruta_casos')
            ruta_origen = self.cfg.get('anexos_ruta_origen')
            
            pestana = self.cfg.get('anexos_pestana', 'DDR_ANUAL')
            col_doi = self.cfg.get('anexos_col_doi', 'AD')
            col_car = self.cfg.get('anexos_col_car', 'A')

            if not ruta_matriz:
                print("[-] ERROR: Falta la ruta del Libro Maestro")
                if callback_progreso:
                    callback_progreso(-1)
                return
                
            if not ruta_destino:
                print("[-] ERROR: Falta la ruta de casos destino")
                if callback_progreso:
                    callback_progreso(-1)
                return
                
            if not ruta_origen:
                print("[-] ERROR: Falta la ruta de origen de anexos")
                if callback_progreso:
                    callback_progreso(-1)
                return

            if not os.path.exists(ruta_matriz):
                print(f"[-] ERROR: La matriz no existe: {ruta_matriz}")
                return

            if not os.path.exists(ruta_origen):
                print(f"[-] ERROR: La ruta de origen no existe: {ruta_origen}")
                return

            print("[*] Iniciando rastreo y copiado de archivos anexos (Sentinel, Sunat, etc.)...")
            
            df_matriz = pd.read_excel(ruta_matriz, sheet_name=pestana, dtype=str)
            total_casos = len(df_matriz)
            archivos_copiados = 0

            for idx, fila in df_matriz.iterrows():
                doi_raw = str(self.obtener_valor(fila, col_doi)).strip().split('.')[0]
                n_carpeta = str(self.obtener_valor(fila, col_car)).strip()

                if not doi_raw or doi_raw.upper() in ["NAN", "0", ""] or not n_carpeta or n_carpeta.upper() in ["NAN", "0", ""]:
                    if callback_progreso:
                        callback_progreso((idx + 1) / total_casos)
                    continue

                ruta_carpeta_caso = os.path.join(ruta_destino, n_carpeta)
                
                if not os.path.exists(ruta_carpeta_caso):
                    if callback_progreso:
                        callback_progreso((idx + 1) / total_casos)
                    continue

                archivos_encontrados = [f for f in os.listdir(ruta_origen) if doi_raw in f and os.path.isfile(os.path.join(ruta_origen, f))]

                if archivos_encontrados:
                    print(f"\n   [*] Expediente {n_carpeta} (DOI: {doi_raw}): Se encontraron {len(archivos_encontrados)} archivos.")
                    for archivo in archivos_encontrados:
                        origen_archivo = os.path.join(ruta_origen, archivo)
                        destino_archivo = os.path.join(ruta_carpeta_caso, archivo)
                        try:
                            shutil.copy2(origen_archivo, destino_archivo)
                            archivos_copiados += 1
                            print(f"       -> Copiado: {archivo}")
                        except Exception as e:
                            print(f"       [x] Error copiando {archivo}: {str(e)}")

                if callback_progreso:
                    callback_progreso((idx + 1) / total_casos)

            print(f"\n[!] PROCESO FINALIZADO. Se anexaron un total de {archivos_copiados} archivos.")
            
        except Exception as e:
            print(f"[ERROR CRÍTICO ANEXOS] {str(e)}")
            import traceback
            traceback.print_exc()
            if callback_progreso:
                callback_progreso(-1)