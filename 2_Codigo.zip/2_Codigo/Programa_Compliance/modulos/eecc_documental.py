import os
import copy
import re
from datetime import datetime
from docx import Document
from docx.table import _Row
import openpyxl
from openpyxl.styles import PatternFill, Font

class GeneradorDocumentalEECC:
    def __init__(self, ruta_maestro):
        self.ruta_maestro = ruta_maestro

    def actualizar_maestro_excel(self, numero_caso, veredicto):
        try:
            wb = openpyxl.load_workbook(self.ruta_maestro)
            nombre_hoja = "Resultados_Compliance"
            
            fill_cabecera = PatternFill(start_color="002060", end_color="002060", fill_type="solid")
            fill_alerta = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
            font_blanca = Font(color="FFFFFF", bold=True)
            
            if nombre_hoja not in wb.sheetnames:
                ws = wb.create_sheet(nombre_hoja)
                ws.append(["N° CASO", "ESTADO FINAL", "DETALLE DEL HALLAZGO", "FECHA ANÁLISIS"])
                for cell in ws[1]:
                    cell.fill = fill_cabecera
                    cell.font = font_blanca
            else:
                ws = wb[nombre_hoja]

            estado = "DESCARTADO" if veredicto.get('descartado') else "ALERTA RIESGO"
            fecha_actual = datetime.now().strftime("%d/%m/%Y %H:%M")
            
            nueva_fila = [numero_caso, estado, veredicto.get('mensaje_excel', ''), fecha_actual]
            ws.append(nueva_fila)
            
            if not veredicto.get('descartado'):
                for cell in ws[ws.max_row]:
                    cell.fill = fill_alerta
                    cell.font = font_blanca

            wb.save(self.ruta_maestro)
            wb.close()
            print(f"✅ Excel Maestro actualizado: Caso {numero_caso}")
        except Exception as e:
            print(f"❌ [ERROR EXCEL] No se pudo actualizar el Libro Maestro para {numero_caso}: {str(e)}")

    def _obtener_todas_las_tablas(self, doc):
        todas = list(doc.tables)
        for section in doc.sections:
            todas.extend(section.header.tables)
            todas.extend(section.footer.tables)
        i = 0
        while i < len(todas):
            for row in todas[i].rows:
                for cell in row.cells:
                    for tb in cell.tables:
                        if tb not in todas:
                            todas.append(tb)
            i += 1
        return todas

    def _procesar_etiquetas_simples(self, doc, mapeo):
        for p in doc.paragraphs:
            self._aplicar_reemplazo_en_parrafo(p, mapeo)
        
        for section in doc.sections:
            for p in section.header.paragraphs:
                self._aplicar_reemplazo_en_parrafo(p, mapeo)
            for p in section.footer.paragraphs:
                self._aplicar_reemplazo_en_parrafo(p, mapeo)
        
        for table in self._obtener_todas_las_tablas(doc):
            for row in table.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        self._aplicar_reemplazo_en_parrafo(p, mapeo)

    def _aplicar_reemplazo_en_parrafo(self, p, mapeo):
        texto_completo = p.text
        if not texto_completo.strip():
            return
        
        hubo_cambio = False
        for tag, valor in mapeo.items():
            clean_tag = tag.replace("{{", "").replace("}}", "").strip()
            clean_tag = re.escape(clean_tag).replace("°", "[°º]").replace("º", "[°º]")
            pattern = r"\{\s*\{\s*" + clean_tag + r"\s*\}\s*\}"
            
            if re.search(pattern, texto_completo, flags=re.IGNORECASE):
                texto_completo = re.sub(pattern, str(valor), texto_completo, flags=re.IGNORECASE)
                hubo_cambio = True
                
        if hubo_cambio:
            f_name, f_size, f_bold = None, None, None
            if p.runs:
                f_name = p.runs[0].font.name
                f_size = p.runs[0].font.size
                f_bold = p.runs[0].bold
                
            p.text = texto_completo
            
            if p.runs and f_name is not None:
                p.runs[0].font.name = f_name
                p.runs[0].font.size = f_size
                p.runs[0].font.bold = f_bold

    def _llenar_tabla_por_indice(self, doc, tag_ancla, lista_datos, llaves_ordenadas):
        clean_tag = tag_ancla.replace("{{", "").replace("}}", "").strip()
        clean_tag = re.escape(clean_tag).replace("°", "[°º]").replace("º", "[°º]")
        patron_ancla = r"\{\s*\{\s*" + clean_tag + r"\s*\}\s*\}"
        
        todas_las_tablas = self._obtener_todas_las_tablas(doc)
        tabla_obj, fila_plantilla = None, None
        
        for table in todas_las_tablas:
            for row in table.rows:
                texto_fila = "".join([p.text for c in row.cells for p in c.paragraphs])
                if re.search(patron_ancla, texto_fila, flags=re.IGNORECASE):
                    tabla_obj = table
                    fila_plantilla = row
                    break
            if tabla_obj:
                break
            
        if tabla_obj and fila_plantilla:
            if lista_datos:
                fila_actual_xml = fila_plantilla._tr
                for d in lista_datos:
                    nuevo_tr_xml = copy.deepcopy(fila_plantilla._tr)
                    fila_actual_xml.addnext(nuevo_tr_xml)
                    fila_actual_xml = nuevo_tr_xml
                    
                    nueva_fila = _Row(nuevo_tr_xml, tabla_obj)
                    
                    for idx, llave in enumerate(llaves_ordenadas):
                        try:
                            celda = nueva_fila.cells[idx]
                            valor = str(d.get(llave, "--"))
                            
                            if celda.paragraphs and celda.paragraphs[0].runs:
                                f_name = celda.paragraphs[0].runs[0].font.name
                                f_size = celda.paragraphs[0].runs[0].font.size
                                f_bold = celda.paragraphs[0].runs[0].font.bold
                                
                                celda.text = valor
                                
                                if celda.paragraphs[0].runs:
                                    celda.paragraphs[0].runs[0].font.name = f_name
                                    celda.paragraphs[0].runs[0].font.size = f_size
                                    celda.paragraphs[0].runs[0].font.bold = f_bold
                            else:
                                celda.text = valor
                        except IndexError:
                            pass
                            
                try:
                    tabla_obj._tbl.remove(fila_plantilla._tr)
                except:
                    pass
            else:
                for idx in range(len(llaves_ordenadas)):
                    try:
                        celda = fila_plantilla.cells[idx]
                        if celda.paragraphs and celda.paragraphs[0].runs:
                            f_name = celda.paragraphs[0].runs[0].font.name
                            f_size = celda.paragraphs[0].runs[0].font.size
                            f_bold = celda.paragraphs[0].runs[0].font.bold
                            
                            celda.text = "--"
                            
                            if celda.paragraphs[0].runs:
                                celda.paragraphs[0].runs[0].font.name = f_name
                                celda.paragraphs[0].runs[0].font.size = f_size
                                celda.paragraphs[0].runs[0].font.bold = f_bold
                        else:
                            celda.text = "--"
                    except IndexError:
                        pass

    def autocompletar_formulario_word(self, ruta_carpeta_caso, veredicto, diccionario_cuentas, tipo_persona):

        
        nombre_plantilla = "Formulario de atención DDR - Persona Jurídica.docx" if tipo_persona == "PJ" else "Formulario de atención DDR - Persona Natural.docx"
        
        ruta_plantillas = os.path.join(os.path.dirname(self.ruta_maestro), "Plantillas_Word")
        ruta_origen = os.path.join(ruta_plantillas, nombre_plantilla)
        ruta_destino = os.path.join(ruta_carpeta_caso, nombre_plantilla)

        if not os.path.exists(ruta_origen):
            print(f"   ❌ No se halló plantilla en {ruta_origen}")
            return
        
        diccionario_reemplazos = {
            "{{AN}}": veredicto.get("texto_an", "--"),
            "{{RF}}": veredicto.get("texto_rf", "--"),
            "{{VEREDICTO}}": veredicto.get("mensaje_excel", "ANÁLISIS COMPLETADO"),
            "{{ESTADO}}": "DESCARTADO" if veredicto.get("descartado") else "ALERTA RIESGO",
            "{{FECHA}}": datetime.now().strftime("%d/%m/%Y"),
            "{{N}}": "X" if veredicto.get("descartado") else "",
            "{{FCI}}": datetime.now().strftime("%d/%m/%Y"),
            "{{NORMAL_X}}": "X" if veredicto.get("descartado") else "",
            "{{ALERTA_X}}": "" if veredicto.get("descartado") else "X"
        }


        datos_cuentas = []
        
        if isinstance(diccionario_cuentas, dict):
            
            for nro_cta, metadata in diccionario_cuentas.items():
                print(f"   [DEBUG WORD] nro_cta={nro_cta}")
                print(f"      metadata keys: {list(metadata.keys())}")
                print(f"      metadata.get('tipo_producto'): {metadata.get('tipo_producto', 'NO EXISTE')}")
                print(f"      metadata.get('origen'): {metadata.get('origen', 'NO EXISTE')}")
                
                tipo_producto_raw = metadata.get("tipo_producto", "")
                
                if not tipo_producto_raw or tipo_producto_raw == "CTA":
                    nro_base = nro_cta.split('-')[0] if '-' in nro_cta else nro_cta
                    datos_base = diccionario_cuentas.get(nro_base, {})
                    tipo_producto_raw = datos_base.get("tipo_producto", "")
                    if tipo_producto_raw:
                        print(f"      -> Obtenido de clave base '{nro_base}': '{tipo_producto_raw}'")
                
                if not tipo_producto_raw or tipo_producto_raw == "CTA":
                    origen = metadata.get("origen", "")
                    if origen == "ROSPRTD":
                        tipo_producto_raw = "Cuenta"
                    elif origen == "ROSPRTT" or origen == "ROSPRTT_MOV":
                        tipo_producto_raw = "Tarjeta"
                    else:
                        tipo_producto_raw = "CTA"
                    print(f"      -> Usando fallback por origen '{origen}': '{tipo_producto_raw}'")
                
                tot_abono = float(metadata.get("tot_abono", 0.0))
                tot_cargo = float(metadata.get("tot_cargo", 0.0))
                moneda = metadata.get("moneda", "PEN")
                str_ingresos = f"Abonos {tot_abono:,.2f} {moneda} - Cargos {tot_cargo:,.2f} {moneda}"

                datos_cuentas.append({
                    "{{TP}}": tipo_producto_raw,
                    "{{Manco}}": str(metadata.get('manco', 'INDIVIDUAL')),
                    "{{N°C}}": str(metadata.get('nro_visual', nro_cta.split('-')[0] if '-' in nro_cta else nro_cta)),
                    "{{FA}}": str(metadata.get('apertura_raw', 'N/D')).replace(".0", ""),
                    "{{FC}}": str(metadata.get('cierre_calculado', metadata.get('estado', 'N/D'))).replace(".0", ""),
                    "{{TI}}": str_ingresos
                })
        else:
            print(f"   [WARN] diccionario_cuentas no es un diccionario: {type(diccionario_cuentas)}")

        try:
            doc = Document(ruta_origen)
            
            if datos_cuentas:
                print(f"   [INFO] Generando tabla con {len(datos_cuentas)} cuentas")
                self._llenar_tabla_por_indice(doc, "{{N°C}}", datos_cuentas, ["{{TP}}", "{{Manco}}", "{{N°C}}", "{{FA}}", "{{FC}}", "{{TI}}"])
            else:
                print(f"   [INFO] No hay cuentas para mostrar en la tabla")
            
            self._procesar_etiquetas_simples(doc, diccionario_reemplazos)

            doc.save(ruta_destino)
            print(f"   ✅ Documento generado: {os.path.basename(ruta_destino)}")

        except Exception as e:
            print(f"   ❌ Error en generación documental: {str(e)}")
            import traceback
            traceback.print_exc()