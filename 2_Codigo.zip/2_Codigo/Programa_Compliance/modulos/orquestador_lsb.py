import os
import pandas as pd
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
from utils.conversor_columnas import ConversorColumnas
from .eecc_extractor import ExtractorEECC
from .eecc_validador import ValidadorEECC

class MotorAnalisisLSB:
    def __init__(self, config: dict):
        self.ruta_matriz = config.get("ruta_matriz", "")
        self.ruta_casos = config.get("ruta_casos", "")
        self.pestana = config.get("matriz_pestana", "DDR_ANUAL")
        self.col_car = config.get("matriz_col_car", "A").upper()
        self.col_tipo = config.get("matriz_col_tipo", "D").upper() 
        self.extractor = ExtractorEECC()
        self.validador = ValidadorEECC()

    def _obtener_tipo_persona(self, nro_caso):
        """Lee el tipo de persona (PN/PJ) desde la matriz"""
        try:
            df = pd.read_excel(self.ruta_matriz, sheet_name=self.pestana, dtype=str)
            idx_car = ConversorColumnas.col_a_indice(self.col_car)
            idx_tipo = ConversorColumnas.col_a_indice(self.col_tipo)
            
            for _, row in df.iterrows():
                caso = str(row.iloc[idx_car]).strip()
                if caso == str(nro_caso):
                    tipo = str(row.iloc[idx_tipo]).strip().upper()
                    return tipo if tipo in ["PN", "PJ"] else "PN"
            return "PN"
        except Exception as e:
            print(f"   [!] Error obteniendo tipo de persona para {nro_caso}: {e}")
            return "PN"

    def ejecutar(self):
        print("\n--- INICIANDO MOTOR LSB (ANÁLISIS DE EECC) ---")
        
        if not self.ruta_matriz or not os.path.exists(self.ruta_matriz):
            print("[-] ERROR LSB: Directorio de matriz no configurado o no existe.")
            return

        if not self.ruta_casos or not os.path.exists(self.ruta_casos):
            print("[-] ERROR LSB: Directorio de casos destino no configurado o no existe.")
            return

        carpetas = [f for f in os.listdir(self.ruta_casos) if os.path.isdir(os.path.join(self.ruta_casos, f))]
        datos_guardar = []

        for nro_caso in carpetas:
            ruta_carpeta_caso = Path(os.path.join(self.ruta_casos, nro_caso))
            
            archivos_excel = []
            
            if ruta_carpeta_caso.exists():
                for f in ruta_carpeta_caso.rglob("*.xls*"):
                    nombre_archivo = f.name.upper()
                    if ("ROSPRTD" in nombre_archivo or "ROSPRTT" in nombre_archivo) and not nombre_archivo.startswith("~"):
                        archivos_excel.append(str(f))

            if not archivos_excel:
                continue

            try:
                print(f"   -> Auditando finanzas: Caso {nro_caso}")
                
                tipo_persona = self._obtener_tipo_persona(nro_caso)
                print(f"       Tipo de persona: {tipo_persona}")
                
                diccionario_cuentas = self.extractor.extraer_datos_bancarios(archivos_excel, tipo_persona)
                
                veredicto = self.validador.evaluar_caso_completo(diccionario_cuentas, tipo_persona, nro_caso)
                
                datos_guardar.append({
                "CARPETA_ID": nro_caso,
                "TIPO_PERSONA": tipo_persona,
                "ESTADO_FINAL": "DESCARTADO" if veredicto.get('descartado') else "ALERTA RIESGO",
                "TEXTO_ANALISIS": veredicto.get('texto_an', ''),
                "TEXTO_RESUMEN": veredicto.get('texto_rf', ''),
                "MENSAJE_EXCEL": veredicto.get('mensaje_excel', '')
                })
            except Exception as e:
                print(f"   [!] Error en caso {nro_caso}: {str(e)}")
                import traceback
                traceback.print_exc()

        self._guardar_en_excel(datos_guardar)

    def _guardar_en_excel(self, datos):
        if not datos:
            return
            
        if not self.ruta_matriz or not os.path.exists(self.ruta_matriz):
            print("[-] ERROR LSB: No se encuentra la matriz para guardar los resultados.")
            return
            
        df = pd.DataFrame(datos)
        nombre_hoja = "Resultados_Compliance"
        
        try:
            with pd.ExcelWriter(self.ruta_matriz, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                df.to_excel(writer, sheet_name=nombre_hoja, index=False)
            
            wb = load_workbook(self.ruta_matriz)
            ws = wb[nombre_hoja]
            fill_azul = PatternFill(start_color="002060", end_color="002060", fill_type="solid")
            for cell in ws[1]:
                cell.fill = fill_azul
                cell.font = Font(color="FFFFFF", bold=True)
            wb.save(self.ruta_matriz)
            print(f">>> LSB Finalizado. {len(datos)} veredictos y narrativas guardadas en Matriz.")
        except PermissionError:
            print("[ERROR EXCEL LSB]: El archivo Excel está abierto. Ciérrelo para guardar los resultados.")
        except Exception as e:
            print(f"[ERROR EXCEL LSB]: {str(e)}")