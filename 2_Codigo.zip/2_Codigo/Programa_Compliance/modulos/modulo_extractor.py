import os
import pandas as pd
import concurrent.futures
from datetime import datetime
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
from utils.conversor_columnas import ConversorColumnas

AZUL_INSTITUCIONAL = "002060"
BLANCO = "FFFFFF"

class MotorCruce:
    def __init__(self, config: dict):
        self.cfg = config
        self.cache_memoria = {}
        self.listas_activas = {nom: c for nom, c in self.cfg.get('listas', {}).items() if c.get('activo', True)}
    
    def obtener_valor(self, fila, letra_col):
        idx = ConversorColumnas.col_a_indice(letra_col)
        if 0 <= idx < len(fila):
            return fila.iloc[idx]
        return ""

    def apply_excel_style(self, ws):
        fill = PatternFill(start_color=AZUL_INSTITUCIONAL, end_color=AZUL_INSTITUCIONAL, fill_type="solid")
        font = Font(color=BLANCO, bold=True)
        for cell in ws[1]:
            cell.fill = fill
            cell.font = font
            cell.alignment = Alignment(horizontal='center')

    def precalentar_cache(self):
        try:
            ruta_listas = self.cfg.get('ruta_listas')
            
            if not ruta_listas:
                print("[ERROR] ❌ No se ha configurado la ruta de listas.")
                print("   Solución: Ve a la pestaña 'Rutas Globales' y configura 'Directorio de Listas'")
                return False
            
            if not os.path.exists(ruta_listas):
                print(f"[ERROR] ❌ La ruta de listas no existe: {ruta_listas}")
                print("   Solución: Verifica que la carpeta exista o crea una nueva.")
                return False

            print("[*] Pre-calentando motores (Convirtiendo listas masivas a Caché RAM)...")
            print("    [!] Este proceso puede tardar la primera vez. Por favor, espere.")
            
            for nom_logico, cfg_lista in self.listas_activas.items():
                try:
                    base_name = cfg_lista['archivo']
                    archivos = [f for f in os.listdir(ruta_listas) if f.startswith(base_name) and f.endswith(('.xlsx', '.csv', '.xls', '.xlsb'))]
                    
                    if not archivos:
                        print(f"   [-] Archivo no encontrado para: {nom_logico} (busca: {base_name}*)")
                        continue
                    
                    ruta_origen = os.path.join(ruta_listas, archivos[0])
                    hojas = [h.strip() for h in cfg_lista['hoja'].split(',')]
                    self.cache_memoria[nom_logico] = {}
                    
                    for hoja in hojas:
                        nombre_limpio = base_name.replace(" ", "_")
                        hoja_limpia = hoja[:20].replace(" ", "_").replace(",", "").replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")
                        ruta_parquet = os.path.join(ruta_listas, f"CACHE_{nombre_limpio}_{hoja_limpia}.parquet")
                        
                        try:
                            if os.path.exists(ruta_parquet):
                                df = pd.read_parquet(ruta_parquet)
                                print(f"   [+] Lista '{nom_logico}' - Hoja '{hoja}' cargada desde caché")
                            else:
                                print(f"   [*] Lista '{nom_logico}' - Hoja '{hoja}' convirtiendo a caché...")
                                if ruta_origen.endswith('.csv'):
                                    df = pd.read_csv(ruta_origen, sep=';', dtype=str, engine='fastparquet')
                                else:
                                    df = pd.read_excel(ruta_origen, sheet_name=hoja, dtype=str)
                                
                                df = df.fillna("")
                                df.columns = df.columns.astype(str)
                                df.to_parquet(ruta_parquet, engine='fastparquet', compression='snappy')
                                print(f"   [+] Lista '{nom_logico}' - Hoja '{hoja}' guardada en caché")
                            
                            self.cache_memoria[nom_logico][hoja] = df
                        except Exception as e:
                            print(f"   [ERROR CACHÉ] {hoja}: {str(e)}")
                            continue
                            
                except KeyError as e:
                    print(f"   [ERROR] Configuración incompleta para lista '{nom_logico}': falta la clave {e}")
                    continue
                except Exception as e:
                    print(f"   [ERROR] Falló la lista '{nom_logico}': {str(e)}")
                    continue
            
            print("[OK] ✅ Cache precalentado exitosamente")
            return True
            
        except Exception as e:
            print(f"[ERROR FATAL] Falló el precalentamiento del cache: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

    def _convertir_letras_a_indices(self, cols_str):
        """
        Convierte una cadena de columnas (ej: "B", "C, D", "C - D") a una lista de índices.
        """
        if not cols_str:
            return []
        
        indices = []
        partes = [p.strip() for p in cols_str.split(',')]
        
        for parte in partes:
            if '-' in parte: 
                rango = parte.split('-')
                if len(rango) == 2:
                    inicio = ConversorColumnas.col_a_indice(rango[0].strip())
                    fin = ConversorColumnas.col_a_indice(rango[1].strip())
                    indices.extend(range(inicio, fin + 1))
            else: 
                indices.append(ConversorColumnas.col_a_indice(parte))
        
        return indices

    def procesar_lista_en_memoria(self, nombre_logico, cfg_lista, doi_busqueda):
        """
        Busca el DOI en las columnas específicas de la lista (NO en todas las columnas).
        """
        if nombre_logico not in self.cache_memoria:
            return None
        
        hojas = [h.strip() for h in cfg_lista['hoja'].split(',')]

        cols_str = cfg_lista.get('cols', 'A')
        col_indices = self._convertir_letras_a_indices(cols_str)
        
        if not col_indices:
            print(f"   [WARN] Lista '{nombre_logico}' no tiene columnas configuradas")
            return None
        
        doi_limpio = doi_busqueda.lstrip('0')
        hallazgos = []

        try:
            for hoja in hojas:
                if hoja not in self.cache_memoria[nombre_logico]:
                    continue
                df = self.cache_memoria[nombre_logico][hoja]
                
                mask_global = pd.Series(False, index=df.index)
                for idx in col_indices:
                    if idx < len(df.columns):
                        col_data = df.iloc[:, idx].astype(str).str.replace(r'\.0$', '', regex=True).str.strip().str.lstrip('0')
                        mask_global |= (col_data == doi_limpio)
                
                res = df[mask_global]
                if not res.empty:
                    hallazgos.append(res)
            
            if hallazgos:
                return (cfg_lista['alias'], pd.concat(hallazgos).drop_duplicates())
        except Exception as e:
            print(f"   [ERROR] Procesando lista {nombre_logico}: {str(e)}")
            return (f"ERR_{cfg_lista['alias']}", str(e))
        return None

    def ejecutar(self, callback_progreso=None):
        try:
            if not self.precalentar_cache():
                print("[ERROR] No se pudo inicializar el cache de listas. Abortando...")
                if callback_progreso:
                    callback_progreso(-1)
                return
            
            print("\n[*] Iniciando Auditoría de Expedientes...")
            
            df_matriz = pd.read_excel(self.cfg['ruta_matriz'], sheet_name=self.cfg.get('matriz_pestana', 'DDR_ANUAL'), dtype=str)
            
            col_id = self.cfg.get('matriz_col_doi', 'AD')
            col_carpeta = self.cfg.get('matriz_col_car', 'A')
            
            total_pasos = len(df_matriz)
            max_workers = os.cpu_count() or 4
            
            reporte_auditoria = [] 
            
            for index, fila in df_matriz.iterrows():
                doi_raw = str(self.obtener_valor(fila, col_id)).strip()
                doi_busqueda = doi_raw.split('.')[0] 
                n_carpeta = str(self.obtener_valor(fila, col_carpeta)).strip()
                
                if not doi_busqueda or doi_busqueda.upper() in ["NAN", "0", ""]:
                    if callback_progreso:
                        callback_progreso((index + 1) / total_pasos)
                    continue
                
                ruta_expediente = os.path.join(self.cfg['ruta_casos'], n_carpeta)
                
                if not os.path.exists(ruta_expediente):
                    print(f"==> Saltando: {n_carpeta} (Carpeta no existe. Usa el botón global para generarla)")
                    reporte_auditoria.append({"N° CARPETA": n_carpeta, "Resultados": "Carpeta inexistente"})
                    if callback_progreso:
                        callback_progreso((index + 1) / total_pasos)
                    continue

                print(f"==> Escaneando: {n_carpeta} (DOI: {doi_busqueda})")
                hallazgos_caso = {}
                
                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futuros = [
                        executor.submit(self.procesar_lista_en_memoria, nom, c, doi_busqueda) 
                        for nom, c in self.listas_activas.items()
                    ]
                    
                    for futuro in concurrent.futures.as_completed(futuros):
                        resultado = futuro.result()
                        if resultado and isinstance(resultado[1], pd.DataFrame):
                            hallazgos_caso[resultado[0][:31]] = resultado[1]
                            print(f"   [+] Match en: {resultado[0]}")

                if hallazgos_caso:
                    texto_resultados = ", ".join([f"Match: {pestana}" for pestana in hallazgos_caso.keys()])
                    reporte_auditoria.append({"N° CARPETA": n_carpeta, "Resultados": texto_resultados})
                    
                    hora = datetime.now().strftime("%H%M%S")
                    with pd.ExcelWriter(os.path.join(ruta_expediente, f"Compilado_Listas_{hora}.xlsx"), engine='openpyxl') as writer:
                        for pestaña, data in hallazgos_caso.items():
                            data.to_excel(writer, sheet_name=pestaña[:31], index=False)
                            self.apply_excel_style(writer.sheets[pestaña[:31]])
                else:
                    reporte_auditoria.append({"N° CARPETA": n_carpeta, "Resultados": "Sin hallazgos en lote actual"})

                if callback_progreso:
                    callback_progreso((index + 1) / total_pasos)

            if reporte_auditoria:
                print("\n[*] Consolidando resultados en el Libro Matriz...")
                df_auditoria = pd.DataFrame(reporte_auditoria)
                try:
                    with pd.ExcelWriter(self.cfg['ruta_matriz'], mode='a', engine='openpyxl', if_sheet_exists='replace') as writer:
                        df_auditoria.to_excel(writer, sheet_name='Auditoria_Resultados', index=False)
                        self.apply_excel_style(writer.sheets['Auditoria_Resultados'])
                    print("   [+] Pestaña 'Auditoria_Resultados' inyectada con éxito.")
                except PermissionError:
                    print("   [!] ERROR: El Libro Matriz está abierto en Excel. Ciérralo para guardar el reporte general.")
                except Exception as e:
                    print(f"   [!] Error al escribir en la Matriz: {str(e)}")

            print("\n[!] PROCESO FINALIZADO EXITOSAMENTE")
            
        except FileNotFoundError as e:
            print(f"[ERROR] Archivo no encontrado: {e}")
            if callback_progreso:
                callback_progreso(-1)
        except PermissionError as e:
            print(f"[ERROR] Permiso denegado. ¿El archivo está abierto en Excel? {e}")
            if callback_progreso:
                callback_progreso(-1)
        except Exception as e:
            print(f"[ERROR CRÍTICO DEL SISTEMA] {str(e)}")
            import traceback
            traceback.print_exc()
            if callback_progreso:
                callback_progreso(-1)