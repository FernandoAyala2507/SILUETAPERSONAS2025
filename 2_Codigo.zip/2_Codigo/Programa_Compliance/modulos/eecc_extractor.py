import os
import re
import pandas as pd
import warnings
from datetime import datetime

warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')

class ExtractorEECC:
    def __init__(self):
        self.palabras_ruido = re.compile(
            r'(AJUSTE|FONDO|MORA|CARGO ADMINISTRATIVO|CARGOS ADMINISTRATIVOS|'
            r'MANTENIMIENTO|COMISION|COMI FLAT|MEMBRESIA|ITF|IMPUESTO|TAX|IGV|'
            r'SEGURO|INSURANCE|PROTECCION|GASTOS ADMINISTRATIVOS|ENVIO ESTADO CUENTA|'
            r'REPROGRAMA|REESTRUCTURA|DEUDA|INTERES MORATORIO|CIERRE|CANCELACION|'
            r'APORTE FONDO|COMISION DE MANTENIMIENTO)',
            re.IGNORECASE
        )
        self.rx_interes = re.compile(r'INTERES', re.IGNORECASE)
        self.rx_cts = re.compile(r'CTS|C\.T\.S\.|CTAS', re.IGNORECASE)

    def _homologar_moneda(self, valor):
        val_str = str(valor).strip().upper()
        if any(x in val_str for x in ["$", "USD", "DOL", "ME", "EXT"]):
            return "USD"
        return "PEN"

    def _normalizar_numero(self, valor):
        if pd.isna(valor):
            return 0.0
        valor_str = str(valor).strip()
        valor_limpio = re.sub(r'[^\d.-]', '', valor_str)
        try:
            return float(valor_limpio) if valor_limpio else 0.0
        except ValueError:
            return 0.0

    def _limpiar_glosa(self, texto):
        if pd.isna(texto):
            return ""
        texto = str(texto)
        texto = re.sub(r'\b(REF|NRO|COD|ID|TRX):\s*\w+\b', '', texto, flags=re.IGNORECASE)
        texto = re.sub(r'\d{2}/\d{2}/\d{4}', '', texto)
        texto = re.sub(r'\s+', ' ', texto).strip()
        return texto

    def _clasificar_transaccion(self, glosa):
        glosa_upper = glosa.upper() if glosa else ""
        if self.rx_interes.search(glosa_upper):
            return 'interes'
        elif self.palabras_ruido.search(glosa_upper):
            return 'ruido'
        else:
            return 'cliente'

    def _procesar_cabecera_cuentas(self, archivo, diccionario_cuentas):
        """Procesa Cabecera Cuentas (ROSPRTD) - DATOS DESDE FILA 8"""
        df_cab_raw = pd.read_excel(archivo, sheet_name="Cabecera Cuentas", header=None)
        
        for idx, row in df_cab_raw.iloc[7:].iterrows():
            tipo_cta_raw = str(row.iloc[2]).strip().upper() if len(row) > 2 else ""
            if not tipo_cta_raw or tipo_cta_raw in ["NAN", "NONE", ""]:
                continue
            
            nro_cta_raw = str(row.iloc[3]).strip() if len(row) > 3 else ""
            nro_cta = nro_cta_raw.split('.')[0]
            
            anio_apertura_raw = str(row.iloc[5]).strip().split('.')[0] if len(row) > 5 else "N/D"
            anio_ult_raw = str(row.iloc[6]).strip().split('.')[0] if len(row) > 6 else "N/D"
            estado_raw = str(row.iloc[7]).strip().upper() if len(row) > 7 else ""
            manco_raw = str(row.iloc[10]).strip().upper() if len(row) > 10 else ""
            
            if "CANCEL" in estado_raw or "CERRAD" in estado_raw:
                cierre_calculado = anio_ult_raw
            else:
                cierre_calculado = estado_raw if estado_raw else "ACTIVA"
            
            es_plazo = "PLAZO" in tipo_cta_raw or "D.PLAZO" in tipo_cta_raw
            es_cts = bool(self.rx_cts.search(tipo_cta_raw))
            
            diccionario_cuentas[nro_cta] = {
                "tipo_producto": tipo_cta_raw,
                "estado": estado_raw,
                "apertura_raw": anio_apertura_raw,
                "cierre_raw": anio_ult_raw,
                "cierre_calculado": cierre_calculado,
                "manco": "MANCOMUNADA" if manco_raw in ["INDISTINTA", "CONJUNTA", "MANCOMUNADA"] else "INDIVIDUAL",
                "es_plazo": es_plazo,
                "es_cts": es_cts,
                "nro_visual": nro_cta,
                "origen": "ROSPRTD",
                "es_cabecera_sin_movimientos": True  
            }

    def _procesar_cabecera_tarjetas(self, archivo, diccionario_cuentas):
        """Procesa Cabecera Tarjeta (ROSPRTT) - DATOS DESDE FILA 8"""
        df_cab_raw = pd.read_excel(archivo, sheet_name="Cabecera Tarjeta", header=None)
        
        for idx, row in df_cab_raw.iloc[7:].iterrows():
            tipo_prd_raw = str(row.iloc[3]).strip().upper() if len(row) > 3 else "TARJETA"
            nro_cta_raw = str(row.iloc[4]).strip() if len(row) > 4 else ""
            if not nro_cta_raw or nro_cta_raw.upper() in ["NAN", "NONE", ""]:
                continue
            
            nro_cta = nro_cta_raw.split('.')[0]
            moneda_raw = str(row.iloc[5]).strip().upper() if len(row) > 5 else "PEN"
            estado_raw = str(row.iloc[9]).strip().upper() if len(row) > 9 else ""
            anio_apertura_raw = str(row.iloc[10]).strip().split('.')[0] if len(row) > 10 else "N/D"
            anio_ult_raw = str(row.iloc[11]).strip().split('.')[0] if len(row) > 11 else "N/D"
            
            if "CANCEL" in estado_raw:
                cierre_calculado = anio_ult_raw
            else:
                cierre_calculado = estado_raw if estado_raw else "ACTIVA"
            
            diccionario_cuentas[nro_cta] = {
                "tipo_producto": tipo_prd_raw,
                "estado": estado_raw,
                "apertura_raw": anio_apertura_raw,
                "cierre_raw": anio_ult_raw,
                "cierre_calculado": cierre_calculado,
                "manco": "INDIVIDUAL",
                "es_plazo": False,
                "es_cts": False,
                "moneda": self._homologar_moneda(moneda_raw),
                "nro_visual": nro_cta,
                "origen": "ROSPRTT",
                "es_cabecera_sin_movimientos": True
            }

    def _procesar_movimientos(self, archivo, diccionario_cuentas, cuentas_con_movimientos):
        """Procesa pestañas de movimientos para ROSPRTD y ROSPRTT"""
        xl = pd.ExcelFile(archivo)
        nombre_archivo = os.path.basename(archivo).upper()
        es_cuenta = "ROSPRTD" in nombre_archivo
        es_tarjeta = "ROSPRTT" in nombre_archivo
        
        hojas_movimientos = []
        for hoja in xl.sheet_names:
            if es_cuenta and hoja == "Cabecera Cuentas":
                continue
            if es_tarjeta and hoja == "Cabecera Tarjeta":
                continue
            hojas_movimientos.append(hoja)
        
        movimientos_por_cuenta = {}
        
        for hoja in hojas_movimientos:
            try:
                header_idx = 0 if es_tarjeta else 3
                df_trx = pd.read_excel(archivo, sheet_name=hoja, header=header_idx)
                
                if df_trx.empty:
                    continue
                
                if es_cuenta:
                    if len(df_trx.columns) < 9:
                        continue
                    df_trx.columns = ['SEC', 'IGN1', 'NRO_CUENTA', 'MONEDA', 'IGN2', 'FECHA', 'GLOSA', 'CARGO', 'ABONO'] + list(df_trx.columns[9:])
                    
                    df_trx['NRO_CUENTA'] = df_trx['NRO_CUENTA'].astype(str).str.strip().str.split('.').str[0]
                    df_trx['MONEDA'] = df_trx['MONEDA'].apply(self._homologar_moneda)
                    df_trx['CARGO'] = df_trx['CARGO'].apply(self._normalizar_numero)
                    df_trx['ABONO'] = df_trx['ABONO'].apply(self._normalizar_numero)
                    
                    fechas_str = df_trx['FECHA'].astype(str).str.replace(r'\.0$', '', regex=True)
                    df_trx['FECHA_CONVERTIDA'] = pd.to_datetime(fechas_str, format='%Y%m%d', errors='coerce')
                    df_trx['GLOSA_LIMPIA'] = df_trx['GLOSA'].apply(self._limpiar_glosa)
                    df_trx['CATEGORIA'] = df_trx['GLOSA_LIMPIA'].apply(self._clasificar_transaccion)
                    
                    for (nro_cta, moneda), grupo in df_trx.groupby(['NRO_CUENTA', 'MONEDA']):
                        if not nro_cta or nro_cta.lower() in ["nan", "none", ""]:
                            continue
                        
                        if nro_cta not in movimientos_por_cuenta:
                            movimientos_por_cuenta[nro_cta] = {}
                        if moneda not in movimientos_por_cuenta[nro_cta]:
                            movimientos_por_cuenta[nro_cta][moneda] = {
                                "tot_abono": 0.0, "tot_cargo": 0.0, "tot_ruido": 0.0, "tot_intereses": 0.0,
                                "transacciones": [], "intereses": [], "ruido": []
                            }
                        
                        movimientos_por_cuenta[nro_cta][moneda]["tot_abono"] += grupo['ABONO'].sum()
                        movimientos_por_cuenta[nro_cta][moneda]["tot_cargo"] += grupo['CARGO'].sum()
                        
                        mask_ruido = grupo['CATEGORIA'] == 'ruido'
                        mask_interes = grupo['CATEGORIA'] == 'interes'
                        mask_cliente = grupo['CATEGORIA'] == 'cliente'
                        
                        movimientos_por_cuenta[nro_cta][moneda]["tot_ruido"] += grupo[mask_ruido]['CARGO'].sum() + grupo[mask_ruido]['ABONO'].sum()
                        movimientos_por_cuenta[nro_cta][moneda]["tot_intereses"] += grupo[mask_interes]['CARGO'].sum() + grupo[mask_interes]['ABONO'].sum()
                        
                        if not grupo[mask_cliente].empty:
                            movimientos_por_cuenta[nro_cta][moneda]["transacciones"].append(grupo[mask_cliente])
                        if not grupo[mask_interes].empty:
                            movimientos_por_cuenta[nro_cta][moneda]["intereses"].append(grupo[mask_interes])
                        if not grupo[mask_ruido].empty:
                            movimientos_por_cuenta[nro_cta][moneda]["ruido"].append(grupo[mask_ruido])
                        
                        cuentas_con_movimientos.add(nro_cta)
                        
                else:
                    if len(df_trx.columns) < 12:
                        continue
                    df_trx.columns = ['NOM_CLIENTE', 'PRODUCTO', 'NRO_CUENTA', 'NRO_TARJETA', 'TP_TC', 
                                     'MONEDA', 'FECHA_TRX', 'DESCRIP_TRX', 'GLOSA_NARRATIVA', 
                                     'TIP_MOV', 'MTO_CARGO', 'MTO_ABONO'] + list(df_trx.columns[12:])
                    
                    df_trx['NRO_CUENTA'] = df_trx['NRO_CUENTA'].astype(str).str.strip().str.split('.').str[0]
                    df_trx['MONEDA'] = df_trx['MONEDA'].apply(self._homologar_moneda)
                    df_trx['MTO_CARGO'] = df_trx['MTO_CARGO'].apply(self._normalizar_numero)
                    df_trx['MTO_ABONO'] = df_trx['MTO_ABONO'].apply(self._normalizar_numero)
                    
                    fechas_str = df_trx['FECHA_TRX'].astype(str).str.replace(r'\.0$', '', regex=True)
                    df_trx['FECHA_CONVERTIDA'] = pd.to_datetime(fechas_str, format='%Y%m%d', errors='coerce')
                    df_trx['GLOSA_LIMPIA'] = df_trx['DESCRIP_TRX'].apply(self._limpiar_glosa)
                    df_trx['CATEGORIA'] = df_trx['GLOSA_LIMPIA'].apply(self._clasificar_transaccion)
                    
                    for (nro_cta, moneda), grupo in df_trx.groupby(['NRO_CUENTA', 'MONEDA']):
                        if not nro_cta or nro_cta.lower() in ["nan", "none", ""]:
                            continue
                        
                        if nro_cta not in movimientos_por_cuenta:
                            movimientos_por_cuenta[nro_cta] = {}
                        if moneda not in movimientos_por_cuenta[nro_cta]:
                            movimientos_por_cuenta[nro_cta][moneda] = {
                                "tot_abono": 0.0, "tot_cargo": 0.0, "tot_ruido": 0.0, "tot_intereses": 0.0,
                                "transacciones": [], "intereses": [], "ruido": []
                            }
                        
                        movimientos_por_cuenta[nro_cta][moneda]["tot_abono"] += grupo['MTO_ABONO'].sum()
                        movimientos_por_cuenta[nro_cta][moneda]["tot_cargo"] += grupo['MTO_CARGO'].sum()
                        
                        mask_ruido = grupo['CATEGORIA'] == 'ruido'
                        mask_interes = grupo['CATEGORIA'] == 'interes'
                        mask_cliente = grupo['CATEGORIA'] == 'cliente'
                        
                        movimientos_por_cuenta[nro_cta][moneda]["tot_ruido"] += grupo[mask_ruido]['MTO_CARGO'].sum() + grupo[mask_ruido]['MTO_ABONO'].sum()
                        movimientos_por_cuenta[nro_cta][moneda]["tot_intereses"] += grupo[mask_interes]['MTO_CARGO'].sum() + grupo[mask_interes]['MTO_ABONO'].sum()
                        
                        if not grupo[mask_cliente].empty:
                            movimientos_por_cuenta[nro_cta][moneda]["transacciones"].append(grupo[mask_cliente])
                        if not grupo[mask_interes].empty:
                            movimientos_por_cuenta[nro_cta][moneda]["intereses"].append(grupo[mask_interes])
                        if not grupo[mask_ruido].empty:
                            movimientos_por_cuenta[nro_cta][moneda]["ruido"].append(grupo[mask_ruido])
                        
                        cuentas_con_movimientos.add(nro_cta)
                        
            except Exception as e:
                print(f"   [!] Error procesando hoja '{hoja}': {e}")
        
        for nro_cta, monedas in movimientos_por_cuenta.items():
            datos_cabecera = diccionario_cuentas.get(nro_cta, {})
            print(f"      datos_cabecera encontrados: {bool(datos_cabecera)}")
            if datos_cabecera:
                print(f"      tipo_producto en cabecera: {datos_cabecera.get('tipo_producto', 'NO EXISTE')}")
            else:
                print(f"      No se encontró cabecera para {nro_cta}")
                claves_existentes = [k for k in diccionario_cuentas.keys() if nro_cta in k]
                print(f"      Claves similares en diccionario: {claves_existentes}")
            for moneda, data in monedas.items():
                clave = f"{nro_cta}-{moneda}"
                
                diccionario_cuentas[clave] = {
                    "tipo_producto": str(datos_cabecera.get("tipo_producto", "CTA")),
                    "estado": datos_cabecera.get("estado", "OPERAT"),
                    "apertura_raw": datos_cabecera.get("apertura_raw", "N/D"),
                    "cierre_raw": datos_cabecera.get("cierre_raw", "N/D"),
                    "cierre_calculado": datos_cabecera.get("cierre_calculado", "N/D"),
                    "manco": datos_cabecera.get("manco", "INDIVIDUAL"),
                    "es_plazo": datos_cabecera.get("es_plazo", False),
                    "es_cts": datos_cabecera.get("es_cts", False),
                    "moneda": moneda,
                    "nro_visual": nro_cta,
                    "origen": "MOVIMIENTOS",
                    "tot_abono": data["tot_abono"],
                    "tot_cargo": data["tot_cargo"],
                    "tot_ruido": data["tot_ruido"],
                    "tot_intereses": data["tot_intereses"],
                    "transacciones": [],
                    "intereses": [],
                    "ruido": []
                }
                
                if data["transacciones"]:
                    diccionario_cuentas[clave]["transacciones"] = pd.concat(data["transacciones"], ignore_index=True)
                if data["intereses"]:
                    diccionario_cuentas[clave]["intereses"] = pd.concat(data["intereses"], ignore_index=True)
                if data["ruido"]:
                    diccionario_cuentas[clave]["ruido"] = pd.concat(data["ruido"], ignore_index=True)
            
            if nro_cta in diccionario_cuentas:
                diccionario_cuentas[nro_cta]["tiene_movimientos"] = True

    def extraer_datos_bancarios(self, archivos_excel, tipo_persona="PN"):
        diccionario_cuentas = {}
        cuentas_con_movimientos = set()
        
        for archivo in archivos_excel:
            nombre_archivo = os.path.basename(archivo).upper()
            es_cuenta = "ROSPRTD" in nombre_archivo
            es_tarjeta = "ROSPRTT" in nombre_archivo
            
            if not es_cuenta and not es_tarjeta:
                continue
            
            try:
                xl = pd.ExcelFile(archivo)
                if es_cuenta and "Cabecera Cuentas" in xl.sheet_names:
                    self._procesar_cabecera_cuentas(archivo, diccionario_cuentas)
                elif es_tarjeta and "Cabecera Tarjeta" in xl.sheet_names:
                    self._procesar_cabecera_tarjetas(archivo, diccionario_cuentas)
            except Exception as e:
                print(f"   [!] Error procesando cabecera de {nombre_archivo}: {e}")
            
            self._procesar_movimientos(archivo, diccionario_cuentas, cuentas_con_movimientos)
        
        # =========================================================
        # FILTRAR: Eliminar cuentas de cabecera que tienen movimientos
        # =========================================================
        cuentas_a_eliminar = []
        for key, data in diccionario_cuentas.items():
            if "-" not in key and data.get("tiene_movimientos", False):
                cuentas_a_eliminar.append(key)
        
        for key in cuentas_a_eliminar:
            if key in diccionario_cuentas:
                del diccionario_cuentas[key]

        cuentas_filtradas = {}
        
        for key, data in diccionario_cuentas.items():
            nro_cta = data.get("nro_visual", key.split('-')[0] if '-' in key else key)
            estado = data.get("estado", "")
            es_plazo = data.get("es_plazo", False)
            es_cts = data.get("es_cts", False)
            
            if tipo_persona == "PJ" and es_cts:
                continue
            
            if "CANCEL" in estado or "CERRAD" in estado:
                if nro_cta not in cuentas_con_movimientos:
                    continue
            
            if "transacciones" in data and isinstance(data["transacciones"], list):
                data["transacciones"] = pd.concat(data["transacciones"], ignore_index=True) if data["transacciones"] else pd.DataFrame()
            if "intereses" in data and isinstance(data["intereses"], list):
                data["intereses"] = pd.concat(data["intereses"], ignore_index=True) if data["intereses"] else pd.DataFrame()
            if "ruido" in data and isinstance(data["ruido"], list):
                data["ruido"] = pd.concat(data["ruido"], ignore_index=True) if data["ruido"] else pd.DataFrame()
            
            cuentas_filtradas[key] = data
        
        return cuentas_filtradas