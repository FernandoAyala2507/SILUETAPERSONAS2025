import os
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment

class ExportadorMaestro:
    def __init__(self, ruta_matriz):
        self.ruta_matriz = ruta_matriz
        self.COLOR_CABECERA = "002060" 

    def guardar(self, datos_resumen, datos_reps):
        if not datos_resumen and not datos_reps:
            print(">>> No hay datos activos/válidos para exportar al Libro Maestro.")
            return

        df_resumen = pd.DataFrame(datos_resumen)
        df_reps = pd.DataFrame(datos_reps)

        try:
            modo = 'a' if os.path.exists(self.ruta_matriz) else 'w'
            engine_args = {'if_sheet_exists': 'replace'} if modo == 'a' else {}
            
            with pd.ExcelWriter(self.ruta_matriz, engine='openpyxl', mode=modo, **engine_args) as writer:
                if not df_resumen.empty:
                    df_resumen.to_excel(writer, sheet_name="SENTINEL_RESUMEN", index=False)
                if not df_reps.empty:
                    df_reps.to_excel(writer, sheet_name="SENTINEL_REPRESENTANTES", index=False)

            self._aplicar_estilos(not df_resumen.empty, not df_reps.empty)
            print(f">>> ÉXITO: {len(df_resumen)} resúmenes y {len(df_reps)} representantes guardados.")

        except PermissionError:
            print("[ERROR FATAL] El Libro Maestro está abierto. Ciérrelo e intente nuevamente.")
        except Exception as e:
            print(f"[ERROR EXPORTADOR]: {str(e)}")
            import traceback
            traceback.print_exc()

    def _aplicar_estilos(self, hay_resumen, hay_reps):
        try:
            wb = load_workbook(self.ruta_matriz)
            fill_azul = PatternFill(start_color=self.COLOR_CABECERA, end_color=self.COLOR_CABECERA, fill_type="solid")
            font_blanca = Font(color="FFFFFF", bold=True)
            center_align = Alignment(horizontal="center", vertical="center")

            hojas = []
            if hay_resumen:
                hojas.append("SENTINEL_RESUMEN")
            if hay_reps:
                hojas.append("SENTINEL_REPRESENTANTES")

            for hoja in [h for h in hojas if h in wb.sheetnames]:
                ws = wb[hoja]
                for cell in ws[1]:
                    cell.fill = fill_azul
                    cell.font = font_blanca
                    cell.alignment = center_align
                
                for col in ws.columns:
                    col_letra = col[0].column_letter
                    
                    if col_letra == "E" and hoja == "SENTINEL_RESUMEN":
                        ws.column_dimensions[col_letra].width = 120
                    elif col_letra == "F" and hoja == "SENTINEL_RESUMEN":
                        ws.column_dimensions[col_letra].width = 50
                    else:
                        ws.column_dimensions[col_letra].width = 30

            wb.save(self.ruta_matriz)
            wb.close()
        except Exception as e:
            print(f"[ERROR APLICANDO ESTILOS]: {e}")