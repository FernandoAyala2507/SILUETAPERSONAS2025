import os
import pandas as pd
from modulos.procesador_pdf import ProcesadorSentinel
from modulos.exportador_excel import ExportadorMaestro
from utils.conversor_columnas import ConversorColumnas

class ExtractorSentinel:
    def __init__(self, config: dict):
        self.ruta_matriz = config.get("ruta_matriz", "")
        self.ruta_casos_destino = config.get("ruta_casos", "")
        self.col_mes = config.get("matriz_col_mes", "B")
        self.mes_seleccionado = config.get("MES", "")
        
        self.pestana = config.get("matriz_pestana", "DDR_ANUAL")
        self.col_car = config.get("matriz_col_car", "A").upper()
        self.col_tipo = config.get("matriz_col_tipo", "D").upper()
        
        self.procesador = ProcesadorSentinel()
        self.exportador = ExportadorMaestro(self.ruta_matriz)
        
        self.datos_resumen = []
        self.datos_reps = []
        self.mapa_tipos = {}
        self.casos_validos_mes = set()
        
        self._cargar_mapa_tipos()
    
    def _es_mes_valido(self, valor_celda):
        if not self.mes_seleccionado:
            return True
        mes_str = str(valor_celda).strip().upper().split('.')[0] 
        
        mapa_meses = {
            "ENERO": ["ENERO", "1", "01"], "FEBRERO": ["FEBRERO", "2", "02"],
            "MARZO": ["MARZO", "3", "03"], "ABRIL": ["ABRIL", "4", "04"],
            "MAYO": ["MAYO", "5", "05"], "JUNIO": ["JUNIO", "6", "06"],
            "JULIO": ["JULIO", "7", "07"], "AGOSTO": ["AGOSTO", "8", "08"],
            "SEPTIEMBRE": ["SEPTIEMBRE", "9", "09"], "OCTUBRE": ["OCTUBRE", "10", "10"],
            "NOVIEMBRE": ["NOVIEMBRE", "11", "11"], "DICIEMBRE": ["DICIEMBRE", "12", "12"]
        }
        permitidos = mapa_meses.get(self.mes_seleccionado, [self.mes_seleccionado])
        return mes_str in permitidos

    def _cargar_mapa_tipos(self):
        if not self.ruta_matriz or not os.path.exists(self.ruta_matriz):
            print(f"   [!] No se encontró la matriz: {self.ruta_matriz}")
            return
            
        try:
            df = pd.read_excel(self.ruta_matriz, sheet_name=self.pestana, dtype=str)
            idx_car = ConversorColumnas.col_a_indice(self.col_car)
            idx_tipo = ConversorColumnas.col_a_indice(self.col_tipo)
            idx_mes = ConversorColumnas.col_a_indice(self.col_mes)
            
            for i, row in df.iterrows():
                try:
                    n_caso = str(row.iloc[idx_car]).strip()
                    tipo = str(row.iloc[idx_tipo]).strip().upper()
                    mes_celda = str(row.iloc[idx_mes]).strip()
                    
                    if n_caso and n_caso.lower() not in ["nan", "none", ""]:
                        self.mapa_tipos[n_caso] = tipo
                        
                        if self._es_mes_valido(mes_celda):
                            self.casos_validos_mes.add(n_caso)
                except IndexError:
                    pass
        except Exception as e:
            print(f"   [!] Error cargando tipos en Sentinel: {e}")

    def ejecutar(self):
        print(f"\n--- Iniciando Extracción Sentinel V4 (Filtro: {self.mes_seleccionado}) ---")
        
        if not self.ruta_matriz or not os.path.exists(self.ruta_matriz):
            print("[ERROR] No se encuentra el Libro Maestro")
            return
            
        if not self.ruta_casos_destino or not os.path.exists(self.ruta_casos_destino):
            print("[ERROR] No se encuentra el directorio de casos")
            return
        
        carpetas = [f for f in os.listdir(self.ruta_casos_destino) if os.path.isdir(os.path.join(self.ruta_casos_destino, f))]
        
        for carpeta in carpetas:
            if self.mes_seleccionado and carpeta not in self.casos_validos_mes:
                continue
            
            print(f"[PROCESANDO CARPETA]: {carpeta}")
            ruta_folder = os.path.join(self.ruta_casos_destino, carpeta)
            tipo_persona = self.mapa_tipos.get(carpeta, "PN") 
            
            for archivo in os.listdir(ruta_folder):
                if archivo.lower().endswith(".pdf"):
                    ruta_pdf = os.path.join(ruta_folder, archivo)
                    resumen, reps = self.procesador.extraer_datos(ruta_pdf, carpeta, tipo_persona)
                    
                    if resumen:
                        self.datos_resumen.append(resumen)
                    if reps:
                        self.datos_reps.extend(reps)

        self.guardar_en_maestro()

    def guardar_en_maestro(self):
        self.exportador.guardar(self.datos_resumen, self.datos_reps)