import os
import gc
import re
import sys
import json
import copy
import shutil
import pandas as pd
from datetime import datetime
from docx import Document
from docx.table import _Row
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
from utils.conversor_columnas import ConversorColumnas

class GeneradorWordMasivo:
    def __init__(self, config: dict):
        self.ruta_excel = config.get("ruta_matriz")
        self.ruta_raiz = config.get("ruta_casos")
        self.ruta_formatos = config.get("ruta_formatos")
        
        self.pestana = config.get("matriz_pestana", "DDR_ANUAL")
        self.col_car = config.get("matriz_col_car", "A").upper()
        self.col_doi = config.get("matriz_col_doi", "AD").upper()
        self.col_nom = config.get("matriz_col_nom", "C").upper()
        self.col_tipo = config.get("matriz_col_tipo", "D").upper()
        self.col_mes = config.get("matriz_col_mes", "B").upper()
        self.mes_seleccionado = config.get("MES", "")
        self.ubigeos = {}
        try:
            def resource_path(relative_path):
                try:
                    base_path = sys._MEIPASS
                except Exception:
                    base_path = os.path.abspath(".")
                return os.path.join(base_path, relative_path)

            ruta_ubigeos = resource_path("ubigeos_map.json")
            if os.path.exists(ruta_ubigeos):
                with open(ruta_ubigeos, 'r', encoding='utf-8') as f:
                    self.ubigeos = json.load(f)
                print(f"   [OK] Mapa de ubigeos cargado: {len(self.ubigeos)} códigos")
            else:
                print(f"   [!] No se encontró ubigeos_map.json en: {ruta_ubigeos}")
        except Exception as e:
            print(f"   [!] Error cargando ubigeos: {e}")
        
        self.log_data = []
        self.ESTADO_CIVIL = {"1": "SOLTERO", "2": "CASADO", "3": "DIVORCIADO", "4": "VIUDO", "5": "CONVIVIENTE"}
        self.DEPARTAMENTOS = {
            "LMA": "Metropolitana de Lima", "AMA": "Amazonas", "ANC": "Ancash", "APU": "Apurímac", 
            "ARE": "Arequipa", "AYA": "Ayacucho", "CAJ": "Cajamarca", "CUZ": "Cusco", "CLL": "Callao", 
            "HUV": "Huancavelica", "HUC": "Huánuco", "ICA": "Ica", "JUN": "Junín", "LIB": "La Libertad", 
            "LAM": "Lambayeque", "LIM": "Lima", "LOR": "Loreto", "MDD": "Madre de Dios", 
            "MOQ": "Moquegua", "PAS": "Pasco", "PIU": "Piura", "PUN": "Puno", "SMA": "San Martín", 
            "TAC": "Tacna", "TUM": "Tumbes", "UCA": "Ucayali"
        }

    def _es_mes_valido(self, valor_celda):
        if not self.mes_seleccionado:
            return True
        mes_str = str(valor_celda).strip().upper().split('.')[0]
        
        mapa_meses = {
            "ENERO": ["ENERO", "1", "01"], "FEBRERO": ["FEBRERO", "2", "02"],
            "MARZO": ["MARZO", "3", "03"], "ABRIL": ["ABRIL", "4", "04"],
            "MAYO": ["MAYO", "5", "05"], "JUNIO": ["JUNIO", "6", "06"],
            "JULIO": ["JULIO", "7", "07"], "AGOSTO": ["AGOSTO", "8", "08"],
            "SEPTIEMBRE": ["SEPTIEMBRE", "9", "09"], "OCTUBRE": ["OCTUBRE", "10", "10"],
            "NOVIEMBRE": ["NOVIEMBRE", "11", "11"], "DICIEMBRE": ["DICIEMBRE", "12", "12"]
        }
        permitidos = mapa_meses.get(self.mes_seleccionado, [self.mes_seleccionado])
        return mes_str in permitidos

    @staticmethod
    def limpiar_espacios(val):
        if pd.isna(val) or str(val).strip().lower() in ['nan', 'none', '']:
            return ""
        return re.sub(r'\s+', ' ', str(val)).strip()

    @staticmethod
    def procesar_fecha_y2k(dia, mes, anio):
        d = GeneradorWordMasivo.limpiar_espacios(str(dia).split('.')[0]).zfill(2)
        m = GeneradorWordMasivo.limpiar_espacios(str(mes).split('.')[0]).zfill(2)
        a = GeneradorWordMasivo.limpiar_espacios(str(anio).split('.')[0])
        if not d or d == "00":
            return "No Registra"
        if len(a) <= 2 and a.isdigit():
            a = f"19{a.zfill(2)}" if int(a) > 30 else f"20{a.zfill(2)}"
        return f"{d}/{m}/{a}"

    @staticmethod
    def calcular_edad(dia, mes, anio):
        from datetime import date
        try:
            def limpiar(v):
                if v is None:
                    return ""
                s = str(v).strip()
                if s.lower() in ['nan', 'none', 'nat', '']:
                    return ""
                return s.split('.')[0].strip()
            
            d = limpiar(dia)
            m = limpiar(mes)
            a = limpiar(anio)
            
            if not d or not m or not a:
                return "--"
            
            d_int = int(d)
            m_int = int(m)
            a_int = int(a)
            
            if a_int < 100:
                a_int = 1900 + a_int if a_int > 30 else 2000 + a_int
            
            fecha_nac = date(a_int, m_int, d_int)
            hoy = date.today()
            
            edad = hoy.year - fecha_nac.year - ((hoy.month, hoy.day) < (fecha_nac.month, fecha_nac.day))
            return str(edad) if 0 <= edad <= 120 else "--"
        except Exception as e:
            print(f"   [DEBUG EDAD] Error calculando edad: {e} | dia={dia} mes={mes} anio={anio}")
            return "--"

    def _construir_ubigeo(self, fila_query):

        # --- Intento 1: Código de ubigeo ---
        ubigeo_raw = self.limpiar_espacios(fila_query.get("CUSUC4", "")).split('.')[0].strip()
        
        if ubigeo_raw and ubigeo_raw.lower() not in ["nan", "none", "0", ""]:
            ubigeo_raw = ubigeo_raw.zfill(6)  # Asegurar 6 dígitos
            if ubigeo_raw in self.ubigeos:
                return self.ubigeos[ubigeo_raw]
        
        # --- Fallback: DP - CT - PR ---
        dp = self.limpiar_espacios(fila_query.get("CUSCTY", ""))
        ct = self.limpiar_espacios(fila_query.get("CUSCTR", ""))
        pref = self.limpiar_espacios(fila_query.get("CUSSTE", "")).upper()
        pr = self.DEPARTAMENTOS.get(pref, pref)
        
        partes = [p for p in [dp, ct, pr] if p and p.lower() not in ["nan", "none", "--"]]
        return " – ".join(partes) if partes else "--"

    @staticmethod
    def obtener_val_por_nombre(fila, columna_nombre, default="--"):
        col_dict = {str(k).strip().upper(): k for k in fila.index}
        col_real = col_dict.get(str(columna_nombre).strip().upper())
        if not col_real:
            return default
        val_limpio = GeneradorWordMasivo.limpiar_espacios(fila.get(col_real, ""))
        return val_limpio if val_limpio else default

    def _obtener_val_por_letra(self, fila, letra_columna, default="--"):
        try:
            idx = ConversorColumnas.col_a_indice(letra_columna)
            val = self.limpiar_espacios(fila.iloc[idx])
            return val if val else default
        except IndexError:
            return default

    def unificar_runs_fragmentados(self, doc):

        import re
        
        def unificar_parrafo(p):
            if len(p.runs) <= 1:
                return
            texto_completo = p.text
            
            if re.search(r'\{\{.*?\}\}', texto_completo):
                if p.runs:
                    primer_run = p.runs[0]
                    primer_run.text = texto_completo
                    primer_run.bold = False
                    primer_run.italic = False
                    primer_run.underline = False
                    for run in p.runs[1:]:
                        run.text = ""
        
        for p in doc.paragraphs:
            unificar_parrafo(p)
        
        for table in self._obtener_todas_las_tablas(doc):
            for row in table.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        unificar_parrafo(p)
        
        for section in doc.sections:
            for p in section.header.paragraphs:
                unificar_parrafo(p)
            for p in section.footer.paragraphs:
                unificar_parrafo(p)

    def extraer_reemplazos(self, xl_obj, numero_caso, doi_objetivo, fila_maestra):
        reemplazos = {}
        datos_sentinel = []
        datos_cuentas = []
        
        reemplazos["{{NM}}"] = self._obtener_val_por_letra(fila_maestra, self.col_nom, "--")
        reemplazos["{{DOI}}"] = str(doi_objetivo)
        reemplazos["{{TD}}"] = self.obtener_val_por_nombre(fila_maestra, "TIPO DOI", "--")
        reemplazos["{{UBIGEO}}"] = "--"
        reemplazos["{{ED}}"] = "--"
        reemplazos["{{FNAC}}"] = "No Registra"
        reemplazos["{{CD}}"] = "No Registra"

        if "QUERY" in xl_obj.sheet_names:
            df_q = pd.read_excel(xl_obj, sheet_name="QUERY", dtype=str)
            fila_q = df_q[df_q["CUSIDN"].astype(str).str.strip() == str(doi_objetivo).strip()]
            if not fila_q.empty:
                f = fila_q.iloc[0]
                nombres_dr = [self.limpiar_espacios(f.get(c, "")) for c in ["CUSNA2", "CUSNA 3", "CUSNA 4"]]
                reemplazos["{{DR}}"] = " ".join([n for n in nombres_dr if n])
                reemplazos["{{DP}}"] = self.limpiar_espacios(f.get("CUSCTY", ""))
                reemplazos["{{CT}}"] = self.limpiar_espacios(f.get("CUSCTR", ""))
                pref = self.limpiar_espacios(f.get("CUSSTE", "")).upper()
                reemplazos["{{PR}}"] = self.DEPARTAMENTOS.get(pref, pref)
                ec_val = self.limpiar_espacios(f.get("CUSMST", "")).split('.')[0]
                reemplazos["{{EC}}"] = self.ESTADO_CIVIL.get(ec_val, "--")
                reemplazos["{{EM}}"] = self.obtener_val_por_nombre(f, "CUSIAD", "No Declara")
                reemplazos["{{PF}}"] = self.obtener_val_por_nombre(f, "CUSCP3", "No Declara")
                reemplazos["{{CLA}}"] = self.obtener_val_por_nombre(f, "CUSCP1", "No Declara")
                cel1 = self.limpiar_espacios(f.get("CUSPH1", ""))
                if cel1 in ["0", ""]:
                    hpn = str(f.get("CUSHPN", "")).replace('nan', '').lstrip('0').strip()
                    phn = str(f.get("CUSPHN", "")).replace('nan', '').lstrip('0').strip()
                    reemplazos["{{CL}}"] = f"{hpn}-{phn}" if (hpn and phn) else f"{hpn}{phn}"
                else:
                    reemplazos["{{CL}}"] = cel1
                reemplazos["{{FNAC}}"] = self.procesar_fecha_y2k(f.get("CUSBDD"), f.get("CUSBDM"), f.get("CUSBDY"))
                reemplazos["{{ED}}"] = self.calcular_edad(f.get("CUSBDD"), f.get("CUSBDM"), f.get("CUSBDY"))
                m, d, a = str(f.get("CUSIDM")), str(f.get("CUSIDD")), str(f.get("CUSIDY"))
                if "nan" in m.lower() or not m.strip():
                    m, d, a = str(f.get("CUSLDM")), str(f.get("CUSLDD")), str(f.get("CUSLDY"))
                reemplazos["{{CD}}"] = self.procesar_fecha_y2k(d, m, a)
                reemplazos["{{UBIGEO}}"] = self._construir_ubigeo(f)

        if "SUNAT_Extraido" in xl_obj.sheet_names:
            df_s = pd.read_excel(xl_obj, sheet_name="SUNAT_Extraido", dtype=str)
            fila_s = df_s[df_s["DOI (Buscado)"].astype(str).str.strip() == str(doi_objetivo).strip()]
            if not fila_s.empty:
                f = fila_s.iloc[0]
                ruc = self.obtener_val_por_nombre(f, "Número de RUC", "--")
                reemplazos["{{RUC}}"] = ruc[:11] if ruc != "--" else "--"
                reemplazos["{{ER}}"] = self.obtener_val_por_nombre(f, "Estado del Contribuyente", "--")
                reemplazos["{{FINI}}"] = self.obtener_val_por_nombre(f, "Fecha de Inicio de Actividades", "--")
                reemplazos["{{FINS}}"] = self.obtener_val_por_nombre(f, "Fecha de Inscripción", "--")
                reemplazos["{{DOFI}}"] = self.obtener_val_por_nombre(f, "Domicilio Fiscal", "--")
                aeco_raw = self.obtener_val_por_nombre(f, "Actividad(es) Económica(s)", "--")
                reemplazos["{{AECO}}"] = self.limpiar_espacios(re.sub(r'(?i)(Fecha consulta:?|\d{1,2}/\d{1,2}/\d{2,4}| \d{1,2}:\d{2})', '', aeco_raw))
                tco = self.obtener_val_por_nombre(f, "Tipo Contribuyente", "").upper()
                reemplazos["{{TCO}}"] = tco if tco != "--" else "--"
                reemplazos["{{1}}"] = "X" if "CON NEGOCIO" in tco else ""
                reemplazos["{{2}}"] = "X" if "CON NEGOCIO" not in tco else ""

        if "SENTINEL_REPRESENTANTES" in xl_obj.sheet_names:
            df_sent_reps = pd.read_excel(xl_obj, sheet_name="SENTINEL_REPRESENTANTES", dtype=str)
            filas_sent = df_sent_reps[df_sent_reps["CARPETA_ID"].astype(str).str.strip() == str(numero_caso).strip()]
            
            if "ESTADO" in filas_sent.columns:
                filas_sent = filas_sent[
                    filas_sent["ESTADO"].astype(str).str.upper().str.strip().apply(
                        lambda x: "ACTIVO" in x and "NO APLICA" not in x
                    )
                ]
            
            if not filas_sent.empty:
                reemplazos["{{A}}"], reemplazos["{{B}}"] = "X", ""
                for _, s in filas_sent.iterrows():
                    datos_sentinel.append({
                        "{{NRL}}": self.obtener_val_por_nombre(s, "NOMBRE_VINCULADO", "--"),
                        "{{RRL}}": self.obtener_val_por_nombre(s, "DOC_VINCULADO", "--"),
                        "{{CRL}}": self.obtener_val_por_nombre(s, "CARGO", "--")
                    })
            else:
                reemplazos["{{A}}"], reemplazos["{{B}}"] = "", "X"

        if "SENTINEL_RESUMEN" in xl_obj.sheet_names:
            df_sent_res = pd.read_excel(xl_obj, sheet_name="SENTINEL_RESUMEN", dtype=str)
            fila_res = df_sent_res[df_sent_res["CARPETA_ID"].astype(str).str.strip() == str(numero_caso).strip()]
            if not fila_res.empty:
                f_res = fila_res.iloc[0]
                reemplazos["{{RIESGO}}"] = self.obtener_val_por_nombre(f_res, "HISTORICO_RIESGO_4AÑOS", "NOR")
                reemplazos["{{DEUDA_TOT}}"] = self.obtener_val_por_nombre(f_res, "DEUDA_TOTAL_ACTUAL", "0.00")
                reemplazos["{{DET_DEUDA}}"] = self.obtener_val_por_nombre(f_res, "DETALLE_DEUDAS", "No registra deudas vigentes.")
                reemplazos["{{SEMAFORO}}"] = self.obtener_val_por_nombre(f_res, "SEMAFORO", "No registra")
            else:
                reemplazos["{{RIESGO}}"] = "NOR"
                reemplazos["{{DEUDA_TOT}}"] = "0.00"
                reemplazos["{{DET_DEUDA}}"] = "No registra información en Sentinel."
                reemplazos["{{SEMAFORO}}"] = "No registra"

        if "GESINTEL" in xl_obj.sheet_names:
            df_g = pd.read_excel(xl_obj, sheet_name="GESINTEL", dtype=str)
            filas_g = df_g[df_g["CARPETA_ID"].astype(str).str.strip() == str(numero_caso).strip()]
            hallazgos = [self.limpiar_espacios(g.get("HALLAZGOS_GESINTEL", "")) for _, g in filas_g.iterrows() if pd.notna(g.get("HALLAZGOS_GESINTEL"))]
            reemplazos["{{NEG}}"] = " - ".join(["Match en listas internas" if "Match NEG" in h else h for h in hallazgos if h]) if hallazgos else "--"

        if "Auditoria_Resultados" in xl_obj.sheet_names:
            df_audit = pd.read_excel(xl_obj, sheet_name="Auditoria_Resultados", dtype=str)
            
            col_carpeta_audit = None
            for col in df_audit.columns:
                if "CARPETA" in str(col).upper():
                    col_carpeta_audit = col
                    break
            
            if col_carpeta_audit:
                fila_audit = df_audit[df_audit[col_carpeta_audit].astype(str).str.strip() == str(numero_caso).strip()]
                if not fila_audit.empty:
                    col_resultados = None
                    for col in df_audit.columns:
                        if "RESULTADO" in str(col).upper():
                            col_resultados = col
                            break
                    
                    if col_resultados:
                        reemplazos["{{LIN}}"] = self.limpiar_espacios(fila_audit.iloc[0][col_resultados])
                    else:
                        reemplazos["{{LIN}}"] = "--"
                else:
                    reemplazos["{{LIN}}"] = "--"
            else:
                reemplazos["{{LIN}}"] = "--"
        else:
            reemplazos["{{LIN}}"] = "--"

        if "Resultados_Compliance" in xl_obj.sheet_names:
            df_lsb = pd.read_excel(xl_obj, sheet_name="Resultados_Compliance", dtype=str)
            
            col_caso = "CARPETA_ID" if "CARPETA_ID" in df_lsb.columns else "N° CASO"
            
            if col_caso in df_lsb.columns:
                fila_lsb = df_lsb[df_lsb[col_caso].astype(str).str.strip() == str(numero_caso).strip()]
                
                if not fila_lsb.empty:
                    f_lsb = fila_lsb.iloc[0]
                    an_val = self.obtener_val_por_nombre(f_lsb, "TEXTO_ANALISIS", self.obtener_val_por_nombre(f_lsb, "DETALLE DEL HALLAZGO", "No se detectó operativa."))
                    rf_val = self.obtener_val_por_nombre(f_lsb, "TEXTO_RESUMEN", "Descarte regular.")
                    est_val = self.obtener_val_por_nombre(f_lsb, "ESTADO_FINAL", self.obtener_val_por_nombre(f_lsb, "ESTADO FINAL", "DESCARTADO"))
                    
                    reemplazos["{{AN}}"] = an_val
                    reemplazos["{{RF}}"] = rf_val
                    reemplazos["{{VEREDICTO}}"] = est_val
                    reemplazos["{{NORMAL_X}}"] = "X" if "DESCARTADO" in est_val.upper() else ""
                    reemplazos["{{ALERTA_X}}"] = "X" if "ALERTA RIESGO" in est_val.upper() else ""
                else:
                    reemplazos["{{AN}}"] = "No se encontraron cuentas para auditar."
                    reemplazos["{{RF}}"] = "Evaluación no aplicable."
                    reemplazos["{{VEREDICTO}}"] = "SIN DATOS"
                    reemplazos["{{NORMAL_X}}"] = ""
                    reemplazos["{{ALERTA_X}}"] = ""

        try:
            from modulos.eecc_extractor import ExtractorEECC
            extractor_aux = ExtractorEECC()
            ruta_carpeta_caso = os.path.join(self.ruta_raiz, numero_caso)
            archivos_excel = [os.path.join(ruta_carpeta_caso, f) for f in os.listdir(ruta_carpeta_caso) 
                              if f.upper().endswith((".XLSX", ".XLS")) and ("ROSPRTD" in f.upper() or "ROSPRTT" in f.upper()) and not f.startswith("~")]
            
            if archivos_excel:
                diccionario_cuentas = extractor_aux.extraer_datos_bancarios(archivos_excel)
                for clave_cta, info in diccionario_cuentas.items():
                    tot_abono = float(info.get("tot_abono", 0.0))
                    tot_cargo = float(info.get("tot_cargo", 0.0))
                    moneda = info.get("moneda", "PEN")
                    str_ingresos = f"Abonos {tot_abono:,.2f} {moneda} - Cargos {tot_cargo:,.2f} {moneda}"

                    tipo_valor = info.get("tipo_producto", "")
                    if not tipo_valor:
                        tipo_valor = info.get("tipo", "CTA")
                    
                    datos_cuentas.append({
                        "{{TP}}": str(tipo_valor),
                        "{{Manco}}": str(info.get("manco", "INDIVIDUAL")),
                        "{{N°C}}": str(info.get("nro_visual", clave_cta)),
                        "{{FA}}": str(info.get("apertura_raw", "N/D")).replace(".0", ""),
                        "{{FC}}": str(info.get("cierre_calculado", "N/D")).replace(".0", ""),
                        "{{TI}}": str_ingresos
                    })
        except Exception as e:
            print(f"   [!] Advertencia al procesar operaciones para {numero_caso}: {e}")

        reemplazos["{{FCI}}"] = datetime.now().strftime("%d/%m/%Y")
        return reemplazos, datos_sentinel, datos_cuentas

    def _obtener_todas_las_tablas(self, doc):
        todas = list(doc.tables)
        for section in doc.sections:
            todas.extend(section.header.tables)
            todas.extend(section.footer.tables)
        i = 0
        while i < len(todas):
            for row in todas[i].rows:
                for cell in row.cells:
                    for tb in cell.tables:
                        if tb not in todas:
                            todas.append(tb)
            i += 1
        return todas

    def llenar_word(self, ruta, reemplazos, datos_sentinel, datos_cuentas):
        doc = Document(ruta)
        
        self.unificar_runs_fragmentados(doc)
        
        self._llenar_tabla_dinamica_xml(doc, "{{N°C}}", datos_cuentas, ["{{TP}}", "{{Manco}}", "{{N°C}}", "{{FA}}", "{{FC}}", "{{TI}}"])
        self._llenar_tabla_dinamica_xml(doc, "{{NRL}}", datos_sentinel, ["{{NRL}}", "{{RRL}}", "{{CRL}}"])
        
        self._procesar_todo_el_documento(doc, reemplazos)
        
        doc.save(ruta)

    def _procesar_todo_el_documento(self, doc, mapeo):
        for p in doc.paragraphs:
            self._aplicar_reemplazo_en_parrafo(p, mapeo)
        for section in doc.sections:
            for hp in section.header.paragraphs:
                self._aplicar_reemplazo_en_parrafo(hp, mapeo)
            for fp in section.footer.paragraphs:
                self._aplicar_reemplazo_en_parrafo(fp, mapeo)
        for table in self._obtener_todas_las_tablas(doc):
            for row in table.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        self._aplicar_reemplazo_en_parrafo(p, mapeo)

    def _aplicar_reemplazo_en_parrafo(self, p, mapeo):
        texto_completo = p.text
        if not texto_completo.strip():
            return
        
        hubo_cambio = False
        for tag, valor in mapeo.items():
            clean_tag = tag.replace("{{", "").replace("}}", "").strip()
            
            clean_tag_regex = re.escape(clean_tag.replace("°", "PLACEHOLDER").replace("º", "PLACEHOLDER")).replace("PLACEHOLDER", "[°º]")
            
            pattern_llaves = r"\{\{\s*" + clean_tag_regex + r"\s*\}\}"
            
            if re.search(pattern_llaves, texto_completo, flags=re.IGNORECASE):
                texto_completo = re.sub(pattern_llaves, str(valor), texto_completo, flags=re.IGNORECASE)
                hubo_cambio = True
            elif re.fullmatch(r"\s*" + clean_tag_regex + r"\s*", texto_completo, flags=re.IGNORECASE):
                texto_completo = str(valor)
                hubo_cambio = True
                
        if hubo_cambio:
            f_name, f_size, f_bold = None, None, None
            if p.runs:
                f_name = p.runs[0].font.name
                f_size = p.runs[0].font.size
                f_bold = p.runs[0].bold
                
            p.text = texto_completo
            
            if p.runs and f_name is not None:
                p.runs[0].font.name = f_name
                p.runs[0].font.size = f_size
                p.runs[0].font.bold = f_bold

    def _llenar_tabla_dinamica_xml(self, doc, tag_ancla, lista_datos, llaves_ordenadas):
        tabla_obj, fila_plantilla = None, None
        
        clean_tag = tag_ancla.replace("{{", "").replace("}}", "").strip()
        clean_tag_regex = re.escape(clean_tag.replace("°", "PLACEHOLDER").replace("º", "PLACEHOLDER")).replace("PLACEHOLDER", "[°º]")
        patron_ancla = r"\{\{\s*" + clean_tag_regex + r"\s*\}\}"

        for table in self._obtener_todas_las_tablas(doc):
            for row in table.rows:
                texto_fila = "".join([c.text.strip() for c in row.cells])
                if re.search(patron_ancla, texto_fila, flags=re.IGNORECASE):
                    tabla_obj = table
                    fila_plantilla = row
                    break
            if tabla_obj:
                break

        if tabla_obj and fila_plantilla:
            if lista_datos:
                last_tr = fila_plantilla._tr
                for d in lista_datos:
                    nuevo_tr_xml = copy.deepcopy(fila_plantilla._tr)
                    last_tr.addnext(nuevo_tr_xml)
                    last_tr = nuevo_tr_xml
                    
                    nueva_fila = _Row(nuevo_tr_xml, tabla_obj)
                    
                    for idx, llave in enumerate(llaves_ordenadas):
                        try:
                            celda = nueva_fila.cells[idx]
                            valor = str(d.get(llave, "--"))
                            
                            if celda.paragraphs:
                                p = celda.paragraphs[0]
                                if p.runs:
                                    p.runs[0].text = valor
                                    for r in p.runs[1:]:
                                        r.text = ""
                                else:
                                    p.text = valor
                        except IndexError:
                            pass
                
                try:
                    tabla_obj._tbl.remove(fila_plantilla._tr)
                except Exception as e:
                    print(f"Advertencia al limpiar fila plantilla: {e}")
            else:
                for idx in range(len(llaves_ordenadas)):
                    try:
                        if fila_plantilla.cells[idx].paragraphs:
                            p = fila_plantilla.cells[idx].paragraphs[0]
                            if p.runs:
                                p.runs[0].text = "--"
                                for r in p.runs[1:]:
                                    r.text = ""
                            else:
                                p.text = "--"
                    except IndexError:
                        pass

    def ejecutar(self):
        print(f"\n>>> INICIANDO FASE DOCUMENTAL: Consolidación Final")
        
        if not self.ruta_excel or not os.path.exists(self.ruta_excel):
            print("[ERROR] No se encuentra el Libro Maestro")
            return
            
        if not self.ruta_raiz or not os.path.exists(self.ruta_raiz):
            print("[ERROR] No se encuentra el directorio de casos")
            return
        
        try:
            xl_obj = pd.ExcelFile(self.ruta_excel)
            df_maestro = pd.read_excel(xl_obj, sheet_name=self.pestana, dtype=str)

            idx_car = ConversorColumnas.col_a_indice(self.col_car)
            idx_doi = ConversorColumnas.col_a_indice(self.col_doi)
            idx_tipo = ConversorColumnas.col_a_indice(self.col_tipo)
            idx_mes = ConversorColumnas.col_a_indice(self.col_mes)

            procesados = 0
            saltados_por_mes = 0

            for i, row in df_maestro.iterrows():
                try:
                    n_caso = self.limpiar_espacios(str(row.iloc[idx_car]))
                    doi = self.limpiar_espacios(str(row.iloc[idx_doi]))
                    tipo_persona = self.limpiar_espacios(str(row.iloc[idx_tipo])).upper()
                    mes_celda = self.limpiar_espacios(str(row.iloc[idx_mes]))
                except IndexError:
                    continue
                
                if not n_caso or n_caso.lower() in ["nan", "none"]:
                    continue
                
                if not self._es_mes_valido(mes_celda):
                    saltados_por_mes += 1
                    continue
                
                ruta_carpeta = os.path.join(self.ruta_raiz, n_caso)
                
                if not os.path.exists(ruta_carpeta):
                    self.log_data.append([n_caso, doi, "Error: Carpeta no encontrada", datetime.now()])
                    continue

                word_file = next((f for f in os.listdir(ruta_carpeta) if "Formulario" in f and f.endswith(".docx") and not f.startswith("~")), None)
                
                if not word_file:
                    if not self.ruta_formatos or not os.path.exists(self.ruta_formatos):
                        self.log_data.append([n_caso, doi, "Error: No hay Plantilla en expediente y no se definió ruta de Formatos", datetime.now()])
                        continue
                    
                    plantilla_origen = next((f for f in os.listdir(self.ruta_formatos) if tipo_persona in f.upper() and f.endswith(".docx") and not f.startswith("~")), None)
                    
                    if not plantilla_origen:
                        self.log_data.append([n_caso, doi, f"Error: No se encontró plantilla para '{tipo_persona}'", datetime.now()])
                        continue
                        
                    try:
                        ruta_origen_plantilla = os.path.join(self.ruta_formatos, plantilla_origen)
                        nuevo_nombre = f"Formulario DDR - {n_caso}.docx"
                        ruta_word = os.path.join(ruta_carpeta, nuevo_nombre)
                        shutil.copy2(ruta_origen_plantilla, ruta_word)
                        word_file = nuevo_nombre
                    except Exception as e:
                        self.log_data.append([n_caso, doi, f"Error copiando plantilla: {str(e)}", datetime.now()])
                        continue
                else:
                    ruta_word = os.path.join(ruta_carpeta, word_file)

                print(f"[*] Finalizando formatos de Compliance para: {n_caso}")
                
                try:
                    reemplazos, sentinel, cuentas = self.extraer_reemplazos(xl_obj, n_caso, doi, row)
                    self.llenar_word(ruta_word, reemplazos, sentinel, cuentas)
                    self.log_data.append([n_caso, doi, "Completado exitosamente", datetime.now()])
                    procesados += 1
                except PermissionError:
                    print(f"[!] Error: El archivo de {n_caso} está abierto. Ciérrelo.")
                    self.log_data.append([n_caso, doi, "Error: Archivo Abierto", datetime.now()])
                except Exception as e:
                    self.log_data.append([n_caso, doi, f"Error interno: {str(e)}", datetime.now()])
                
                gc.collect()

            print(f"\n[!] Consolidación Finalizada: {procesados} documentos procesados, {saltados_por_mes} saltados por filtro de mes")

        except Exception as e:
            print(f"[X] ERROR FATAL AL PROCESAR LIBRO MAESTRO: {str(e)}")
            import traceback
            traceback.print_exc()
        finally:
            if self.log_data:
                self._escribir_log_excel()

    def _escribir_log_excel(self):
        df_log = pd.DataFrame(self.log_data, columns=["N°_CASO", "DOI", "RESULTADO", "FECHA_HORA"])
        try:
            with pd.ExcelWriter(self.ruta_excel, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                df_log.to_excel(writer, sheet_name="LOG_CONSOLIDACION", index=False)
            
            wb = load_workbook(self.ruta_excel)
            ws = wb["LOG_CONSOLIDACION"]
            azul_fill = PatternFill(start_color="002060", end_color="002060", fill_type="solid")
            font_blanca = Font(color="FFFFFF", bold=True)
            for cell in ws[1]:
                cell.fill, cell.font = azul_fill, font_blanca
            wb.save(self.ruta_excel)
            print("[OK] Log de consolidación guardado en el Libro Maestro")
        except Exception as e:
            print(f"[ERROR] No se pudo guardar el log: {e}")