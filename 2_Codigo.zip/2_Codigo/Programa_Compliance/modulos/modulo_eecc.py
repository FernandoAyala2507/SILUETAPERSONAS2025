import pandas as pd
import shutil
from pathlib import Path
from utils.conversor_columnas import ConversorColumnas

class OrquestadorEECC:
    def __init__(self, config: dict):
        self.ruta_matriz = Path(config.get("ruta_matriz", ""))
        self.ruta_origen_eecc = Path(config.get("ruta_eecc", ""))
        self.ruta_destino_casos = Path(config.get("ruta_casos", ""))
        self.col_mes = config.get("matriz_col_mes", "B")
        self.mes_seleccionado = config.get("MES", "")
        self.pestana = config.get("matriz_pestana", "DDR_ANUAL")
        self.col_doi = config.get("matriz_col_doi", "AD").upper()
        self.col_car = config.get("matriz_col_car", "A").upper()

    def _es_mes_valido(self, valor_celda):
        if not self.mes_seleccionado:
            return True
        mes_str = str(valor_celda).strip().upper().split('.')[0] 
        
        mapa_meses = {
            "ENERO": ["ENERO", "1", "01"], "FEBRERO": ["FEBRERO", "2", "02"],
            "MARZO": ["MARZO", "3", "03"], "ABRIL": ["ABRIL", "4", "04"],
            "MAYO": ["MAYO", "5", "05"], "JUNIO": ["JUNIO", "6", "06"],
            "JULIO": ["JULIO", "7", "07"], "AGOSTO": ["AGOSTO", "8", "08"],
            "SEPTIEMBRE": ["SEPTIEMBRE", "9", "09"], "OCTUBRE": ["OCTUBRE", "10", "10"],
            "NOVIEMBRE": ["NOVIEMBRE", "11", "11"], "DICIEMBRE": ["DICIEMBRE", "12", "12"]
        }
        permitidos = mapa_meses.get(self.mes_seleccionado, [self.mes_seleccionado])
        return mes_str in permitidos

    def ejecutar(self):
        if not self.ruta_matriz.is_file():
            print(f"[-] ERROR EECC: La ruta de la Matriz no es un archivo Excel válido.")
            return
            
        if not self.ruta_origen_eecc.is_dir():
            print(f"[-] ERROR EECC: La ruta de origen EECC no es una carpeta válida.")
            return
            
        if not self.ruta_destino_casos.is_dir():
            print(f"[-] ERROR EECC: La ruta destino de casos no es una carpeta válida.")
            return

        try:
            df_ddr = pd.read_excel(self.ruta_matriz, sheet_name=self.pestana, dtype=str)
            
            idx_car = ConversorColumnas.col_a_indice(self.col_car)
            idx_doi = ConversorColumnas.col_a_indice(self.col_doi)
            idx_mes = ConversorColumnas.col_a_indice(self.col_mes)
            
            mapa_cuscun = {}
            xl_obj = pd.ExcelFile(self.ruta_matriz)
            
            if "QUERY" in xl_obj.sheet_names:
                df_query = pd.read_excel(xl_obj, sheet_name="QUERY", dtype=str)
                if 'CUSIDN' in df_query.columns and 'CUSCUN' in df_query.columns:
                    for _, fila_q in df_query.iterrows():
                        idn = str(fila_q.get('CUSIDN', '')).split('.')[0].strip()
                        cun = str(fila_q.get('CUSCUN', '')).split('.')[0].strip()
                        
                        if idn.lower() in ["nan", "none", ""]:
                            continue
                        if idn not in mapa_cuscun:
                            mapa_cuscun[idn] = set()
                        if cun and cun.lower() not in ["nan", "none", ""]:
                            mapa_cuscun[idn].add(cun)
            else:
                print("   [!] Advertencia: No se encontró pestaña 'QUERY'.")

            procesados = 0
            
            for i, row in df_ddr.iterrows():
                try:
                    n_caso = str(row.iloc[idx_car]).strip()
                    doi = str(row.iloc[idx_doi]).strip().split('.')[0]
                    mes_celda = str(row.iloc[idx_mes]).strip()
                except IndexError:
                    continue
                
                if not n_caso or n_caso.lower() in ['nan', 'none', '']:
                    continue
                
                if not self._es_mes_valido(mes_celda):
                    continue
                
                ruta_caso = self.ruta_destino_casos / n_caso
                
                if not ruta_caso.exists():
                    print(f"   [!] Saltando caso {n_caso}: La carpeta destino no existe.")
                    continue
                
                lista_cuscunes = mapa_cuscun.get(doi, set())
                archivos_candidatos = []
                
                for cuscun in lista_cuscunes:
                    archivos_candidatos.extend(list(self.ruta_origen_eecc.rglob(f"*{cuscun}*.xls*")))
                if doi and doi.lower() not in ["nan", "none", ""]:
                    archivos_candidatos.extend(list(self.ruta_origen_eecc.rglob(f"*{doi}*.xls*")))
                archivos_candidatos.extend(list(self.ruta_origen_eecc.rglob(f"*{n_caso}*.xls*")))
                
                carpeta_origen_caso = self.ruta_origen_eecc / n_caso
                if carpeta_origen_caso.exists() and carpeta_origen_caso.is_dir():
                    archivos_candidatos.extend(list(carpeta_origen_caso.rglob("*.xls*")))

                archivos_candidatos = list(set(archivos_candidatos))
                archivos_finales = [f for f in archivos_candidatos if "ROSPRT" in f.name.upper() and not f.name.startswith("~")]
                
                if archivos_finales:
                    txt_codigos = ", ".join(lista_cuscunes) if lista_cuscunes else "N/A"
                    print(f"   -> Copiando {len(archivos_finales)} EECC para {n_caso} (Códigos: {txt_codigos})")
                    for archivo in archivos_finales:
                        destino_archivo = ruta_caso / archivo.name
                        try:
                            if not destino_archivo.exists():
                                shutil.copy2(archivo, destino_archivo)
                                procesados += 1
                        except Exception as e:
                            print(f"      [X] Error copiando {archivo.name}: {e}")
                            
            print(f">>> EECC Finalizado. Se copiaron {procesados} archivos bancarios ROSPRT nuevos.")
            
        except ValueError as ve:
            print(f"[-] ERROR LECTURA: Asegúrate de que las columnas existan en la pestaña. Detalle: {ve}")
        except Exception as e:
            print(f"[-] ERROR CRÍTICO EECC: {e}")
            import traceback
            traceback.print_exc()