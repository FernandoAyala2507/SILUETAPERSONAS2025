import pandas as pd
from datetime import datetime

class ValidadorEECC:
    def __init__(self):
        self.umbral_volumen = 1000.0
        self.meses_es = {1:'enero', 2:'febrero', 3:'marzo', 4:'abril', 5:'mayo', 6:'junio', 7:'julio', 8:'agosto', 9:'septiembre', 10:'octubre', 11:'noviembre', 12:'diciembre'}

    def _generar_detalle_mensual(self, df_datos, moneda, es_ruido=False):
        if df_datos is None or df_datos.empty or 'FECHA_CONVERTIDA' not in df_datos.columns:
            return ""

        df_fechas = df_datos.dropna(subset=['FECHA_CONVERTIDA']).copy()
        if df_fechas.empty:
            return ""
        
        df_fechas.set_index('FECHA_CONVERTIDA', inplace=True)
        df_fechas.sort_index(inplace=True)
        
        df_mensual = df_fechas.resample('ME').sum(numeric_only=True)
        resumen = []
        
        for mes, row in df_mensual.iterrows():
            abonos = row.get('MTO_ABONO', row.get('ABONO', 0))
            cargos = row.get('MTO_CARGO', row.get('CARGO', 0))
            
            if abonos > 0 or cargos > 0:
                nombre_mes = f"{self.meses_es[mes.month]} {mes.year}"
                if es_ruido:
                    txt_abono = f"{abonos:.2f} {moneda} en abonos" if abonos > 0 else ""
                    txt_cargo = f"{cargos:.2f} {moneda} en cargos" if cargos > 0 else ""
                    unidos = " y ".join(filter(None, [txt_abono, txt_cargo]))
                    resumen.append(f"{nombre_mes}: {unidos}")
                else:
                    resumen.append(f"mes {nombre_mes} abonos {abonos:.2f} y cargos {cargos:.2f}")
                    
        return ", ".join(resumen)

    def _generar_detalle_ruido(self, df_ruido, moneda):
        """Genera lista detallada de conceptos de ruido administrativo"""
        if df_ruido.empty:
            return [], ""
        
        conceptos = []
        for _, row in df_ruido.iterrows():
            glosa = row.get('GLOSA_LIMPIA', row.get('DESCRIP_TRX', row.get('GLOSA', '')))
            monto = row.get('MTO_CARGO', row.get('CARGO', 0)) or row.get('MTO_ABONO', row.get('ABONO', 0))
            if monto > 0 and glosa:
                glosa_corta = glosa[:50] + "..." if len(glosa) > 50 else glosa
                conceptos.append(f"{glosa_corta} por {monto:.2f} {moneda}")
        
        texto = " | ".join(conceptos[:5]) if conceptos else ""
        return conceptos, texto

    def _generar_detalle_intereses(self, df_int, moneda):
        """Genera lista detallada de intereses"""
        if df_int.empty:
            return [], ""
        
        conceptos = []
        for _, row in df_int.iterrows():
            glosa = row.get('GLOSA_LIMPIA', row.get('DESCRIP_TRX', row.get('GLOSA', '')))
            monto = row.get('MTO_ABONO', row.get('ABONO', 0))
            if monto > 0 and glosa:
                conceptos.append(f"{glosa} por {monto:.2f} {moneda}")
        
        texto = " | ".join(conceptos[:3]) if conceptos else ""
        return conceptos, texto

    def evaluar_cuenta_individual(self, nro_cta, metadata, nro_caso):
        tipo_cta = metadata.get("tipo_producto", "").upper()
        estado_cta = metadata.get("estado", "").upper()
        df_trx = metadata.get("transacciones", pd.DataFrame())
        df_int = metadata.get("intereses", pd.DataFrame())
        df_ruido = metadata.get("ruido", pd.DataFrame())
        moneda = metadata.get("moneda", "PEN")
        es_plazo = metadata.get("es_plazo", False)
        es_cts = metadata.get("es_cts", False)
        nro_visual = metadata.get("nro_visual", nro_cta.split('-')[0] if '-' in nro_cta else nro_cta)

        # =========================================================
        # REGLA 1: DEPÓSITO A PLAZO
        # =========================================================
        if es_plazo or "PLAZO" in tipo_cta:
            if "CANCEL" not in estado_cta and "CERRAD" not in estado_cta:
                return {
                    "estado": "ALERTA RIESGO",
                    "codigo_escenario": 99,
                    "motivo_excel": f"Depósito a Plazo activo (Estado: {estado_cta})",
                    "detalle_word": f"Cuenta {nro_visual}: Depósito a Plazo activo (Estado: {estado_cta}). Requiere revisión.",
                    "detalle_ruido": ""
                }
            else:
                return {
                    "estado": "OK",
                    "codigo_escenario": 0,
                    "motivo_excel": f"Depósito a Plazo cancelado",
                    "detalle_word": f"Cuenta {nro_visual}: Depósito a Plazo cancelado.",
                    "detalle_ruido": ""
                }

        # Calcular totales
        suma_abonos = df_trx['MTO_ABONO'].sum() if 'MTO_ABONO' in df_trx.columns else (df_trx['ABONO'].sum() if 'ABONO' in df_trx.columns else 0)
        suma_cargos = df_trx['MTO_CARGO'].sum() if 'MTO_CARGO' in df_trx.columns else (df_trx['CARGO'].sum() if 'CARGO' in df_trx.columns else 0)
        suma_operativa = suma_abonos + suma_cargos
        
        # Obtener detalles de ruido e intereses
        conceptos_ruido, texto_ruido = self._generar_detalle_ruido(df_ruido, moneda)
        conceptos_int, texto_int = self._generar_detalle_intereses(df_int, moneda)
        
        # =========================================================
        # REGLA 2: SOLO RUIDO (sin operativas de cliente)
        # =========================================================
        if suma_operativa == 0:
            tiene_ruido = not df_ruido.empty
            tiene_intereses = not df_int.empty
            
            if tiene_ruido or tiene_intereses:
                # Construir mensaje detallado de lo que sí hubo
                partes = []
                if texto_ruido:
                    partes.append(f"conceptos administrativos: {texto_ruido}")
                if texto_int:
                    partes.append(f"intereses: {texto_int}")
                
                mensaje_detalle = f"Solo {' y '.join(partes)}" if partes else "Solo conceptos administrativos"
                
                return {
                    "estado": "OK",
                    "codigo_escenario": 0,
                    "motivo_excel": f"Cuenta {nro_visual} - Solo conceptos administrativos",
                    "detalle_word": f"Cuenta {nro_visual}: {mensaje_detalle}.",
                    "detalle_ruido": texto_ruido
                }
            else:
                # Sin operativas, sin ruido, sin intereses
                return {
                    "estado": "OK",
                    "codigo_escenario": 0,
                    "motivo_excel": f"Cuenta {nro_visual} - Sin operaciones",
                    "detalle_word": f"Cuenta {nro_visual}: Sin operaciones del cliente o Banco en el periodo evaluado.",
                    "detalle_ruido": ""
                }

        # =========================================================
        # REGLA 3: OPERATIVIDAD REGULAR
        # =========================================================
        df_fechas = df_trx.dropna(subset=['FECHA_CONVERTIDA']).copy() if 'FECHA_CONVERTIDA' in df_trx.columns else pd.DataFrame()
        
        if not df_fechas.empty:
            detalle_volumenes = self._generar_detalle_mensual(df_fechas, moneda, es_ruido=False)

            if suma_operativa < self.umbral_volumen:
                mensaje_adicional = ""
                if texto_ruido:
                    mensaje_adicional = f" Además, se detectaron conceptos administrativos: {texto_ruido}"
                if texto_int:
                    mensaje_adicional += f" Además, se detectaron intereses: {texto_int}"
                
                return {
                    "estado": "OK",
                    "codigo_escenario": 4,
                    "motivo_excel": f"Cuenta {nro_visual} - Volumen mínimo",
                    "detalle_word": f"Cuenta {nro_visual}: El cliente presenta un volumen mínimo transaccional, registrando: {detalle_volumenes}.{mensaje_adicional}",
                    "detalle_ruido": texto_ruido
                }
            
            df_fechas.set_index('FECHA_CONVERTIDA', inplace=True)
            df_fechas.sort_index(inplace=True)
            
            col_abono = 'MTO_ABONO' if 'MTO_ABONO' in df_fechas.columns else 'ABONO'
            col_cargo = 'MTO_CARGO' if 'MTO_CARGO' in df_fechas.columns else 'CARGO'
            vol_semanal = df_fechas.resample('W-MON')[[col_abono, col_cargo]].sum().sum(axis=1)
            
            if (vol_semanal <= self.umbral_volumen).all():
                mensaje_adicional = ""
                if texto_ruido:
                    mensaje_adicional = f" Además, se detectaron conceptos administrativos: {texto_ruido}"
                if texto_int:
                    mensaje_adicional += f" Además, se detectaron intereses: {texto_int}"
                
                return {
                    "estado": "OK",
                    "codigo_escenario": 6,
                    "motivo_excel": f"Cuenta {nro_visual} - Operatividad regular",
                    "detalle_word": f"Cuenta {nro_visual}: El cliente refleja operatividad regular sin picos inusuales, registrando: {detalle_volumenes}.{mensaje_adicional}",
                    "detalle_ruido": texto_ruido
                }
            
            return {
                "estado": "ALERTA RIESGO",
                "codigo_escenario": 90,
                "motivo_excel": f"Cuenta {nro_visual} - Supera umbral semanal",
                "detalle_word": f"Cuenta {nro_visual}: Supera {self.umbral_volumen} semanales.",
                "detalle_ruido": texto_ruido
            }

        return {
            "estado": "OK",
            "codigo_escenario": 4,
            "motivo_excel": f"Cuenta {nro_visual} - Fechas inválidas",
            "detalle_word": f"Cuenta {nro_visual}: Fechas inválidas o corruptas en estado de cuenta.",
            "detalle_ruido": ""
        }

    def evaluar_caso_completo(self, diccionario_cuentas, tipo_persona="PN", nro_caso=""):
        if not diccionario_cuentas:
            return {
                "descartado": True,
                "texto_an": "No se encontraron estados de cuenta para analizar en este expediente.",
                "texto_rf": "Evaluación no aplicable por falta de documentación bancaria.",
                "mensaje_excel": "Sin EECC"
            }
        
        resultados_individuales = []
        for nro_cta, metadata in diccionario_cuentas.items():
            resultado = self.evaluar_cuenta_individual(nro_cta, metadata, nro_caso)
            resultados_individuales.append(resultado)
        
        alertas = [r for r in resultados_individuales if r["estado"] == "ALERTA RIESGO"]
        descartado = len(alertas) == 0
        
        textos_detalle = [r["detalle_word"] for r in resultados_individuales if r.get("detalle_word")]
        texto_analisis = " | ".join(textos_detalle) if textos_detalle else "Operativa regular sin hallazgos relevantes."
        
        if descartado:
            texto_resumen = "Luego del análisis de movimientos bancarios, se determina que la operativa del cliente es regular y no presenta indicadores de riesgo que justifiquen una alerta."
        else:
            alerta_descripciones = [r["detalle_word"] for r in resultados_individuales if r["estado"] == "ALERTA RIESGO"]
            texto_resumen = f"Se detectaron alertas en el análisis financiero: {' | '.join(alerta_descripciones)}. Se recomienda profundizar la investigación."
        
        if not descartado:
            mensaje_excel = f"ALERTA: {len(alertas)} cuenta(s) con riesgo"
        else:
            mensaje_excel = f"Descartado - {len(resultados_individuales)} cuenta(s) analizada(s)"
        
        return {
            "descartado": descartado,
            "texto_an": texto_analisis,
            "texto_rf": texto_resumen,
            "mensaje_excel": mensaje_excel
        }